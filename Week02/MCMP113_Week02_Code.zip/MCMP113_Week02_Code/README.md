# MCMP113 · Introduction to Basic Algorithms and Programming
## Week 2 — example code pack

Asst. Prof. Hasan Oğuz, PhD · Istanbul Okan University · 2026–2027 Fall

Every folder in this pack is a **separate, complete C# console project** (`.csproj` + `Program.cs`) for .NET 10.
All programs were built with 0 errors / 0 warnings and run with the sample inputs listed below.

### Getting started
1. Install the **.NET 10 SDK** (https://dotnet.microsoft.com/en-us/download/dotnet/10.0) and **Visual Studio Code** with the **C# Dev Kit** extension.
2. Unzip this pack, e.g. to `Documents\MCMP113\Week02`.
3. Run one example from a terminal:
   ```
   cd 02_01_RectangleArea
   dotnet run
   ```
4. Or open the whole pack in VS Code (`File → Open Folder…`). The solution file `MCMP113_Week02_Code.sln` lists all projects; in the C# Dev Kit *Solution Explorer* right-click a project → *Debug → Start New Instance*.

### Notes
* Programs are written with **top-level statements** (no `class Program`/`Main` needed).
* The course project template turns off nullable warnings and uses **invariant culture**, so decimal numbers are typed with a **point** (`72.5`) even on Turkish-language Windows.
* Typing input: when a program waits, type a value and press **Enter**. Stop a running program with **Ctrl + C**.
* `bin/` and `obj/` folders are created automatically on the first build; you may delete them at any time.

---


Each folder is a separate .NET 10 console project (course template: Nullable off, InvariantGlobalization on).
Run with:  `cd <folder>`  then  `dotnet run`.
These are **look-ahead** programs: the C# syntax is taught from Week 3 on. Compare every run with its flowchart in the slides/notes.

| Folder | Flowchart pattern | Sample input |
|---|---|---|
| 02_01_RectangleArea | sequence: area and perimeter | 4.5, 3 |
| 02_02_AbsoluteValue | selection, one branch (IF–THEN) | -7.25 |
| 02_03_EvenOdd | selection, two branches (IF–THEN–ELSE) | 14 / -7 |
| 02_04_PassFail | two-way decision with a boundary (grade >= 50) | 49.5 / 50 |
| 02_05_MaxOfThree | nested decisions vs. running maximum | 4, 9, 7 |
| 02_06_LeapYear | three nested decisions + single condition | 2024, 2026, 1900, 2000 |
| 02_07_SumToN | repetition: sum 1..N (back-edge = while) | 100 / 0 |
| 02_08_Factorial | repetition with a product accumulator (long) | 5 / 20 |
| 02_09_EuclidGcd | loop not controlled by a counter | 48, 18 |
| 02_10_GuessNumber | decision inside a loop (secret fixed at 37) | 50, 25, 37 |
