// MCMP113 · Week 8 · Example 10 — Hollow square pattern (problem P6)
// Validated size (do-while), nested for loops, and a condition that selects border cells.

int n;
bool ok;
do
{
    Console.Write("Size (2-20): ");
    ok = int.TryParse(Console.ReadLine(), out n);
} while (!ok || n < 2 || n > 20);

for (int row = 1; row <= n; row++)
{
    for (int col = 1; col <= n; col++)
    {
        if (row == 1 || row == n || col == 1 || col == n)
        {
            Console.Write("* ");     // border cell
        }
        else
        {
            Console.Write("  ");     // inside: two spaces keep the columns aligned
        }
    }
    Console.WriteLine();
}
