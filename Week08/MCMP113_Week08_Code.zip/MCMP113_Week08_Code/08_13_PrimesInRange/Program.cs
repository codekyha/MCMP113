// MCMP113 · Week 8 · Example 13 — Prime numbers between A and B (problem P9)
// Nested loops: trial division up to the square root (d * d <= n) with break; counter of primes found.

int a, b;
bool okA, okB;
do
{
    Console.Write("A = ");
    okA = int.TryParse(Console.ReadLine(), out a);
    Console.Write("B = ");
    okB = int.TryParse(Console.ReadLine(), out b);
    if (!okA || !okB || a < 2 || b < a)
    {
        Console.WriteLine("  Need whole numbers with 2 <= A <= B. Try again.");
    }
} while (!okA || !okB || a < 2 || b < a);

int count = 0;
for (int n = a; n <= b; n++)
{
    bool isPrime = true;
    for (int d = 2; d * d <= n; d++)        // same as d <= Math.Sqrt(n)
    {
        if (n % d == 0)
        {
            isPrime = false;
            break;                          // one divisor is enough
        }
    }
    if (isPrime)
    {
        Console.Write(n + " ");
        count++;
    }
}
Console.WriteLine();
Console.WriteLine($"Primes between {a} and {b}: {count}");
