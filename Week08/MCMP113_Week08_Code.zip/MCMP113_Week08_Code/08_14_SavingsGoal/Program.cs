// MCMP113 · Week 8 · Example 14 — Months until a savings goal is reached (problem P10)
// Condition-controlled while loop (number of passes unknown in advance) with decimal money values.

Console.Write("Monthly deposit (TL): ");
decimal deposit = decimal.Parse(Console.ReadLine());
Console.Write("Monthly interest rate (%): ");
decimal rate = decimal.Parse(Console.ReadLine());
Console.Write("Target (TL): ");
decimal target = decimal.Parse(Console.ReadLine());

if (deposit <= 0 || rate < 0 || target <= 0)
{
    Console.WriteLine("Deposit and target must be positive; the rate cannot be negative.");
}
else
{
    decimal balance = 0;
    int months = 0;
    while (balance < target)
    {
        balance = balance * (1 + rate / 100) + deposit;   // interest first, then the new deposit
        months++;
    }
    Console.WriteLine($"Target reached after {months} months (= {months / 12} y {months % 12} m).");
    Console.WriteLine($"Final balance: {balance:F2} TL");
}
