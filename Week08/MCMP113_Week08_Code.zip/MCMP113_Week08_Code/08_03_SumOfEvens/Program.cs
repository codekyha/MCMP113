// MCMP113 · Week 8 · Example 3 — Sum of the even numbers from 1 to N (review question Q11)
// C# version of the flowchart answer: a counter loop with a decision inside.

Console.Write("N = ");
int n = int.Parse(Console.ReadLine());

int sum = 0;
for (int i = 1; i <= n; i++)
{
    if (i % 2 == 0)          // even?
    {
        sum += i;
    }
}
Console.WriteLine(
    $"Sum of even numbers from 1 to {n}: {sum}");
