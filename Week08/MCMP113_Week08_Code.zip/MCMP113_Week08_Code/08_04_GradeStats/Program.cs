// MCMP113 · Week 8 · Example 4 — Grade statistics with a sentinel (review question Q12)
// Sentinel-controlled while loop: count, average, highest and number passed; invalid grades are skipped.

int count = 0, sum = 0, highest = 0, passed = 0;

Console.Write("Grade (-1 to stop): ");
int grade = int.Parse(Console.ReadLine());      // priming read

while (grade != -1)
{
    if (grade < 0 || grade > 100)
    {
        Console.WriteLine("  Invalid grade, ignored.");
    }
    else
    {
        count++;
        sum += grade;
        if (count == 1 || grade > highest)       // first valid grade starts the maximum
        {
            highest = grade;
        }
        if (grade >= 50)
        {
            passed++;
        }
    }
    Console.Write("Grade (-1 to stop): ");
    grade = int.Parse(Console.ReadLine());      // read the next value at the END of the body
}

if (count == 0)
{
    Console.WriteLine("No grades entered.");
}
else
{
    double average = (double)sum / count;
    Console.WriteLine($"Count: {count}");
    Console.WriteLine($"Average: {average:F2}");
    Console.WriteLine($"Highest: {highest}");
    Console.WriteLine($"Passed: {passed} of {count}");
}
