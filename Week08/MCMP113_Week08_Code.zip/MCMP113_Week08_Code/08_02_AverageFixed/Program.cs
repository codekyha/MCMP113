// MCMP113 · Week 8 · Example 2 — Average of N grades (review question Q10, bugs fixed)
// Corrected "find the bugs" program: <= instead of <, no ';' after for, real division, $ string, guard for n <= 0.

Console.Write("How many grades? ");
int n = int.Parse(Console.ReadLine());

if (n <= 0)
{
    Console.WriteLine("Nothing to average.");   // fix 5: avoid division by zero
}
else
{
    int sum = 0;
    for (int i = 1; i <= n; i++)                // fix 1: <=   fix 2: no ';' here
    {
        Console.Write($"Grade {i}: ");
        int g = int.Parse(Console.ReadLine());
        sum += g;
    }
    double avg = (double)sum / n;               // fix 3: real (not integer) division
    Console.WriteLine($"Average: {avg:F2}");    // fix 4: $ makes it an interpolated string
}
