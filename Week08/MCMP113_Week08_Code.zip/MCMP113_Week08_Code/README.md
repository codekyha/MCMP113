# MCMP113 · Introduction to Basic Algorithms and Programming
## Week 8 — example code pack

Asst. Prof. Hasan Oğuz, PhD · Istanbul Okan University · 2026–2027 Fall

Every folder in this pack is a **separate, complete C# console project** (`.csproj` + `Program.cs`) for .NET 10.
All programs were built with 0 errors / 0 warnings and run with the sample inputs listed below.

### Getting started
1. Install the **.NET 10 SDK** (https://dotnet.microsoft.com/en-us/download/dotnet/10.0) and **Visual Studio Code** with the **C# Dev Kit** extension.
2. Unzip this pack, e.g. to `Documents\MCMP113\Week08`.
3. Run one example from a terminal:
   ```
   cd 08_01_PredictChecker
   dotnet run
   ```
4. Or open the whole pack in VS Code (`File → Open Folder…`). The solution file `MCMP113_Week08_Code.sln` lists all projects; in the C# Dev Kit *Solution Explorer* right-click a project → *Debug → Start New Instance*.

### Notes
* Programs are written with **top-level statements** (no `class Program`/`Main` needed).
* The course project template turns off nullable warnings and uses **invariant culture**, so decimal numbers are typed with a **point** (`72.5`) even on Turkish-language Windows.
* Typing input: when a program waits, type a value and press **Enter**. Stop a running program with **Ctrl + C**.
* `bin/` and `obj/` folders are created automatically on the first build; you may delete them at any time.

---


Every project is a separate .NET 10 console app (top-level statements). Run with `dotnet run` inside the folder.
All programs were built with 0 errors / 0 warnings and run with the sample input below.

| Folder | What it shows | Sample input |
|---|---|---|
| `08_01_PredictChecker` | Runs every predict-the-output / trace snippet of the deck (Q5–Q9), practice exam (Q1, Q2, Q3) and problem set (P1–P3, P11, P12). Answer on paper first! | none |
| `08_02_AverageFixed` | Review Q10: the "find the bugs" average program, corrected | `3`, `70`, `85`, `92` → 82.33 |
| `08_03_SumOfEvens` | Review Q11: sum of even numbers 1..N (flowchart answer in C#) | `10` → 30 |
| `08_04_GradeStats` | Review Q12: sentinel loop, count/average/highest/passed, invalid grades skipped | `72 45 105 90 58 -1` (one per line) |
| `08_05_FactorialFixed` | Practice exam Q5: factorial 1..20 with `long`, bugs fixed | `20` → 2432902008176640000 |
| `08_06_ShippingCost` | Practice exam Q6: TryParse validation, switch for zone, else-if weight brackets | `12.5`, `3` → 444.00 TL |
| `08_07_Divisors` | Practice exam Q7: do-while validation, divisors, prime and perfect test | `28` |
| `08_08_MinMax` | Problem P4: min, max, average of N numbers (best-so-far pattern) | `4`, `12.5`, `-3`, `40`, `7.5` |
| `08_09_DaysInMonth` | Problem P5: leap year + switch with grouped labels | `2024`, `2` → 29 days |
| `08_10_HollowSquare` | Problem P6: nested for loops, border condition | `5` |
| `08_11_DigitStats` | Problem P7: digit count/sum/even digits, reverse, palindrome (do-while) | `12321` |
| `08_12_MenuCalculator` | Problem P8: do-while menu + switch, division-by-zero and bad-choice handling | `1`, `7.5`, `2.5`, `0` |
| `08_13_PrimesInRange` | Problem P9: primes between A and B, trial division with `d * d <= n` and `break` | `10`, `50` → 11 primes |
| `08_14_SavingsGoal` | Problem P10: while loop until a savings target is reached (decimal) | `2000`, `1.5`, `30000` → 14 months |
