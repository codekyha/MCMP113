// MCMP113 · Week 8 · Example 5 — Factorial n! for 1 <= n <= 20 (practice exam Q5, bugs fixed)
// Corrected version: ';' added, || instead of &&, long instead of int, start at 1, no ';' after for.

Console.Write("n = ");
int n = int.Parse(Console.ReadLine());          // fix 1: missing ';'

if (n < 1 || n > 20)                            // fix 2: || (a number cannot be < 1 AND > 20)
{
    Console.WriteLine("Out of range");
}
else
{
    long fact = 1;                              // fix 3: long (13! does not fit in int)  fix 4: start at 1
    for (int i = 1; i <= n; i++)                // fix 5: no ';' after the for header
    {
        fact = fact * i;
    }
    Console.WriteLine("n! = " + fact);
}
