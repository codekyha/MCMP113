// MCMP113 · Week 8 · Example 9 — Days in a month (problem P5)
// Leap-year boolean expression + switch with grouped case labels + TryParse range checks.

Console.Write("Year: ");
bool okYear = int.TryParse(Console.ReadLine(), out int year);
Console.Write("Month (1-12): ");
bool okMonth = int.TryParse(Console.ReadLine(), out int month);

if (!okYear || year < 1)
{
    Console.WriteLine("Invalid year.");
}
else if (!okMonth || month < 1 || month > 12)
{
    Console.WriteLine("Invalid month.");
}
else
{
    bool leap = (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
    int days;
    switch (month)
    {
        case 2:
            days = leap ? 29 : 28;
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            days = 30;
            break;
        default:
            days = 31;
            break;
    }
    Console.WriteLine($"Month {month} of {year} has {days} days.");
    Console.WriteLine(leap ? $"{year} is a leap year." : $"{year} is not a leap year.");
}
