// MCMP113 · Week 8 · Example 11 — Digit statistics and palindrome test (problem P7)
// Digit loop with % 10 and / 10; do-while so that the number 0 still has one digit.

int n;
bool ok;
do
{
    Console.Write("Enter an integer (0 - 999999999): ");
    ok = int.TryParse(Console.ReadLine(), out n);
} while (!ok || n < 0 || n > 999999999);

int temp = n, digits = 0, digitSum = 0, evenDigits = 0, reversed = 0;
do
{
    int d = temp % 10;           // last digit
    digits++;
    digitSum += d;
    if (d % 2 == 0)
    {
        evenDigits++;
    }
    reversed = reversed * 10 + d;
    temp = temp / 10;            // drop the last digit
} while (temp > 0);

Console.WriteLine($"Digits: {digits}");
Console.WriteLine($"Sum of digits: {digitSum}");
Console.WriteLine($"Even digits: {evenDigits}");
Console.WriteLine($"Reversed: {reversed}");
Console.WriteLine(reversed == n ? "Palindrome: yes" : "Palindrome: no");
