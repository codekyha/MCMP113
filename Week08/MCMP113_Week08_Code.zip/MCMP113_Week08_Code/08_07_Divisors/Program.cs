// MCMP113 · Week 8 · Example 7 — Divisors, prime and perfect test (practice exam Q7)
// do-while input validation with TryParse, a for loop over candidate divisors, counters and ?: output.

int n;
bool ok;
do
{
    Console.Write("Enter an integer N (N >= 2): ");
    ok = int.TryParse(Console.ReadLine(), out n);
    if (!ok || n < 2)
    {
        Console.WriteLine("  Invalid input, try again.");
    }
} while (!ok || n < 2);

int count = 0, properSum = 0;
Console.Write($"Divisors of {n}:");
for (int d = 1; d <= n; d++)
{
    if (n % d == 0)
    {
        Console.Write($" {d}");
        count++;
        if (d < n)
        {
            properSum += d;     // proper divisors: all divisors except n itself
        }
    }
}
Console.WriteLine();

Console.WriteLine($"Number of divisors: {count}");
Console.WriteLine(count == 2 ? $"{n} is prime." : $"{n} is not prime.");
Console.WriteLine(properSum == n ? $"{n} is perfect." : $"{n} is not perfect (proper divisors sum to {properSum}).");
