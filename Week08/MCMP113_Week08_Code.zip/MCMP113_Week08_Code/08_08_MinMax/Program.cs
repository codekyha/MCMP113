// MCMP113 · Week 8 · Example 8 — Minimum, maximum and average of N numbers (problem P4)
// "Best so far" pattern without arrays: start min and max with the FIRST number, not with 0.

Console.Write("How many numbers? ");
int n = int.Parse(Console.ReadLine());

if (n < 1)
{
    Console.WriteLine("N must be at least 1.");
}
else
{
    Console.Write("Number 1: ");
    double x = double.Parse(Console.ReadLine());
    double min = x, max = x, sum = x;

    for (int i = 2; i <= n; i++)
    {
        Console.Write($"Number {i}: ");
        x = double.Parse(Console.ReadLine());
        if (x < min)
        {
            min = x;
        }
        if (x > max)
        {
            max = x;
        }
        sum += x;
    }
    Console.WriteLine($"Min: {min}  Max: {max}  Average: {sum / n:F2}");
}
