// MCMP113 · Week 8 · Example 12 — Menu-driven calculator (problem P8)
// do-while menu + switch; TryParse failure must not be mistaken for choice 0 (Exit).

int choice;
do
{
    Console.WriteLine();
    Console.WriteLine("1) Add  2) Subtract  3) Multiply  4) Divide  0) Exit");
    Console.Write("Choice: ");
    bool ok = int.TryParse(Console.ReadLine(), out choice);
    if (!ok)
    {
        choice = -1;             // TryParse sets choice to 0 on failure -> would exit!
    }

    if (choice >= 1 && choice <= 4)
    {
        Console.Write("a = ");
        double a = double.Parse(Console.ReadLine());
        Console.Write("b = ");
        double b = double.Parse(Console.ReadLine());
        switch (choice)
        {
            case 1:
                Console.WriteLine($"{a} + {b} = {a + b}");
                break;
            case 2:
                Console.WriteLine($"{a} - {b} = {a - b}");
                break;
            case 3:
                Console.WriteLine($"{a} * {b} = {a * b}");
                break;
            case 4:
                if (b == 0)
                {
                    Console.WriteLine("Error: division by zero.");
                }
                else
                {
                    Console.WriteLine($"{a} / {b} = {a / b:F4}");
                }
                break;
        }
    }
    else if (choice != 0)
    {
        Console.WriteLine("Unknown choice.");
    }
} while (choice != 0);

Console.WriteLine("Goodbye!");
