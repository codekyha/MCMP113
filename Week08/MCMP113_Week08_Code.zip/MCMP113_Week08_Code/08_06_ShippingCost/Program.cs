// MCMP113 · Week 8 · Example 6 — Shipping cost calculator (practice exam Q6)
// TryParse validation, else-if brackets for the weight surcharge and a switch for the zone price.

Console.Write("Weight (kg): ");
bool okWeight = decimal.TryParse(Console.ReadLine(), out decimal weight);
Console.Write("Zone (1 = city, 2 = domestic, 3 = international): ");
bool okZone = int.TryParse(Console.ReadLine(), out int zone);

if (!okWeight || weight <= 0 || weight > 30)
{
    Console.WriteLine("Invalid weight.");
}
else if (!okZone || zone < 1 || zone > 3)
{
    Console.WriteLine("Invalid zone.");
}
else
{
    decimal basePrice = 0;
    switch (zone)
    {
        case 1:
            basePrice = 60;
            break;
        case 2:
            basePrice = 90;
            break;
        case 3:
            basePrice = 350;
            break;
    }

    decimal surcharge;
    if (weight <= 2)
    {
        surcharge = 0;
    }
    else if (weight <= 10)
    {
        surcharge = (weight - 2) * 8;           // 8 TL per kg above 2 kg
    }
    else
    {
        surcharge = 64 + (weight - 10) * 12;    // 64 TL for 2..10 kg, then 12 TL per kg
    }

    decimal total = basePrice + surcharge;
    Console.WriteLine($"Base price: {basePrice:F2} TL");
    Console.WriteLine($"Surcharge:  {surcharge:F2} TL");
    Console.WriteLine($"Total:      {total:F2} TL");
}
