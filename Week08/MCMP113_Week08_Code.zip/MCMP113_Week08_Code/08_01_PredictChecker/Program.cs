// MCMP113 · Week 8 · Example 1 — Predict-the-output checker
// Runs every "predict the output" / trace snippet of the review deck, the practice exam and the problem set.
// Try each question on paper FIRST, then run this program to check your answers.

Console.WriteLine("===== Review deck, Q5: operators =====");
{
    int a = 17, b = 5;
    Console.WriteLine(a / b);
    Console.WriteLine(a % b);
    Console.WriteLine(a / (double)b);
    Console.WriteLine(a + b * 2 - 1);
    Console.WriteLine(-a % b);
    Console.WriteLine("Sum: " + a + b);
    Console.WriteLine(a > b && b != 5);
    int x = 5;
    int y = x++ * 2;
    Console.WriteLine($"{x} {y}");
}

Console.WriteLine("===== Review deck, Q6: trace the while loop =====");
{
    int n = 1230, rev = 0, count = 0;
    while (n > 0)
    {
        int d = n % 10;
        rev = rev * 10 + d;
        n = n / 10;
        count++;
        Console.WriteLine($"  trace: d={d} rev={rev} n={n} count={count}");
    }
    Console.WriteLine($"{rev} {count}");
}

Console.WriteLine("===== Review deck, Q7: selection =====");
{
    int score = 85;
    if (score >= 50)
    {
        Console.WriteLine("DD");
    }
    else if (score >= 85)
    {
        Console.WriteLine("BA");
    }
    else
    {
        Console.WriteLine("FF");
    }

    int day = 7;
    switch (day)
    {
        case 6:
        case 7:
            Console.WriteLine("Weekend");
            break;
        default:
            Console.WriteLine("Weekday");
            break;
    }

    Console.WriteLine(score % 2 == 0 ? "even" : "odd");
}

Console.WriteLine("===== Review deck, Q8: nested for =====");
{
    int stars = 0;
    for (int i = 1; i <= 4; i++)
    {
        for (int j = 1; j <= 4 - i; j++)
        {
            Console.Write(" ");
        }
        for (int k = 1; k <= 2 * i - 1; k++)
        {
            Console.Write("*");
            stars++;
        }
        Console.WriteLine();
    }
    Console.WriteLine($"  (Console.Write(\"*\") executed {stars} times)");
}

Console.WriteLine("===== Review deck, Q9: break / continue / do-while =====");
{
    int total = 0;
    for (int i = 1; i <= 10; i++)
    {
        if (i % 3 == 0)
        {
            continue;
        }
        if (i > 7)
        {
            break;
        }
        total += i;
    }
    Console.WriteLine(total);

    int k = 10;
    do
    {
        Console.Write(k + " ");
        k += 5;
    } while (k < 10);
    Console.WriteLine($"| k = {k}");
}

Console.WriteLine("===== Practice exam, Q1: selected multiple-choice items =====");
{
    int x = (int)7.9;
    Console.WriteLine($"Q1.4  (int)7.9 = {x}");
    Console.WriteLine($"Q1.5  10 - 4 / 2 * 3 = {10 - 4 / 2 * 3}");
    Console.Write("Q1.7  7 / 2 * 2.0 prints: ");
    Console.WriteLine(7 / 2 * 2.0);
    int hi = 0;
    for (int i = 0; i < 10; i += 3)
    {
        hi++;
    }
    Console.WriteLine($"Q1.8  \"Hi\" is printed {hi} times");
    bool ok = int.TryParse("12a", out int v);
    Console.WriteLine($"Q1.10 TryParse(\"12a\") -> {ok}, v = {v}");
}

Console.WriteLine("===== Practice exam, Q2: predict the output =====");
{
    Console.WriteLine("(a)");
    int a = 7, b = 2;
    double c = a / b;
    Console.WriteLine($"{c} {a % b} {(double)a / b}");

    Console.WriteLine("(b)");
    string s = "C#";
    Console.WriteLine(s + 1 + 2);
    Console.WriteLine(1 + 2 + s);

    Console.WriteLine("(c)");
    int x = 5;
    int y = x++ + 2;
    int z = --x * 2;
    Console.WriteLine($"{x} {y} {z}");

    Console.WriteLine("(d)");
    int t = 25;
    bool raining = false;
    if (t > 20 && !raining)
    {
        Console.Write("Picnic ");
    }
    if (t > 10 || raining)
    {
        Console.Write("Walk ");
    }
    else
    {
        Console.Write("Stay ");
    }
    Console.WriteLine(t >= 25 ? "Warm" : "Cool");

    Console.WriteLine("(e)");
    int month = 4, days;
    switch (month)
    {
        case 2:
            days = 28;
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            days = 30;
            break;
        default:
            days = 31;
            break;
    }
    Console.WriteLine($"Month {month}: {days} days");
}

Console.WriteLine("===== Practice exam, Q3: trace table =====");
{
    int n = 13, steps = 0, maxValue = n, tests = 0;
    while (n != 1)
    {
        tests++;
        if (n % 2 == 0)
        {
            n = n / 2;
        }
        else
        {
            n = 3 * n + 1;
        }
        steps++;
        if (n > maxValue)
        {
            maxValue = n;
        }
        Console.WriteLine($"  trace: n={n} steps={steps} maxValue={maxValue}");
    }
    tests++; // the final test (n != 1 is false)
    Console.WriteLine($"steps={steps}, max={maxValue}");
    Console.WriteLine($"  (condition n != 1 tested {tests} times)");
}

Console.WriteLine("===== Problem set, P1: counting nested iterations =====");
{
    int count = 0;
    for (int i = 1; i <= 5; i++)
    {
        for (int j = i; j <= 5; j++)
        {
            count++;
        }
    }
    Console.WriteLine($"(a) count = {count}");

    count = 0;
    for (int i = 1; i <= 5; i++)
    {
        for (int j = 1; j < i; j++)
        {
            count++;
        }
    }
    Console.WriteLine($"(b) count = {count}");
}

Console.WriteLine("===== Problem set, P2: trace the for loop =====");
{
    int x = 1;
    for (int i = 1; i <= 5; i++)
    {
        x = x * 2 + i;
        Console.WriteLine($"  trace: i={i} x={x}");
    }
    Console.WriteLine(x);
}

Console.WriteLine("===== Problem set, P3: for -> while -> do-while =====");
{
    for (int i = 10; i > 0; i -= 3)
    {
        Console.Write(i + " ");
    }
    Console.WriteLine("| for");

    int w = 10;
    while (w > 0)
    {
        Console.Write(w + " ");
        w -= 3;
    }
    Console.WriteLine("| while");

    int d = 10;
    do
    {
        Console.Write(d + " ");
        d -= 3;
    } while (d > 0);
    Console.WriteLine("| do-while");

    // start value 0: the condition is false from the beginning
    for (int i = 0; i > 0; i -= 3)
    {
        Console.Write(i + " ");
    }
    Console.WriteLine("| for, start 0");
    int e = 0;
    do
    {
        Console.Write(e + " ");
        e -= 3;
    } while (e > 0);
    Console.WriteLine("| do-while, start 0");
}

Console.WriteLine("===== Problem set, P11: the loop that never ends (first 8 passes only) =====");
{
    int i = 1, guard = 0;
    while (i != 10 && guard < 8)
    {
        Console.Write(i + " ");
        i += 2;
        guard++;
    }
    Console.WriteLine("...");
}

Console.WriteLine("===== Problem set, P12: logical operators and short-circuit =====");
{
    int a = 3, b = 0, c = -2;
    Console.WriteLine(a > b && b > c);
    Console.WriteLine(!(a < b) || c > 0);
    Console.WriteLine(b != 0 && a / b > 1);
    Console.WriteLine(a % 2 == 1 || a / b > 0);
    Console.WriteLine(!(a > 0 && c > 0));
    // (f) a / b > 0 || a % 2 == 1  would throw DivideByZeroException: not executed here.
}
