// MCMP113 · Week 11 · Example 4 — Diagonals of a square matrix and the identity matrix
// Main diagonal: r == c.  Anti-diagonal: r + c == n - 1.  Identity: 1 on the main diagonal, 0 elsewhere.

int[,] a =
{
    { 2, 7, 1, 8 },
    { 7, 3, 5, 0 },
    { 1, 5, 4, 6 },
    { 8, 0, 6, 9 },
};
int n = a.GetLength(0);              // square: rows == columns

// print [x] on the main diagonal, (x) on the anti-diagonal
// (this layout assumes single-digit values)
for (int r = 0; r < n; r++)
{
    for (int c = 0; c < n; c++)
    {
        if (r == c)
        {
            Console.Write($"  [{a[r, c]}]");
        }
        else if (r + c == n - 1)
        {
            Console.Write($"  ({a[r, c]})");
        }
        else
        {
            Console.Write($"{a[r, c],5}");
        }
    }
    Console.WriteLine();
}

// one loop is enough: on each diagonal the column follows from the row
int mainSum = 0;
int antiSum = 0;
for (int i = 0; i < n; i++)
{
    mainSum += a[i, i];
    antiSum += a[i, n - 1 - i];
}
Console.WriteLine($"Main diagonal sum (trace) = {mainSum}");
Console.WriteLine($"Anti-diagonal sum         = {antiSum}");

// identity matrix of the same size
int[,] identity = new int[n, n];     // all zeros
for (int i = 0; i < n; i++)
{
    identity[i, i] = 1;
}
Console.WriteLine($"Identity {n} x {n}:");
for (int r = 0; r < n; r++)
{
    for (int c = 0; c < n; c++)
    {
        Console.Write($"{identity[r, c],3}");
    }
    Console.WriteLine();
}
