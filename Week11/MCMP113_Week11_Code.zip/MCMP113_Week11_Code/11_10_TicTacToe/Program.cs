// MCMP113 · Week 11 · Example 10 — Tic-tac-toe on a 3 x 3 char matrix
// Two players type row and column (1-3); after every move the program checks rows, columns and both diagonals.

char[,] board = new char[3, 3];
for (int r = 0; r < 3; r++)
{
    for (int c = 0; c < 3; c++)
    {
        board[r, c] = '.';
    }
}

char player = 'X';
int moves = 0;
bool win = false;
while (!win && moves < 9)
{
    Console.Write($"{player} row: ");
    int row = int.Parse(Console.ReadLine()) - 1;   // 1-3 -> 0-2
    Console.Write($"{player} col: ");
    int col = int.Parse(Console.ReadLine()) - 1;
    bool inside = row >= 0 && row <= 2 && col >= 0 && col <= 2;
    if (!inside || board[row, col] != '.')
    {
        Console.WriteLine("Invalid move, try again.");
        continue;                                  // same player again
    }
    board[row, col] = player;
    moves++;

    // print the board
    for (int r = 0; r < 3; r++)
    {
        Console.Write($"  {board[r, 0]} {board[r, 1]}");
        Console.WriteLine($" {board[r, 2]}");
    }

    // win check: 3 rows, 3 columns, 2 diagonals
    for (int i = 0; i < 3; i++)
    {
        if (board[i, 0] == player
            && board[i, 1] == player
            && board[i, 2] == player)
        {
            win = true;                              // row i
        }
        if (board[0, i] == player
            && board[1, i] == player
            && board[2, i] == player)
        {
            win = true;                              // column i
        }
    }
    if (board[0, 0] == player
        && board[1, 1] == player
        && board[2, 2] == player)
    {
        win = true;                                  // main diagonal
    }
    if (board[0, 2] == player
        && board[1, 1] == player
        && board[2, 0] == player)
    {
        win = true;                                  // anti-diagonal
    }

    if (!win)
    {
        player = player == 'X' ? 'O' : 'X';          // next player
    }
}

if (win)
{
    Console.WriteLine($"{player} wins after {moves} moves!");
}
else
{
    Console.WriteLine("Draw: the board is full.");
}
