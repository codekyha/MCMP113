// MCMP113 · Week 11 · Example 3 — Grade book (students x exams)
// Row averages, the best grade of each row, column averages and the top student.

// a name for every row and for every column
string[] students = { "Elif", "Mehmet", "Zeynep", "Can" };
string[] exams = { "Quiz", "Midterm", "Final" };
double[,] grades =
{
    { 70, 65, 80 },
    { 45, 55, 60 },
    { 90, 85, 95 },
    { 60, 75, 50 },
};
int nStudents = grades.GetLength(0);
int nExams = grades.GetLength(1);

// header line
Console.Write($"{"Student",-8}");
for (int c = 0; c < nExams; c++)
{
    Console.Write($"{exams[c],9}");
}
Console.WriteLine($"{"Average",9}{"Best",6}");

// one line per student: grades, row average, row maximum
int topStudent = 0;
double topAverage = -1;
for (int r = 0; r < nStudents; r++)
{
    double rowSum = 0;
    double rowMax = grades[r, 0];    // first grade of the row
    Console.Write($"{students[r],-8}");
    for (int c = 0; c < nExams; c++)
    {
        Console.Write($"{grades[r, c],9:F0}");
        rowSum += grades[r, c];
        if (grades[r, c] > rowMax)
        {
            rowMax = grades[r, c];
        }
    }
    double average = rowSum / nExams;
    Console.WriteLine($"{average,9:F2}{rowMax,6:F0}");
    if (average > topAverage)
    {
        topAverage = average;
        topStudent = r;
    }
}

// column averages: outer loop over the exams
Console.Write($"{"Average",-8}");
for (int c = 0; c < nExams; c++)
{
    double colSum = 0;
    for (int r = 0; r < nStudents; r++)
    {
        colSum += grades[r, c];
    }
    Console.Write($"{colSum / nStudents,9:F2}");
}
Console.WriteLine();
Console.Write($"Top student: {students[topStudent]}");
Console.WriteLine($" ({topAverage:F2})");
