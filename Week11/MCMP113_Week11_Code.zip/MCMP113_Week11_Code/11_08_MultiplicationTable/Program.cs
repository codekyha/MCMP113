// MCMP113 · Week 11 · Example 8 — Multiplication table stored in a matrix
// table[r, c] holds (r + 1) * (c + 1): index 0 stands for the number 1.

Console.Write("Size n (1-12): ");
int n = int.Parse(Console.ReadLine());

int[,] table = new int[n, n];
for (int r = 0; r < n; r++)
{
    for (int c = 0; c < n; c++)
    {
        table[r, c] = (r + 1) * (c + 1);
    }
}

// header row
Console.Write("   x|");
for (int c = 0; c < n; c++)
{
    Console.Write($"{c + 1,4}");
}
Console.WriteLine();

// one line per row, with the row number in front
for (int r = 0; r < n; r++)
{
    Console.Write($"{r + 1,4}|");
    for (int c = 0; c < n; c++)
    {
        Console.Write($"{table[r, c],4}");
    }
    Console.WriteLine();
}

// look-up: 7 x 8 is stored at [6, 7] (if the table is big enough)
if (n >= 8)
{
    Console.WriteLine($"7 x 8 = table[6, 7] = {table[6, 7]}");
}
