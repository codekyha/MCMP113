// MCMP113 · Week 11 · Example 9 — Cinema seat booking (char matrix)
// '.' = free, 'X' = sold. The user types row and seat numbers starting at 1; the array starts at 0.

char[,] seats = new char[5, 8];      // 5 rows, 8 seats per row
int rows = seats.GetLength(0);
int perRow = seats.GetLength(1);
for (int r = 0; r < rows; r++)
{
    for (int c = 0; c < perRow; c++)
    {
        seats[r, c] = '.';
    }
}
seats[2, 3] = 'X';                   // two seats already sold
seats[2, 4] = 'X';

Console.WriteLine($"Cinema: {rows} rows x {perRow} seats");
int row;
do
{
    Console.Write($"Row (1-{rows}, 0 = finish): ");
    row = int.Parse(Console.ReadLine());
    if (row != 0)
    {
        Console.Write($"Seat (1-{perRow}): ");
        int seat = int.Parse(Console.ReadLine());
        if (row < 1 || row > rows || seat < 1 || seat > perRow)
        {
            Console.WriteLine("  No such seat.");
        }
        else if (seats[row - 1, seat - 1] == 'X')   // number - 1 = index
        {
            Console.WriteLine("  Sorry, already sold.");
        }
        else
        {
            seats[row - 1, seat - 1] = 'X';
            Console.WriteLine($"  Booked: row {row}, seat {seat}.");
        }
    }
} while (row != 0);

// seat map with the screen at the top, and a count of free seats
Console.WriteLine("       S C R E E N");
Console.Write("    ");
for (int c = 0; c < perRow; c++)
{
    Console.Write($"{c + 1,2}");
}
Console.WriteLine();
int free = 0;
for (int r = 0; r < rows; r++)
{
    Console.Write($"Row{r + 1}");
    for (int c = 0; c < perRow; c++)
    {
        Console.Write($" {seats[r, c]}");
        if (seats[r, c] == '.')
        {
            free++;
        }
    }
    Console.WriteLine();
}
Console.WriteLine($"Free seats: {free} of {seats.Length}");
