// MCMP113 · Week 11 · Example 7 — Matrix multiplication
// C = A x B with A (m x n), B (n x p): C[i, j] = sum over k of A[i, k] * B[k, j]; C is m x p.

int[,] a =
{
    { 1, 2, 3 },
    { 4, 5, 6 },
};                                   // 2 x 3
int[,] b =
{
    { 7, 8 },
    { 9, 10 },
    { 11, 12 },
};                                   // 3 x 2

int m = a.GetLength(0);
int n = a.GetLength(1);
int p = b.GetLength(1);

if (n != b.GetLength(0))         // columns of A must = rows of B
{
    Console.WriteLine("A x B is not defined.");
}
else
{
    int[,] c = new int[m, p];        // result: m x p, starts at 0
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < p; j++)
        {
            for (int k = 0; k < n; k++)
            {
                // row i of A times column j of B
                c[i, j] += a[i, k] * b[k, j];
            }
        }
    }
    Console.WriteLine($"A ({m}x{n}) x B ({n}x{p}) = C ({m}x{p}):");
    for (int i = 0; i < m; i++)
    {
        for (int j = 0; j < p; j++)
        {
            Console.Write($"{c[i, j],6}");
        }
        Console.WriteLine();
    }
    Console.WriteLine($"Multiplications: {m * p * n}");
}
