// MCMP113 · Week 11 · Example 11 — A grey-scale image as a matrix of brightness values
// Brightness 0 (black) .. 9 (white); inverting means new = 9 - old. Real photos use 0 .. 255 the same way.

int[,] image =
{
    { 0, 6, 9, 6, 0, 6, 9, 6, 0 },
    { 6, 9, 9, 9, 6, 9, 9, 9, 6 },
    { 9, 9, 9, 9, 9, 9, 9, 9, 9 },
    { 3, 9, 9, 9, 9, 9, 9, 9, 3 },
    { 0, 3, 9, 9, 9, 9, 9, 3, 0 },
    { 0, 0, 3, 9, 9, 9, 3, 0, 0 },
    { 0, 0, 0, 3, 9, 3, 0, 0, 0 },
};
string shades = " .:-=+*#%@";            // shades[v] draws brightness v
int rows = image.GetLength(0);
int cols = image.GetLength(1);

// draw the image (each pixel twice, so it is not too narrow)
// and add up the brightness
int sum = 0;
Console.WriteLine("Original:");
for (int r = 0; r < rows; r++)
{
    for (int c = 0; c < cols; c++)
    {
        char ch = shades[image[r, c]];
        Console.Write($"{ch}{ch}");
        sum += image[r, c];
    }
    Console.WriteLine();
}
double average = (double)sum / image.Length;
Console.WriteLine($"Average brightness: {average:F2}");

// invert every pixel in place
for (int r = 0; r < rows; r++)
{
    for (int c = 0; c < cols; c++)
    {
        image[r, c] = 9 - image[r, c];
    }
}

Console.WriteLine("Inverted:");
for (int r = 0; r < rows; r++)
{
    for (int c = 0; c < cols; c++)
    {
        char ch = shades[image[r, c]];
        Console.Write($"{ch}{ch}");
    }
    Console.WriteLine();
}
