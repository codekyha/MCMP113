// MCMP113 · Week 11 · Example 1 — Matrix basics
// Declares a 2-D array, uses m[row, col] and GetLength, prints it as a grid.

int[,] m = new int[3, 4];        // 3 rows, 4 columns, all 0

m[0, 0] = 5;                     // row 0, column 0 (top-left)
m[1, 2] = 7;                     // row 1, column 2
m[2, 3] = 9;                     // row 2, column 3 (bottom-right)

int rows = m.GetLength(0);       // dimension 0 = rows
int cols = m.GetLength(1);       // dimension 1 = columns
Console.WriteLine($"rows = {rows}, cols = {cols}");
Console.WriteLine($"Length = {m.Length}, Rank = {m.Rank}");

// row-major traversal: outer loop = rows, inner loop = columns
for (int r = 0; r < rows; r++)
{
    for (int c = 0; c < cols; c++)
    {
        Console.Write($"{m[r, c],4}");   // width 4, right-aligned
    }
    Console.WriteLine();                 // end of one row
}

// initializer: the shape comes from the braces (2 rows, 3 columns)
int[,] small = { { 1, 2, 3 }, { 4, 5, 6 } };
Console.WriteLine($"small[1, 0] = {small[1, 0]}");

// foreach visits every element in row-major order
Console.Write("foreach:");
foreach (int x in small)
{
    Console.Write($" {x}");
}
Console.WriteLine();
