// MCMP113 · Week 11 · Example 12 — Pascal's triangle in a jagged array int[][]
// Row r has r + 1 elements: each row is its own 1-D array, so the rows have different lengths.

Console.Write("Number of rows: ");
int n = int.Parse(Console.ReadLine());

int[][] pascal = new int[n][];           // n rows, none created yet
for (int r = 0; r < n; r++)
{
    pascal[r] = new int[r + 1];          // row r gets r + 1 elements
    pascal[r][0] = 1;                    // first and last element are 1
    pascal[r][r] = 1;
    for (int c = 1; c < r; c++)
    {
        // sum of the two numbers above
        pascal[r][c] = pascal[r - 1][c - 1] + pascal[r - 1][c];
    }
}

// print as a triangle: 2 spaces of indent per missing row
for (int r = 0; r < n; r++)
{
    for (int s = 0; s < n - 1 - r; s++)
    {
        Console.Write("  ");
    }
    for (int c = 0; c < pascal[r].Length; c++)
    {
        Console.Write($"{pascal[r][c],4}");
    }
    Console.WriteLine();
}
Console.WriteLine($"Rows: {pascal.Length}");
Console.WriteLine($"Last row length: {pascal[n - 1].Length}");
