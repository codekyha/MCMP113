// MCMP113 · Week 11 · Example 6 — Matrix addition and scalar multiplication
// C = A + B only if A and B have the same size; k * A multiplies every element by k.

int[,] a =
{
    { 1, 2, 3 },
    { 4, 5, 6 },
};
int[,] b =
{
    { 10, 20, 30 },
    { -1, -2, -3 },
};
Console.Write("Scalar k = ");
int k = int.Parse(Console.ReadLine());

int rows = a.GetLength(0);
int cols = a.GetLength(1);

// addition: sizes must match exactly
if (rows != b.GetLength(0) || cols != b.GetLength(1))
{
    Console.WriteLine("A + B is not defined: different sizes.");
}
else
{
    int[,] sum = new int[rows, cols];
    for (int r = 0; r < rows; r++)
    {
        for (int c = 0; c < cols; c++)
        {
            sum[r, c] = a[r, c] + b[r, c];   // element by element
        }
    }
    Console.WriteLine("A + B =");
    for (int r = 0; r < rows; r++)
    {
        for (int c = 0; c < cols; c++)
        {
            Console.Write($"{sum[r, c],5}");
        }
        Console.WriteLine();
    }
}

// scalar multiplication: always defined
int[,] scaled = new int[rows, cols];
for (int r = 0; r < rows; r++)
{
    for (int c = 0; c < cols; c++)
    {
        scaled[r, c] = k * a[r, c];
    }
}
Console.WriteLine($"{k} * A =");
for (int r = 0; r < rows; r++)
{
    for (int c = 0; c < cols; c++)
    {
        Console.Write($"{scaled[r, c],5}");
    }
    Console.WriteLine();
}
