// MCMP113 · Week 11 · Example 2 — Read a matrix, row sums and column sums
// Reads rows x cols numbers from the keyboard, prints the grid with row sums, column sums and the total.

Console.Write("Rows: ");
int rows = int.Parse(Console.ReadLine());
Console.Write("Columns: ");
int cols = int.Parse(Console.ReadLine());

int[,] a = new int[rows, cols];
for (int r = 0; r < rows; r++)
{
    for (int c = 0; c < cols; c++)
    {
        Console.Write($"a[{r},{c}] = ");
        a[r, c] = int.Parse(Console.ReadLine());
    }
}

// each row, followed by its sum
int total = 0;
for (int r = 0; r < rows; r++)
{
    int rowSum = 0;          // reset for every row
    for (int c = 0; c < cols; c++)
    {
        Console.Write($"{a[r, c],5}");
        rowSum += a[r, c];
    }
    Console.WriteLine($"  | {rowSum,4}");
    total += rowSum;
}

// column sums: the OUTER loop runs over the columns
for (int c = 0; c < cols; c++)
{
    int colSum = 0;          // reset for every column
    for (int r = 0; r < rows; r++)
    {
        colSum += a[r, c];
    }
    Console.Write($"{colSum,5}");
}
Console.WriteLine($"  | {total,4}");
