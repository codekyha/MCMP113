# MCMP113 · Introduction to Basic Algorithms and Programming
## Week 11 — example code pack

Asst. Prof. Hasan Oğuz, PhD · Istanbul Okan University · 2026–2027 Fall

Every folder in this pack is a **separate, complete C# console project** (`.csproj` + `Program.cs`) for .NET 10.
All programs were built with 0 errors / 0 warnings and run with the sample inputs listed below.

### Getting started
1. Install the **.NET 10 SDK** (https://dotnet.microsoft.com/en-us/download/dotnet/10.0) and **Visual Studio Code** with the **C# Dev Kit** extension.
2. Unzip this pack, e.g. to `Documents\MCMP113\Week11`.
3. Run one example from a terminal:
   ```
   cd 11_01_MatrixBasics
   dotnet run
   ```
4. Or open the whole pack in VS Code (`File → Open Folder…`). The solution file `MCMP113_Week11_Code.sln` lists all projects; in the C# Dev Kit *Solution Explorer* right-click a project → *Debug → Start New Instance*.

### Notes
* Programs are written with **top-level statements** (no `class Program`/`Main` needed).
* The course project template turns off nullable warnings and uses **invariant culture**, so decimal numbers are typed with a **point** (`72.5`) even on Turkish-language Windows.
* Typing input: when a program waits, type a value and press **Enter**. Stop a running program with **Ctrl + C**.
* `bin/` and `obj/` folders are created automatically on the first build; you may delete them at any time.

---


Each folder is a separate .NET 10 console project (course template: Nullable disabled,
InvariantGlobalization on). Open the folder in VS Code and press Run, or type `dotnet run` inside it.
All programs were built with 0 errors / 0 warnings and run with the sample input below;
the transcripts on the slides and in the notes are real output of these runs.
Everything is written with top-level statements only (methods come in Week 12).

| Folder | What it shows | Sample input |
|---|---|---|
| `11_01_MatrixBasics` | `int[,]` declaration, `m[r, c]`, `GetLength(0/1)`, `Length`, `Rank`, row-major printing with `{x,4}`, initializer, `foreach` | — |
| `11_02_RowColumnSums` | Reading a rows × cols matrix from the keyboard; row sums (outer loop = rows), column sums (outer loop = columns), grand total | `2 3 4 7 1 2 5 8` |
| `11_03_GradeBook` | `double[,]` grade book (students × exams) with name arrays: row average, row maximum, column averages, top student | — |
| `11_04_Diagonals` | Main diagonal `r == c` / anti-diagonal `r + c == n − 1` marked in the grid, trace and anti-diagonal sum with one loop, identity matrix | — |
| `11_05_TransposeSymmetric` | Transpose `t[c, r] = a[r, c]` of a 2 × 3 matrix (sizes swapped); symmetric check visiting only the upper triangle | — |
| `11_06_AddScale` | Matrix addition with a size check, scalar multiplication `k · A` | `3` |
| `11_07_MatrixMultiply` | `C = A × B` with three nested loops, dimension check (cols of A = rows of B), multiplication count | — |
| `11_08_MultiplicationTable` | Multiplication table stored in an n × n matrix (`table[r, c] = (r + 1)(c + 1)`), header row/column, look-up `table[6, 7]` | `9` (also try `5`) |
| `11_09_CinemaBooking` | `char[,]` seat map, user numbers from 1 vs indices from 0, range check first, `do-while` with sentinel 0, free-seat count | `3 4 3 6 3 4 6 1 1 8 0` |
| `11_10_TicTacToe` | 3 × 3 `char` board, two players, invalid-move handling with `continue`, win check (3 rows, 3 columns, 2 diagonals), draw | win: `2 2 1 1 1 3 2 2 2 1 3 1`; draw: `1 1 2 2 1 2 1 3 3 1 2 1 2 3 3 2 3 3` |
| `11_11_ImageInvert` | Grey-scale image as a brightness matrix (0–9) drawn with characters, average brightness, in-place inversion `9 − v` | — |
| `11_12_PascalJagged` | Jagged array `int[][]`: Pascal's triangle, rows of different lengths, `pascal[r].Length` | `6` |

Inputs are typed one per line (spaces above separate the lines).
