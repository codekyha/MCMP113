// MCMP113 · Week 11 · Example 5 — Transpose and symmetric check
// The transpose swaps rows and columns: t[c, r] = a[r, c]. A square matrix is symmetric if s[r, c] == s[c, r].

int[,] a =
{
    { 1, 2, 3 },
    { 4, 5, 6 },
};
int rows = a.GetLength(0);           // 2
int cols = a.GetLength(1);           // 3

int[,] t = new int[cols, rows];      // 3 x 2: the sizes are swapped
for (int r = 0; r < rows; r++)
{
    for (int c = 0; c < cols; c++)
    {
        t[c, r] = a[r, c];           // row r of a becomes column r of t
    }
}

Console.WriteLine($"A ({rows} x {cols}):");
for (int r = 0; r < rows; r++)
{
    for (int c = 0; c < cols; c++)
    {
        Console.Write($"{a[r, c],4}");
    }
    Console.WriteLine();
}
Console.WriteLine($"Transpose ({cols} x {rows}):");
for (int r = 0; r < cols; r++)
{
    for (int c = 0; c < rows; c++)
    {
        Console.Write($"{t[r, c],4}");
    }
    Console.WriteLine();
}

// symmetric check: compare each element above the diagonal
// with its mirror image below the diagonal
int[,] s =
{
    { 1, 2, 3 },
    { 2, 5, 4 },
    { 3, 4, 6 },
};
int n = s.GetLength(0);
bool symmetric = true;
int checks = 0;
for (int r = 0; r < n; r++)
{
    for (int c = r + 1; c < n; c++)  // start right of the diagonal
    {
        checks++;
        if (s[r, c] != s[c, r])
        {
            symmetric = false;
        }
    }
}
Console.WriteLine($"S symmetric? {symmetric}  ({checks} comparisons)");
