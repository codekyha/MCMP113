// MCMP113 · Week 15 · Example 6 — Practice final Q6: three array methods, bugs fixed
// Count with a condition, linear search with early return, and a real copy (the original stays unchanged).

int[] numbers = { 4, 7, 10, 3, 8 };
Console.WriteLine($"Even: {CountEven(numbers)}");
Console.WriteLine($"Contains 7: {Contains(numbers, 7)}");      // fix 5: arguments in the declared order
Console.WriteLine($"Contains 5: {Contains(numbers, 5)}");
int[] doubled = Doubled(numbers);
Console.WriteLine("Original: " + string.Join(" ", numbers));
Console.WriteLine("Doubled:  " + string.Join(" ", doubled));

// Number of even elements
static int CountEven(int[] a)
{
    int count = 0;
    for (int i = 0; i < a.Length; i++)                         // fix 1: < instead of <=
    {
        if (a[i] % 2 == 0)
        {
            count++;
        }
    }
    return count;                                              // fix 2: return AFTER the loop
}

// true if target occurs in a (linear search)
static bool Contains(int[] a, int target)
{
    for (int i = 0; i < a.Length; i++)
    {
        if (a[i] == target)
        {
            return true;                                       // found: stop early
        }
    }
    return false;                                              // fix 3: "not found" only after the loop
}

// New array with every element doubled; a is not changed
static int[] Doubled(int[] a)
{
    int[] result = new int[a.Length];                          // fix 4: a new array, not a second name
    for (int i = 0; i < a.Length; i++)
    {
        result[i] = a[i] * 2;
    }
    return result;
}
