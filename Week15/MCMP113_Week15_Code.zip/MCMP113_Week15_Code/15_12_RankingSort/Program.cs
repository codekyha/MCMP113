// MCMP113 · Week 15 · Example 12 — Problem set P10: sort parallel arrays into a ranking
// Selection sort by score (high to low), equal scores by name (A to Z); both arrays are swapped together.

string[] names = { "Mert", "Ece", "Ali", "Selin", "Burak", "Deniz" };
int[] scores = { 78, 91, 78, 85, 91, 60 };

SortRanking(names, scores);

int rank = 0;
for (int i = 0; i < names.Length; i++)
{
    if (i == 0 || scores[i] != scores[i - 1])
    {
        rank = i + 1;                       // equal scores share a rank: 1 1 3 ...
    }
    Console.WriteLine($"{rank}. {names[i],-6} {scores[i],3}");
}

// true if student i must be listed before student j
static bool ComesBefore(string[] names, int[] scores, int i, int j)
{
    if (scores[i] != scores[j])
    {
        return scores[i] > scores[j];
    }
    return string.Compare(names[i], names[j], StringComparison.Ordinal) < 0;
}

// Selection sort on two parallel arrays (the arrays are changed in place)
static void SortRanking(string[] names, int[] scores)
{
    for (int i = 0; i < names.Length - 1; i++)
    {
        int first = i;
        for (int j = i + 1; j < names.Length; j++)
        {
            if (ComesBefore(names, scores, j, first))
            {
                first = j;
            }
        }
        SwapText(ref names[i], ref names[first]);
        SwapNumber(ref scores[i], ref scores[first]);
    }
}

// Swaps two strings
static void SwapText(ref string a, ref string b)
{
    string t = a;
    a = b;
    b = t;
}

// Swaps two integers
static void SwapNumber(ref int a, ref int b)
{
    int t = a;
    a = b;
    b = t;
}
