// MCMP113 · Week 15 · Example 15 — Problem set P14: three recursive methods with self-tests
// Each method has a base case that stops and a recursive step that makes the problem smaller.

Console.WriteLine($"Power(2, 10)  = {Power(2, 10)}");
Console.WriteLine($"Power(3, 0)   = {Power(3, 0)}");
int[] a = { 4, 8, 15, 16, 23, 42 };
Console.WriteLine($"SumArray(a, {a.Length}) = {SumArray(a, a.Length)}");
Console.WriteLine($"IsPalindrome(\"kayak\") = {IsPalindrome("kayak", 0, 4)}");

Check("Power(5, 3) == 125", Power(5, 3) == 125);
Check("Power(10, 1) == 10", Power(10, 1) == 10);
Check("SumArray(a, 0) == 0", SumArray(a, 0) == 0);
Check("SumArray(a, 3) == 27", SumArray(a, 3) == 27);
Check("IsPalindrome(\"level\")", IsPalindrome("level", 0, 4));
Check("!IsPalindrome(\"okan\")", !IsPalindrome("okan", 0, 3));
Check("IsPalindrome(\"a\")", IsPalindrome("a", 0, 0));

// b to the power e (e >= 0): b^e = b * b^(e-1), b^0 = 1
static long Power(long b, int e)
{
    if (e == 0)
    {
        return 1;
    }
    return b * Power(b, e - 1);
}

// Sum of the first n elements: sum(n) = sum(n-1) + a[n-1], sum(0) = 0
static int SumArray(int[] a, int n)
{
    if (n == 0)
    {
        return 0;
    }
    return SumArray(a, n - 1) + a[n - 1];
}

// true if s[lo..hi] reads the same in both directions
static bool IsPalindrome(string s, int lo, int hi)
{
    if (lo >= hi)
    {
        return true;                    // 0 or 1 character left
    }
    if (s[lo] != s[hi])
    {
        return false;
    }
    return IsPalindrome(s, lo + 1, hi - 1);
}

// Prints PASS or FAIL for one test
static void Check(string label, bool ok)
{
    Console.WriteLine($"{(ok ? "PASS" : "FAIL")}  {label}");
}
