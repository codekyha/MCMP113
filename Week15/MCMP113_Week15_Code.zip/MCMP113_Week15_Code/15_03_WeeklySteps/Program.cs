// MCMP113 · Week 15 · Example 3 — Review Q13: write the methods (weekly step counter)
// Arrays + methods: read 7 values with validation, then average, best day and days above average.

string[] days = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };
int[] steps = ReadSteps(days);

double average = Average(steps);
int best = IndexOfMax(steps);
int above = CountAbove(steps, average);
Console.WriteLine($"Average: {average:F1} steps");
Console.WriteLine($"Best day: {days[best]} ({steps[best]} steps)");
Console.WriteLine($"Days above average: {above}");

// Reads one non-negative value per day; repeats the prompt until the input is valid
static int[] ReadSteps(string[] dayNames)
{
    int[] values = new int[dayNames.Length];
    for (int i = 0; i < values.Length; i++)
    {
        int v;
        bool ok;
        do
        {
            Console.Write($"{dayNames[i]}: ");
            ok = int.TryParse(Console.ReadLine(), out v) && v >= 0;
            if (!ok)
            {
                Console.WriteLine("  Please enter a whole number >= 0.");
            }
        } while (!ok);
        values[i] = v;
    }
    return values;
}

// Average of the elements
static double Average(int[] a)
{
    int sum = 0;
    foreach (int x in a)
    {
        sum += x;
    }
    return (double)sum / a.Length;
}

// Index of the first largest element
static int IndexOfMax(int[] a)
{
    int best = 0;
    for (int i = 1; i < a.Length; i++)
    {
        if (a[i] > a[best])
        {
            best = i;
        }
    }
    return best;
}

// How many elements are strictly greater than limit
static int CountAbove(int[] a, double limit)
{
    int count = 0;
    foreach (int x in a)
    {
        if (x > limit)
        {
            count++;
        }
    }
    return count;
}
