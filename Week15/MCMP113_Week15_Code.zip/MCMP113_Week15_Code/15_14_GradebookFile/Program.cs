// MCMP113 · Week 15 · Example 14 — Problem set P12: CSV file -> matrix -> sorted ranking file
// Integrates files, string.Split, a double[,] matrix, methods and selection sort on parallel arrays.

const string InputFile = "gradebook.csv";
CreateSampleFile(InputFile);

try
{
    string[] lines = File.ReadAllLines(InputFile);
    int students = lines.Length - 1;                  // line 0 is the header
    int exams = lines[0].Split(',').Length - 1;
    string[] names = new string[students];
    double[,] scores = new double[students, exams];
    for (int r = 0; r < students; r++)
    {
        string[] f = lines[r + 1].Split(',');
        names[r] = f[0];
        for (int c = 0; c < exams; c++)
        {
            scores[r, c] = double.Parse(f[c + 1]);
        }
    }

    for (int c = 0; c < exams; c++)
    {
        Console.WriteLine($"Exam {c + 1} average: {ColumnAverage(scores, c):F2}");
    }

    double[] averages = new double[students];
    for (int r = 0; r < students; r++)
    {
        averages[r] = RowAverage(scores, r);
    }
    SortDescending(names, averages);                   // the matrix itself stays in file order

    using (StreamWriter w = new StreamWriter("ranking.txt"))
    {
        for (int i = 0; i < students; i++)
        {
            w.WriteLine($"{i + 1}. {names[i],-7} {averages[i],6:F2}");
        }
    }
    Console.WriteLine("--- ranking.txt ---");
    Console.Write(File.ReadAllText("ranking.txt"));
}
catch (FileNotFoundException)
{
    Console.WriteLine($"File not found: {InputFile}");
}
catch (FormatException)
{
    Console.WriteLine("The file contains a value that is not a number.");
}

// Writes the sample grade book: header + one line per student
static void CreateSampleFile(string path)
{
    File.WriteAllLines(path, new string[]
    {
        "name,exam1,exam2,exam3",
        "Ayşe,72,85,90",
        "Mehmet,45,58,62",
        "Zeynep,90,94,88",
        "Can,60,70,65",
        "Elif,38,51,47",
    });
}

// Average of row r (one student)
static double RowAverage(double[,] m, int r)
{
    double sum = 0;
    for (int c = 0; c < m.GetLength(1); c++)
    {
        sum += m[r, c];
    }
    return sum / m.GetLength(1);
}

// Average of column c (one exam)
static double ColumnAverage(double[,] m, int c)
{
    double sum = 0;
    for (int r = 0; r < m.GetLength(0); r++)
    {
        sum += m[r, c];
    }
    return sum / m.GetLength(0);
}

// Selection sort, highest value first; names are moved together with their values
static void SortDescending(string[] names, double[] values)
{
    for (int i = 0; i < values.Length - 1; i++)
    {
        int maxIndex = i;
        for (int j = i + 1; j < values.Length; j++)
        {
            if (values[j] > values[maxIndex])
            {
                maxIndex = j;
            }
        }
        (values[i], values[maxIndex]) = (values[maxIndex], values[i]);   // tuple swap (Week 10)
        (names[i], names[maxIndex]) = (names[maxIndex], names[i]);
    }
}
