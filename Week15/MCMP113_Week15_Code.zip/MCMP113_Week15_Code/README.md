# MCMP113 · Introduction to Basic Algorithms and Programming
## Week 15 — example code pack

Asst. Prof. Hasan Oğuz, PhD · Istanbul Okan University · 2026–2027 Fall

Every folder in this pack is a **separate, complete C# console project** (`.csproj` + `Program.cs`) for .NET 10.
All programs were built with 0 errors / 0 warnings and run with the sample inputs listed below.

### Getting started
1. Install the **.NET 10 SDK** (https://dotnet.microsoft.com/en-us/download/dotnet/10.0) and **Visual Studio Code** with the **C# Dev Kit** extension.
2. Unzip this pack, e.g. to `Documents\MCMP113\Week15`.
3. Run one example from a terminal:
   ```
   cd 15_01_PredictChecker
   dotnet run
   ```
4. Or open the whole pack in VS Code (`File → Open Folder…`). The solution file `MCMP113_Week15_Code.sln` lists all projects; in the C# Dev Kit *Solution Explorer* right-click a project → *Debug → Start New Instance*.

### Notes
* Programs are written with **top-level statements** (no `class Program`/`Main` needed).
* The course project template turns off nullable warnings and uses **invariant culture**, so decimal numbers are typed with a **point** (`72.5`) even on Turkish-language Windows.
* Typing input: when a program waits, type a value and press **Enter**. Stop a running program with **Ctrl + C**.
* `bin/` and `obj/` folders are created automatically on the first build; you may delete them at any time.

---


Each folder is a separate .NET 10 console project (course template: Nullable disabled,
InvariantGlobalization on). Open the folder in VS Code and press Run, or type `dotnet run` inside it.
All programs were built with 0 errors / 0 warnings and run with the sample input below;
the transcripts on the slides and in the notes are real output of these runs.
Methods are `static` local functions at the bottom of `Program.cs`, each with a one-line `//` comment.
No LINQ and no `List<T>`.

Programs that use files (15_04, 15_08, 15_13, 15_14) **create their input files themselves first**,
in the working directory (with `dotnet run`: the project folder). They have no external dependencies.

| Folder | What it shows | Sample input |
|---|---|---|
| `15_01_PredictChecker` | Runs every predict/trace snippet: deck Q1–Q2 and Q5–Q10, practice final Q1 (code items), Q2 (a)–(e), Q3, Q4(a), Q5(a), Q5(c), problem set P1–P5 and P13. Answer on paper first! (Q2(e) creates and deletes `t.txt`.) | none |
| `15_02_TempStatsFixed` | Review Q12: the "find the bugs" temperature program, corrected (loop bounds, real division, max starts with `a[0]`, value not index) | `-3 -7 -2 -1 -4` → -3.40, -1 |
| `15_03_WeeklySteps` | Review Q13: `ReadSteps` (TryParse validation), `Average`, `IndexOfMax`, `CountAbove` | `6500 8200 abc 7400 12050 9900 3100 10400` |
| `15_04_GradeReportCsv` | Review Q14: creates `grades.csv`, StreamReader + `using`, header skip, `Split`, field check, `FormatException`, writes `report.txt` | none |
| `15_05_ShopSales` | Practice final Q4(b): row totals and the best column of a matrix | none |
| `15_06_ArrayToolsFixed` | Practice final Q6: `CountEven`, `Contains`, `Doubled` with the five errors fixed | none |
| `15_07_TemperatureAnalysis` | Practice final Q7: `ReadIntInRange`, `ReadArray`, `Average`, `IndexOfMax`, `CountAbove`, `SortedCopy` (selection sort on a clone) | `0 6 14.5 18 9.5 21 17.5 12` |
| `15_08_SalesFile` | Practice final Q8: creates `sales.csv`, `File.ReadAllLines`, `decimal`, bad line skipped, `summary.txt` via StreamWriter, `FileNotFoundException` test with `missing.csv` | none |
| `15_09_ArrayDrills` | Problems P6, P7: `RemoveAll` (count, then fill a new array) and `LongestRun` (tuple) | none |
| `15_10_MagicSquare` | Problem P8: `RowSum`, `ColumnSum`, `IsMagic` for Lo Shu, a non-magic square and Dürer's 4 × 4 square | none |
| `15_11_LetterFrequency` | Problem P9: `int[26]` counting array with `ch - 'a'`, histogram, letters outside a–z | `Merhaba dünya, hello world!` |
| `15_12_RankingSort` | Problem P10: selection sort of parallel arrays (score desc, name asc), shared ranks, `ref` swaps | none |
| `15_13_LogFilter` | Problem P11: creates `app.log`, StreamReader/StreamWriter, `Array.IndexOf`, counts per level, `errors.txt` | none |
| `15_14_GradebookFile` | Problem P12 (★★★): CSV → `string[]` + `double[,]`, row/column averages, sorted ranking → `ranking.txt` | none |
| `15_15_RecursionPractice` | Problem P14: recursive `Power`, `SumArray`, `IsPalindrome` with PASS/FAIL self-tests | none |

Inputs are typed one per line (spaces above separate the lines).

Not in this folder: the buggy versions of review Q11/Q12 and practice-final Q5(b)/Q6 (Q11, Q5(b) and Q6
do not compile on purpose; Q12 compiles and crashes). The compiler messages and the crash quoted in the
notes (CS0103, CS0136, CS0165, CS0161, CS0029, CS8421, CS1503, CS0162, IndexOutOfRangeException) were
produced by building and running exactly the code printed in the slides/notes.
