// MCMP113 · Week 15 · Example 5 — Practice final Q4(b): row totals and the best column of a matrix
// sales[shop, quarter]: outer loop over rows for shop totals, outer loop over columns for quarter totals.

int[,] sales =
{
    { 120, 95, 140, 110 },
    { 80, 105, 90, 150 },
    { 150, 120, 100, 98 },
};
int shops = sales.GetLength(0);
int quarters = sales.GetLength(1);

// (1) total per shop = row sums
for (int s = 0; s < shops; s++)
{
    int shopTotal = 0;
    for (int q = 0; q < quarters; q++)
    {
        shopTotal += sales[s, q];
    }
    Console.WriteLine($"Shop {s + 1}: {shopTotal}");
}

// (2) best quarter = column with the largest column sum
int bestQuarter = 0;
int bestTotal = 0;
for (int q = 0; q < quarters; q++)
{
    int quarterTotal = 0;
    for (int s = 0; s < shops; s++)
    {
        quarterTotal += sales[s, q];
    }
    Console.WriteLine($"  Q{q + 1} total: {quarterTotal}");
    if (q == 0 || quarterTotal > bestTotal)
    {
        bestQuarter = q;
        bestTotal = quarterTotal;
    }
}
Console.WriteLine($"Best quarter: Q{bestQuarter + 1} ({bestTotal})");
