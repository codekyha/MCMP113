// MCMP113 · Week 15 · Example 8 — Practice final Q8: CSV sales file -> summary file
// Creates sales.csv, reads it with File.ReadAllLines, skips bad lines, writes summary.txt with StreamWriter.

CreateSalesFile("sales.csv");
Summarise("sales.csv", "summary.txt");
Console.WriteLine();
Summarise("missing.csv", "summary2.txt");          // test: the file does not exist

// Writes the sample sales data (header + 5 lines) into path
static void CreateSalesFile(string path)
{
    File.WriteAllLines(path, new string[]
    {
        "product,quantity,unitPrice",
        "Keyboard,3,450.00",
        "Mouse,two,150.00",
        "Monitor,2,3250.50",
        "USB cable,10,39.90",
        "Headset,1,899.99",
    });
}

// Reads the CSV file, prints problems, writes the totals into outPath and shows them
static void Summarise(string inPath, string outPath)
{
    try
    {
        string[] lines = File.ReadAllLines(inPath);
        decimal revenue = 0m;
        int items = 0;
        string bestProduct = "";
        decimal bestRevenue = -1m;
        for (int i = 1; i < lines.Length; i++)      // line 0 is the header
        {
            string[] f = lines[i].Split(',');
            try
            {
                int quantity = int.Parse(f[1]);
                decimal price = decimal.Parse(f[2]);
                decimal lineTotal = quantity * price;
                revenue += lineTotal;
                items += quantity;
                if (lineTotal > bestRevenue)
                {
                    bestRevenue = lineTotal;
                    bestProduct = f[0];
                }
            }
            catch (FormatException)
            {
                Console.WriteLine($"Skipped line {i + 1}: {lines[i]}");
            }
        }
        using (StreamWriter w = new StreamWriter(outPath))
        {
            w.WriteLine($"Items sold: {items}");
            w.WriteLine($"Revenue: {revenue:F2} TL");
            w.WriteLine($"Best product: {bestProduct} ({bestRevenue:F2} TL)");
        }
        Console.WriteLine($"--- {outPath} ---");
        Console.Write(File.ReadAllText(outPath));
    }
    catch (FileNotFoundException)
    {
        Console.WriteLine($"Error: {inPath} was not found.");
    }
}
