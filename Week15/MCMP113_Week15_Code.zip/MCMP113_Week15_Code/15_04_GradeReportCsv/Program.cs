// MCMP113 · Week 15 · Example 4 — Review Q14: read a CSV file, write a report file
// The program first creates grades.csv itself, then reads it line by line with StreamReader.

const string InputFile = "grades.csv";
const string ReportFile = "report.txt";
CreateSampleFile(InputFile);

int count = 0;
double sum = 0;
try
{
    using (StreamReader reader = new StreamReader(InputFile))
    using (StreamWriter writer = new StreamWriter(ReportFile))
    {
        reader.ReadLine();                      // skip the header line
        string line;
        while ((line = reader.ReadLine()) != null)
        {
            string[] parts = line.Split(',');
            if (parts.Length != 3)
            {
                Console.WriteLine($"Skipped (3 fields expected): {line}");
                continue;
            }
            try
            {
                double total = Total(parts[1], parts[2]);
                string result = total >= 50 ? "PASS" : "FAIL";
                writer.WriteLine($"{parts[0],-8}{total,7:F2}  {result}");
                count++;
                sum += total;
            }
            catch (FormatException)
            {
                Console.WriteLine($"Skipped (not a number): {line}");
            }
        }
    }
}
catch (FileNotFoundException)
{
    Console.WriteLine($"File not found: {InputFile}");
}
PrintSummary(count, sum, ReportFile);

// Writes the sample data (header + one line per student) into path
static void CreateSampleFile(string path)
{
    string[] lines =
    {
        "name,midterm,final",
        "Ayşe,72,85",
        "Mehmet,45,58",
        "Zeynep,90,94",
        "Can,6O,70",
        "Deniz,80",
        "Elif,38,51",
    };
    File.WriteAllLines(path, lines);
}

// Course total: 40 % midterm + 60 % final; int.Parse throws FormatException for a bad number
static double Total(string mid, string fin)
{
    return 0.4 * int.Parse(mid)
         + 0.6 * int.Parse(fin);
}

// Prints the number of students, the class average and the report file
static void PrintSummary(int count, double sum, string path)
{
    if (count == 0)
    {
        Console.WriteLine("No valid lines.");
        return;
    }
    double avg = sum / count;
    Console.WriteLine($"Students: {count}");
    Console.WriteLine($"Average: {avg:F2}");
    Console.WriteLine($"--- {path} ---");
    Console.Write(File.ReadAllText(path));
}
