// MCMP113 · Week 15 · Example 2 — Review Q12: the "find the bugs" temperature program, corrected
// Read 5 daily temperatures into an array; print the average and the highest with two methods.

int[] temps = new int[5];
for (int i = 0; i < temps.Length; i++)          // fix 1: indices 0 .. Length - 1
{
    Console.Write($"Day {i + 1}: ");
    temps[i] = int.Parse(Console.ReadLine());
}
Console.WriteLine($"Average: {Average(temps):F2}");
Console.WriteLine($"Highest: {Highest(temps)}");

// Average of the elements (real division)
static double Average(int[] a)
{
    int sum = 0;
    foreach (int t in a)
    {
        sum += t;
    }
    return (double)sum / a.Length;               // fix 2: no integer division
}

// Largest element (best-so-far pattern)
static int Highest(int[] a)
{
    int max = a[0];                              // fix 3: start with the first element, not 0
    for (int i = 1; i < a.Length; i++)
    {
        if (a[i] > max)
        {
            max = a[i];                          // fix 4: store the value, not the index
        }
    }
    return max;
}
