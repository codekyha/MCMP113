// MCMP113 · Week 15 · Example 13 — Problem set P11: filter a log file
// Creates app.log, counts the lines per level and copies the ERROR lines (with line numbers) to errors.txt.

string[] levels = { "INFO", "WARN", "ERROR" };
int[] counts = new int[levels.Length];          // parallel to levels

CreateLog("app.log");

using (StreamReader reader = new StreamReader("app.log"))
using (StreamWriter writer = new StreamWriter("errors.txt"))
{
    string line;
    int lineNo = 0;
    while ((line = reader.ReadLine()) != null)
    {
        lineNo++;
        string[] parts = line.Split(' ');       // date, time, level, message...
        int k = Array.IndexOf(levels, parts[2]);
        if (k >= 0)
        {
            counts[k]++;
        }
        if (parts[2] == "ERROR")
        {
            writer.WriteLine($"{lineNo,3}: {line}");
        }
    }
}

for (int i = 0; i < levels.Length; i++)
{
    Console.WriteLine($"{levels[i],-5} {counts[i]}");
}
Console.WriteLine("--- errors.txt ---");
foreach (string e in File.ReadAllLines("errors.txt"))
{
    Console.WriteLine(e);
}

// Writes a small sample log (date time LEVEL message)
static void CreateLog(string path)
{
    string[] lines =
    {
        "2026-12-14 09:15 INFO Server started",
        "2026-12-14 09:16 INFO User ayse logged in",
        "2026-12-14 09:20 WARN Disk 85% full",
        "2026-12-14 09:21 ERROR Cannot open grades.csv",
        "2026-12-14 09:25 INFO User mehmet logged in",
        "2026-12-14 09:30 ERROR Division by zero in report",
        "2026-12-14 09:31 WARN Slow response (2.4 s)",
        "2026-12-14 09:40 INFO Backup finished",
    };
    File.WriteAllLines(path, lines);
}
