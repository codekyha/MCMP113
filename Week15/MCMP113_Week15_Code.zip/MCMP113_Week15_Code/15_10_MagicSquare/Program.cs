// MCMP113 · Week 15 · Example 10 — Problem set P8: is the matrix a magic square?
// Every row, every column and both diagonals must have the same sum.

int[,] loShu = { { 2, 7, 6 }, { 9, 5, 1 }, { 4, 3, 8 } };
int[,] swapped = { { 2, 7, 6 }, { 9, 5, 1 }, { 4, 8, 3 } };
int[,] durer =
{
    { 16, 3, 2, 13 },
    { 5, 10, 11, 8 },
    { 9, 6, 7, 12 },
    { 4, 15, 14, 1 },
};

Report("Lo Shu", loShu);
Report("Swapped", swapped);
Report("Durer", durer);

// Prints the matrix and the verdict
static void Report(string name, int[,] m)
{
    Console.WriteLine($"{name}:");
    for (int r = 0; r < m.GetLength(0); r++)
    {
        for (int c = 0; c < m.GetLength(1); c++)
        {
            Console.Write($"{m[r, c],4}");
        }
        Console.WriteLine();
    }
    if (IsMagic(m))
    {
        Console.WriteLine($"  magic, every sum = {RowSum(m, 0)}");
    }
    else
    {
        Console.WriteLine("  not magic");
    }
}

// true if all rows, columns and both diagonals of the square matrix m have the same sum
static bool IsMagic(int[,] m)
{
    int n = m.GetLength(0);
    int target = RowSum(m, 0);
    int diag = 0, anti = 0;
    for (int i = 0; i < n; i++)
    {
        if (RowSum(m, i) != target || ColumnSum(m, i) != target)
        {
            return false;
        }
        diag += m[i, i];
        anti += m[i, n - 1 - i];
    }
    return diag == target && anti == target;
}

// Sum of row r
static int RowSum(int[,] m, int r)
{
    int sum = 0;
    for (int c = 0; c < m.GetLength(1); c++)
    {
        sum += m[r, c];
    }
    return sum;
}

// Sum of column c
static int ColumnSum(int[,] m, int c)
{
    int sum = 0;
    for (int r = 0; r < m.GetLength(0); r++)
    {
        sum += m[r, c];
    }
    return sum;
}
