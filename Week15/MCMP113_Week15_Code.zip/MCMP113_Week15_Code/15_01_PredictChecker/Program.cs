// MCMP113 · Week 15 · Example 1 — Predict-the-output checker for the final review
// Runs every predict / trace snippet of the review deck, the practice final and the problem set.
// Answer each question on paper FIRST, then run this program to check yourself.

Console.WriteLine("===== Deck Q1-Q4: multiple choice (code items) =====");
{
    double[] t = new double[4];
    try
    {
        Console.WriteLine(t[4]);
    }
    catch (IndexOutOfRangeException ex)
    {
        Console.WriteLine("Q1: " + ex.Message);
    }
    int[,] m = new int[3, 5];
    Console.WriteLine($"Q2: m.GetLength(1) = {m.GetLength(1)}");
}

Console.WriteLine("===== Deck Q5: arrays =====");
{
    int[] a = { 4, 7, 1, 9, 3 };
    int[] b = a;
    b[0] = 10;
    Console.WriteLine(a[0]);
    Console.WriteLine(a[a.Length - 1]);
    Console.WriteLine(a[a[2]]);
    int sum = 0;
    for (int i = 1; i < a.Length; i += 2)
    {
        sum += a[i];
    }
    Console.WriteLine(sum);
    int[] c = (int[])a.Clone();
    c[1] = 0;
    Console.WriteLine(string.Join(",", a));
    Console.WriteLine(a == c);
}

Console.WriteLine("===== Deck Q6: bubble sort, pass by pass =====");
{
    int[] a = { 4, 2, 7, 1, 9, 5 };
    int n = a.Length;
    int comparisons = 0, swaps = 0;
    for (int pass = 1; pass <= n - 1; pass++)
    {
        bool swapped = false;
        int passSwaps = 0;
        for (int j = 0; j < n - pass; j++)
        {
            comparisons++;
            if (a[j] > a[j + 1])
            {
                int temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
                swapped = true;
                swaps++;
                passSwaps++;
            }
        }
        Console.WriteLine($"Pass {pass}: {string.Join(" ", a)}   swaps: {passSwaps}");
        if (!swapped)
        {
            break;
        }
    }
    Console.WriteLine($"Comparisons: {comparisons}, swaps: {swaps}");
}

Console.WriteLine("===== Deck Q7: binary search trace =====");
{
    int[] a = { 3, 8, 11, 15, 19, 24, 30, 36, 41, 47, 52 };
    int[] targets = { 47, 12 };
    foreach (int target in targets)
    {
        Console.WriteLine($"target = {target}");
        int low = 0, high = a.Length - 1, index = -1, step = 0;
        while (low <= high && index == -1)
        {
            int mid = (low + high) / 2;
            step++;
            Console.WriteLine($"  step {step}: low={low} high={high} mid={mid} a[mid]={a[mid]}");
            if (a[mid] == target)
            {
                index = mid;
            }
            else if (a[mid] < target)
            {
                low = mid + 1;
            }
            else
            {
                high = mid - 1;
            }
        }
        Console.WriteLine($"  result: index {index}, steps {step}, final low={low} high={high}");
    }
}

Console.WriteLine("===== Deck Q8: matrix loops =====");
{
    int[,] m = { { 2, 7, 1 }, { 5, 3, 8 }, { 4, 6, 9 } };
    int n = m.GetLength(0);
    for (int r = 0; r < n; r++)
    {
        for (int c = 0; c < n; c++)
        {
            if (r > c)
            {
                Console.Write("  .");
            }
            else
            {
                Console.Write($"{m[r, c],3}");
            }
        }
        Console.WriteLine();
    }
    int diag = 0, anti = 0;
    for (int i = 0; i < n; i++)
    {
        diag += m[i, i];
        anti += m[i, n - 1 - i];
    }
    Console.WriteLine($"{diag} {anti}");
}

Console.WriteLine("===== Deck Q9: value, ref and array parameters =====");
{
    int x = 5, y = 5;
    int[] arr = { 5, 5 };
    Bump(x);
    BumpRef(ref y);
    BumpArray(arr);
    Replace(arr);
    Console.WriteLine($"{x} {y} {arr[0]} {arr[1]}");
    int z = Twice(x) + Twice(Twice(1));
    Console.WriteLine(z);
}

Console.WriteLine("===== Deck Q10: recursion =====");
{
    Console.WriteLine(Mystery(6));
    Console.WriteLine($"calls of Mystery for n = 6: {MysteryCalls(6)}");
    Countdown(3);
    Console.WriteLine();
}

Console.WriteLine("===== Practice final Q1 (code items) =====");
{
    int n = 6, comparisons = 0;
    for (int pass = 1; pass <= n - 1; pass++)
    {
        for (int j = 0; j < n - pass; j++)
        {
            comparisons++;
        }
    }
    Console.WriteLine($"1.4: bubble sort comparisons for 6 elements (no early exit): {comparisons}");
    int[,] m = new int[2, 3];
    Console.WriteLine($"1.5: m.Length = {m.Length}");
    bool[] flags = new bool[3];
    Console.WriteLine($"1.2: new bool[3] -> {string.Join(" ", flags)}");
    string[] parts = "Ali,85,90".Split(',');
    Console.WriteLine($"1.9: {parts.Length} {parts[1]}");
}

Console.WriteLine("===== Practice final Q2 =====");
{
    // (a)
    int[] a = { 2, 4, 6, 8, 10 };
    for (int i = 0; i < a.Length; i++)
    {
        int t = a[i];
        a[i] = a[a.Length - 1 - i];
        a[a.Length - 1 - i] = t;
    }
    Console.WriteLine(string.Join(" ", a));

    // (b)
    string w = "level up";
    int count = 0;
    for (int i = 0; i < w.Length; i++)
    {
        if (w[i] == 'e' || w[i] == 'u')
        {
            count++;
        }
    }
    Console.WriteLine($"{w.Length} {count} {w[w.Length - 1]}");

    // (c)
    int[] data = { 3, 1, 3, 0, 2, 3, 1 };
    int[] freq = new int[4];
    foreach (int d in data)
    {
        freq[d]++;
    }
    Console.WriteLine(string.Join(",", freq));

    // (d)
    (int lo, int hi) = MinMax(new int[] { 7, -2, 9, 4 });
    Console.WriteLine($"{lo} {hi}");
    Console.WriteLine(Clamp(15, 0, 10) + Clamp(-3, 0, 10));

    // (e)
    File.WriteAllText("t.txt", "a\nb\n");
    File.AppendAllText("t.txt", "c\n");
    string[] lines = File.ReadAllLines("t.txt");
    Console.WriteLine($"{lines.Length} {lines[lines.Length - 1]}");
    File.WriteAllLines("t.txt", new string[] { "x" });
    Console.WriteLine(File.ReadAllLines("t.txt").Length);
    File.Delete("t.txt");               // tidy up the checker's own file
}

Console.WriteLine("===== Practice final Q3: selection sort =====");
{
    int[] a = { 29, 10, 14, 37, 13 };
    int n = a.Length, comparisons = 0, swaps = 0;
    for (int i = 0; i < n - 1; i++)
    {
        int minIndex = i;
        for (int j = i + 1; j < n; j++)
        {
            comparisons++;
            if (a[j] < a[minIndex])
            {
                minIndex = j;
            }
        }
        if (minIndex != i)
        {
            int temp = a[i];
            a[i] = a[minIndex];
            a[minIndex] = temp;
            swaps++;
        }
        Console.WriteLine($"Pass {i + 1}: {string.Join(" ", a)}   (minIndex = {minIndex})");
    }
    Console.WriteLine($"Comparisons: {comparisons}, swaps: {swaps}");
}

Console.WriteLine("===== Practice final Q4(a): matrix =====");
{
    int rows = 3, cols = 4;
    int[,] g = new int[rows, cols];
    for (int r = 0; r < rows; r++)
    {
        for (int c = 0; c < cols; c++)
        {
            g[r, c] = r * cols + c;
        }
    }
    Console.WriteLine(g[2, 1]);
    Console.WriteLine(g.Length);
    for (int c = 0; c < cols; c++)
    {
        Console.Write(g[1, c] % 3 + " ");
    }
    Console.WriteLine();
    int s = 0;
    for (int r = 0; r < rows; r++)
    {
        s += g[r, cols - 1];
    }
    Console.WriteLine(s);
}

Console.WriteLine("===== Practice final Q5(a): parameters =====");
{
    int a = 3;
    int[] v = { 1, 2, 3 };
    Change(a, v);
    Console.WriteLine($"{a} {string.Join(",", v)}");
    Swap(ref v[0], ref v[2]);
    Console.WriteLine(string.Join(",", v));
    int b = Next(ref a) + Next(ref a);
    Console.WriteLine($"{a} {b}");
}

Console.WriteLine("===== Practice final Q5(c): recursion =====");
{
    Console.WriteLine($"G(4, 3) = {G(4, 3)}");
    Console.WriteLine($"G(7, 0) = {G(7, 0)}");
}

Console.WriteLine("===== Problem set P1 =====");
{
    int[] a = new int[6];
    for (int i = 0; i < a.Length; i++)
    {
        a[i] = i * i % 5;
    }
    Console.WriteLine(string.Join(" ", a));
    int k = 0;
    while (k < a.Length && a[k] != 4)
    {
        k++;
    }
    Console.WriteLine(k);
}

Console.WriteLine("===== Problem set P2: linear search =====");
{
    int[] a = { 12, 5, 8, 21, 5, 30 };
    int[] targets = { 5, 21, 7 };
    foreach (int target in targets)
    {
        int index = -1, checks = 0;
        for (int i = 0; i < a.Length && index == -1; i++)
        {
            checks++;
            if (a[i] == target)
            {
                index = i;
            }
        }
        int occurrences = 0;
        foreach (int x in a)
        {
            if (x == target)
            {
                occurrences++;
            }
        }
        Console.WriteLine($"target {target}: first index {index}, comparisons {checks}, occurrences {occurrences}");
    }
}

Console.WriteLine("===== Problem set P3: column by column =====");
{
    int[,] m = { { 1, 2, 3 }, { 4, 5, 6 } };
    for (int c = 0; c < m.GetLength(1); c++)
    {
        for (int r = m.GetLength(0) - 1; r >= 0; r--)
        {
            Console.Write(m[r, c] + " ");
        }
    }
    Console.WriteLine();
}

Console.WriteLine("===== Problem set P4: worst-case binary search steps =====");
{
    int[] sizes = { 15, 100, 1000, 1000000 };
    foreach (int size in sizes)
    {
        // simulate the worst case: the remaining range keeps the larger half
        int low = 0, high = size - 1, steps = 0;
        while (low <= high)
        {
            int mid = (low + high) / 2;
            steps++;
            low = mid + 1;              // target bigger than every element
        }
        Console.WriteLine($"n = {size}: {steps} steps (linear search: {size})");
    }
}

Console.WriteLine("===== Problem set P5: recursion =====");
{
    PrintBinary(13);
    Console.WriteLine();
    Console.WriteLine(Digits(2026));
    Console.WriteLine(Digits(7));
}

Console.WriteLine("===== Problem set P13: value vs ref =====");
{
    int n = 1;
    for (int i = 0; i < 3; i++)
    {
        n = AddTwice(n);
    }
    Console.WriteLine(n);
    int m = 1;
    Grow(m);
    GrowRef(ref m);
    GrowRef(ref m);
    Console.WriteLine(m);
}

// ---------- methods used by the snippets ----------

// value parameter: changes only the copy
static void Bump(int v)
{
    v++;
}

// ref parameter: v is another name for the caller's variable
static void BumpRef(ref int v)
{
    v++;
}

// array parameter: the reference is copied, the elements are shared
static void BumpArray(int[] a)
{
    a[0]++;
}

// reassigning the parameter does not affect the caller's array
static void Replace(int[] a)
{
    a = new int[] { 0, 0 };
    a[1] = 99;
}

// returns two times v
static int Twice(int v)
{
    return 2 * v;
}

// builds the binary digits of n as a decimal-looking number
static int Mystery(int n)
{
    if (n == 0)
    {
        return 0;
    }
    return n % 2 + 10 * Mystery(n / 2);
}

// counts how many calls Mystery(n) makes in total
static int MysteryCalls(int n)
{
    if (n == 0)
    {
        return 1;
    }
    return 1 + MysteryCalls(n / 2);
}

// prints n before and after the recursive call
static void Countdown(int n)
{
    if (n == 0)
    {
        return;
    }
    Console.Write(n + " ");
    Countdown(n - 1);
    Console.Write(n + " ");
}

// smallest and largest element as a tuple
static (int min, int max) MinMax(int[] a)
{
    int min = a[0], max = a[0];
    foreach (int x in a)
    {
        if (x < min)
        {
            min = x;
        }
        if (x > max)
        {
            max = x;
        }
    }
    return (min, max);
}

// keeps v inside the range lo..hi
static int Clamp(int v, int lo, int hi)
{
    if (v < lo)
    {
        return lo;
    }
    if (v > hi)
    {
        return hi;
    }
    return v;
}

// x is a copy; arr is a copy of the reference
static void Change(int x, int[] arr)
{
    x = x * 10;
    arr[0] = x;
    arr = new int[] { 0, 0, 0 };
    arr[1] = 99;
}

// swaps the caller's two variables
static void Swap(ref int p, ref int q)
{
    int t = p;
    p = q;
    q = t;
}

// increases the caller's variable and returns the new value
static int Next(ref int n)
{
    n++;
    return n;
}

// a * b by repeated addition (recursive)
static int G(int a, int b)
{
    if (b == 0)
    {
        return 0;
    }
    return a + G(a, b - 1);
}

// prints n in binary: first the higher digits, then the last one
static void PrintBinary(int n)
{
    if (n > 0)
    {
        PrintBinary(n / 2);
        Console.Write(n % 2);
    }
}

// number of decimal digits of n >= 0
static int Digits(int n)
{
    if (n < 10)
    {
        return 1;
    }
    return 1 + Digits(n / 10);
}

// returns v + v (the caller decides what to do with it)
static int AddTwice(int v)
{
    v = v + v;
    return v;
}

// multiplies its own copy by 3
static void Grow(int v)
{
    v *= 3;
}

// multiplies the caller's variable by 3
static void GrowRef(ref int v)
{
    v *= 3;
}
