// MCMP113 · Week 15 · Example 11 — Problem set P9: letter frequency with an int[26] counting array
// The index of a letter is ch - 'a' (a -> 0, b -> 1, ..., z -> 25).

Console.Write("Text: ");
string text = Console.ReadLine();

int[] counts = CountLetters(text, out int others);
int best = 0;
for (int i = 0; i < 26; i++)
{
    if (counts[i] > 0)
    {
        char letter = (char)('a' + i);
        Console.WriteLine($"{letter} {counts[i],2} {new string('*', counts[i])}");
    }
    if (counts[i] > counts[best])
    {
        best = i;
    }
}
Console.WriteLine($"Most frequent: {(char)('a' + best)} ({counts[best]} times)");
Console.WriteLine($"Other letters (not a-z): {others}");

// Counts a..z (ignoring case) in s; letters outside a..z (e.g. ü, ş) are counted in others
static int[] CountLetters(string s, out int others)
{
    int[] counts = new int[26];
    others = 0;
    foreach (char ch in s.ToLower())
    {
        if (ch >= 'a' && ch <= 'z')
        {
            counts[ch - 'a']++;
        }
        else if (char.IsLetter(ch))
        {
            others++;
        }
    }
    return counts;
}
