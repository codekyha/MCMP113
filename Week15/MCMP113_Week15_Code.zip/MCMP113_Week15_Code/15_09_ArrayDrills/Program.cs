// MCMP113 · Week 15 · Example 9 — Problem set P6 and P7: two array methods
// RemoveAll: count first, then fill a new shorter array. LongestRun: longest block of equal neighbours.

int[] data = { 3, 5, 5, 2, 5, 5, 5, 1, 1 };
Console.WriteLine("data:          " + string.Join(" ", data));
Console.WriteLine("without 5:     " + Show(RemoveAll(data, 5)));
Console.WriteLine("without 9:     " + Show(RemoveAll(data, 9)));
Console.WriteLine("{7, 7} - 7:    " + Show(RemoveAll(new int[] { 7, 7 }, 7)));

(int value, int length) = LongestRun(data);
Console.WriteLine($"longest run:   {value} x {length}");
(value, length) = LongestRun(new int[] { 4, 8, 6 });
Console.WriteLine($"no repeats:    {value} x {length}");

// New array that contains every element of a except the ones equal to x
static int[] RemoveAll(int[] a, int x)
{
    int keep = 0;
    foreach (int v in a)                    // pass 1: how big must the result be?
    {
        if (v != x)
        {
            keep++;
        }
    }
    int[] result = new int[keep];
    int w = 0;                              // write index into result
    foreach (int v in a)                    // pass 2: copy the kept values
    {
        if (v != x)
        {
            result[w] = v;
            w++;
        }
    }
    return result;
}

// Value and length of the longest block of equal neighbouring elements (first one wins a tie)
static (int value, int length) LongestRun(int[] a)
{
    int bestValue = a[0], bestLength = 1;
    int runLength = 1;
    for (int i = 1; i < a.Length; i++)
    {
        if (a[i] == a[i - 1])
        {
            runLength++;
        }
        else
        {
            runLength = 1;
        }
        if (runLength > bestLength)
        {
            bestLength = runLength;
            bestValue = a[i];
        }
    }
    return (bestValue, bestLength);
}

// Array as text, or "(empty)"
static string Show(int[] a)
{
    if (a.Length == 0)
    {
        return "(empty)";
    }
    return string.Join(" ", a);
}
