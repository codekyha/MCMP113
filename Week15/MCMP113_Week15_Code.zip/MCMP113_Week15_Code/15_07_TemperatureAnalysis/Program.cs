// MCMP113 · Week 15 · Example 7 — Practice final Q7: arrays + methods (temperature analysis)
// Read n temperatures, then average, hottest day, days above average and a sorted copy.

int n = ReadIntInRange("Number of days (1-31): ", 1, 31);
double[] temps = ReadArray(n);

double average = Average(temps);
int hottest = IndexOfMax(temps);
double[] sorted = SortedCopy(temps);

Console.WriteLine($"Average: {average:F2}");
Console.WriteLine($"Hottest: day {hottest + 1} ({temps[hottest]:F1})");
Console.WriteLine($"Days above average: {CountAbove(temps, average)}");
Console.WriteLine("Sorted:   " + string.Join(" ", sorted));
Console.WriteLine("Original: " + string.Join(" ", temps));

// Reads a whole number between min and max; asks again until the input is valid
static int ReadIntInRange(string prompt, int min, int max)
{
    int value;
    bool ok;
    do
    {
        Console.Write(prompt);
        ok = int.TryParse(Console.ReadLine(), out value) && value >= min && value <= max;
    } while (!ok);
    return value;
}

// Reads n real numbers into a new array
static double[] ReadArray(int n)
{
    double[] a = new double[n];
    for (int i = 0; i < n; i++)
    {
        Console.Write($"Day {i + 1}: ");
        a[i] = double.Parse(Console.ReadLine());
    }
    return a;
}

// Average of the elements
static double Average(double[] a)
{
    double sum = 0;
    foreach (double x in a)
    {
        sum += x;
    }
    return sum / a.Length;
}

// Index of the first largest element
static int IndexOfMax(double[] a)
{
    int best = 0;
    for (int i = 1; i < a.Length; i++)
    {
        if (a[i] > a[best])
        {
            best = i;
        }
    }
    return best;
}

// Number of elements greater than limit
static int CountAbove(double[] a, double limit)
{
    int count = 0;
    foreach (double x in a)
    {
        if (x > limit)
        {
            count++;
        }
    }
    return count;
}

// Sorted (ascending) copy made with selection sort; a itself is not changed
static double[] SortedCopy(double[] a)
{
    double[] b = (double[])a.Clone();
    for (int i = 0; i < b.Length - 1; i++)
    {
        int minIndex = i;
        for (int j = i + 1; j < b.Length; j++)
        {
            if (b[j] < b[minIndex])
            {
                minIndex = j;
            }
        }
        double temp = b[i];
        b[i] = b[minIndex];
        b[minIndex] = temp;
    }
    return b;
}
