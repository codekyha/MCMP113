// MCMP113 · Week 5 · Example 5 — Letter grade
// Demonstrates: an else-if ladder, the same logic as a switch expression, and a switch on a string.
// Example scale only; the official cut-offs are in the university regulation.
Console.Write("Enter the score (0-100): ");
if (!int.TryParse(Console.ReadLine(), out int score) || score < 0 || score > 100)
{
    Console.WriteLine("Error: the score must be a whole number from 0 to 100.");
    return;
}

// Version 1: else-if ladder. Order matters: test the highest band first.
string letter;
if (score >= 90)
{
    letter = "AA";
}
else if (score >= 85)
{
    letter = "BA";
}
else if (score >= 80)
{
    letter = "BB";
}
else if (score >= 75)
{
    letter = "CB";
}
else if (score >= 70)
{
    letter = "CC";
}
else if (score >= 65)
{
    letter = "DC";
}
else if (score >= 60)
{
    letter = "DD";
}
else
{
    letter = "FF";
}

// Version 2: switch expression with relational patterns (C# 9). First matching arm wins.
string letter2 = score switch
{
    >= 90 => "AA",
    >= 85 => "BA",
    >= 80 => "BB",
    >= 75 => "CB",
    >= 70 => "CC",
    >= 65 => "DC",
    >= 60 => "DD",
    _ => "FF"
};

// Grade point on the 4-point scale: switch expression on a string.
double point = letter switch
{
    "AA" => 4.0,
    "BA" => 3.5,
    "BB" => 3.0,
    "CB" => 2.5,
    "CC" => 2.0,
    "DC" => 1.5,
    "DD" => 1.0,
    _ => 0.0
};

Console.WriteLine($"Score {score} -> {letter} (grade point {point:F1})");
Console.WriteLine($"Ladder: {letter}   Switch expression: {letter2}");
