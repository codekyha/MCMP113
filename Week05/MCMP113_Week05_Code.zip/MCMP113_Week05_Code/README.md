# MCMP113 · Introduction to Basic Algorithms and Programming
## Week 5 — example code pack

Asst. Prof. Hasan Oğuz, PhD · Istanbul Okan University · 2026–2027 Fall

Every folder in this pack is a **separate, complete C# console project** (`.csproj` + `Program.cs`) for .NET 10.
All programs were built with 0 errors / 0 warnings and run with the sample inputs listed below.

### Getting started
1. Install the **.NET 10 SDK** (https://dotnet.microsoft.com/en-us/download/dotnet/10.0) and **Visual Studio Code** with the **C# Dev Kit** extension.
2. Unzip this pack, e.g. to `Documents\MCMP113\Week05`.
3. Run one example from a terminal:
   ```
   cd 05_01_PassFail
   dotnet run
   ```
4. Or open the whole pack in VS Code (`File → Open Folder…`). The solution file `MCMP113_Week05_Code.sln` lists all projects; in the C# Dev Kit *Solution Explorer* right-click a project → *Debug → Start New Instance*.

### Notes
* Programs are written with **top-level statements** (no `class Program`/`Main` needed).
* The course project template turns off nullable warnings and uses **invariant culture**, so decimal numbers are typed with a **point** (`72.5`) even on Turkish-language Windows.
* Typing input: when a program waits, type a value and press **Enter**. Stop a running program with **Ctrl + C**.
* `bin/` and `obj/` folders are created automatically on the first build; you may delete them at any time.

---


Each folder is a separate .NET 10 console project. Open the folder in VS Code and run it with `dotnet run`.
Every program was built with 0 errors and 0 warnings and run with boundary inputs that reach every branch (type one value per line).

| Folder | What it shows | Sample input |
|---|---|---|
| `05_01_PassFail` | `if`-`else if`-`else` ladder that includes the validation: `int.TryParse` with `out`, range check 0–100, pass mark as `const` | `60`, `59` (also `abc`, `-1`, `0`, `100`, `101`) |
| `05_02_EvenOdd` | guard clause with `return`, `if`-`else` on `n % 2 == 0`, the same decision with `?:` | `-7`, `10` (also `0`, `x`) |
| `05_03_MaxOfThree` | nested `if`-`else` (four paths) vs. "largest so far" with two independent `if`s | `9 3 5`, `3 5 9`, `7 7 7`, `-2 -8 -5` |
| `05_04_LeapYear` | leap-year rule as three nested decisions and as one `bool` expression | `2026`, `2024`, `1900`, `2000` (also `0`) |
| `05_05_LetterGrade` | else-if ladder (example AA–FF scale), the same as a switch expression with relational patterns, switch expression on a `string` | `85` (borders `90/89`, `60/59`, `0`, `100`, `101`) |
| `05_06_BmiCategory` | ranges on a `double`, validation written as "what is valid" (catches height in cm, `NaN`) | `72.5`, `1.78` (borders `74 2`, `100 2`, `120 2`; error `72.5 178`) |
| `05_07_Calculator` | `switch` on a `string`, stacked labels `"*" "x" "X"`, `default`, division-by-zero check for `/` and `%` | `7`, `/`, `2` (also `7 / 0`, `7 ^ 2`) |
| `05_08_DayName` | `switch` on an `int`, `return` inside `default`, stacked labels `case 6: case 7:` | `3`, `6`, `9` |
| `05_09_TriangleType` | guard clauses (type, range, triangle inequality), ladder equilateral / isosceles / scalene, independent right-angle `if` | `3 4 5`, `5 5 5`, `5 5 8`, `1 2 3`, `0 4 5` |
| `05_10_QuadraticRoots` | `a = 0` check first, three-way decision on Δ (> 0, = 0, < 0), complex roots | `1 -3 2`, `1 2 1`, `1 2 5`, `0 2 1` |
| `05_11_AtmWithdrawal` | `decimal` money, ladder whose order encodes the business rules (Week 1 exercise C) | `500`, `200` (also `500 500`, `500 510`, `500 25`, `500 0`) |
| `05_12_LoginCheck` | string comparison with `==` (case-sensitive), `&&` / `\|\|`, empty-input check | `student`, `Okan2026!` (also `Student`, `Okan2026!`) |
| `05_13_ShippingCost` | weight brackets with an else-if ladder and `Math.Ceiling`, `switch` on a `char` with stacked labels, `char.TryParse` | `23.5`, `e` (borders `1`/`1.01`, `5`/`5.01`, `20`/`20.1`, `100`/`100.1`) |

Notes
- The projects use the course template: `Nullable` disabled and `InvariantGlobalization` enabled, so `72.5` is typed with a decimal **point** also on Turkish-locale PCs. With this setting `double.TryParse("72,5")` succeeds with **725** (the comma is a thousands separator), which is why the programs also check realistic ranges.
- The letter-grade table is an example scale for exercises; the official cut-offs are in the university regulation.
- The shipping tariff, the ATM rules and the login data are invented teaching examples (never keep real passwords in source code).
- No loops are used this week: each program handles one input and ends. Repeating a question until the input is valid comes in Week 7.
