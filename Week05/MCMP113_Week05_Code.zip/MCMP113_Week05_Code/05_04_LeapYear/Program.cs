// MCMP113 · Week 5 · Example 4 — Leap year
// Demonstrates: the same rule as nested if-else and as one logical expression.
Console.Write("Enter a year: ");
if (!int.TryParse(Console.ReadLine(), out int year) || year < 1)
{
    Console.WriteLine("Error: enter a positive whole number, e.g. 2024.");
    return;
}

// Method 1: nested if-else, one question at a time.
bool leap1;
if (year % 4 == 0)
{
    if (year % 100 == 0)
    {
        if (year % 400 == 0)
        {
            leap1 = true;    // e.g. 2000
        }
        else
        {
            leap1 = false;   // e.g. 1900
        }
    }
    else
    {
        leap1 = true;        // e.g. 2024
    }
}
else
{
    leap1 = false;           // e.g. 2026
}

// Method 2: a single boolean expression (Week 4).
bool leap2 = (year % 4 == 0 && year % 100 != 0)
             || year % 400 == 0;

if (leap1)
{
    Console.WriteLine($"{year} is a leap year (366 days).");
}
else
{
    Console.WriteLine($"{year} is not a leap year (365 days).");
}
Console.WriteLine($"Nested if: {leap1}   Single expression: {leap2}");
