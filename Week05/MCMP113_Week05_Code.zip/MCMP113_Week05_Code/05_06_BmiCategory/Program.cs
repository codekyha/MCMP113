// MCMP113 · Week 5 · Example 6 — BMI category
// Demonstrates: range checks with && and an else-if ladder on a double value.
Console.Write("Weight (kg): ");
bool okW = double.TryParse(Console.ReadLine(), out double weight);
Console.Write("Height (m): ");
bool okH = double.TryParse(Console.ReadLine(), out double height);

// Written as "what is VALID": realistic ranges also catch height typed in cm (178).
bool valid = okW && okH && weight > 0 && weight <= 500 && height > 0 && height < 3;
if (!valid)
{
    Console.WriteLine("Error: weight 0-500 kg, height 0-3 m (e.g. 72.5, 1.78).");
    return;
}

double bmi = weight / (height * height);

// WHO adult categories. Each test only needs an upper limit,
// because the lower limit was already excluded by the tests above it.
string category;
if (bmi < 18.5)
{
    category = "Underweight";
}
else if (bmi < 25)
{
    category = "Normal weight";
}
else if (bmi < 30)
{
    category = "Overweight";
}
else
{
    category = "Obese";
}

Console.WriteLine($"BMI = {bmi:F2} -> {category}");
