// MCMP113 · Week 5 · Example 12 — Login check (one attempt)
// Demonstrates: comparing strings with ==, combining conditions with && and ||.
const string CorrectUser = "student";
const string CorrectPassword = "Okan2026!";

Console.Write("Username: ");
string user = Console.ReadLine();
Console.Write("Password: ");
string password = Console.ReadLine();

// == compares strings exactly: "Student" is not "student".
if (user == "" || password == "")
{
    Console.WriteLine("Error: empty username or password.");
}
else if (user == CorrectUser && password == CorrectPassword)
{
    Console.WriteLine($"Login successful. Welcome, {user}!");
}
else
{
    // Do not say WHICH part was wrong: it helps attackers.
    Console.WriteLine("Wrong username or password.");
}
