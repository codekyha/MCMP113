// MCMP113 · Week 5 · Example 11 — ATM withdrawal (Week 1, exercise C)
// Demonstrates: decimal money values and an else-if ladder whose ORDER encodes the rules.
Console.Write("Account balance (TL): ");
bool okBalance = decimal.TryParse(Console.ReadLine(), out decimal balance);
Console.Write("Amount to withdraw (TL): ");
bool okAmount = decimal.TryParse(Console.ReadLine(), out decimal amount);

if (!okBalance || !okAmount)
{
    Console.WriteLine("Error: please enter numbers only.");
    return;
}

if (amount <= 0)
{
    Console.WriteLine("Refused: amount must be positive.");
}
else if (amount % 10 != 0)
{
    Console.WriteLine("Refused: only multiples of 10 TL.");
}
else if (amount > balance)
{
    Console.WriteLine("Refused: insufficient funds.");
}
else
{
    balance -= amount;
    Console.WriteLine($"Please take your {amount:F2} TL.");
    Console.WriteLine($"New balance: {balance:F2} TL");
}
