// MCMP113 · Week 5 · Example 3 — Largest of three numbers
// Demonstrates: nested if-else (method 1) versus a "largest so far" variable (method 2).
Console.Write("a = ");
bool okA = double.TryParse(Console.ReadLine(), out double a);
Console.Write("b = ");
bool okB = double.TryParse(Console.ReadLine(), out double b);
Console.Write("c = ");
bool okC = double.TryParse(Console.ReadLine(), out double c);

if (!okA || !okB || !okC)
{
    Console.WriteLine("Error: please enter three numbers.");
    return;
}

// Method 1: nested if-else. First compare a and b, then the winner with c.
double max1;
if (a >= b)
{
    if (a >= c)
    {
        max1 = a;
    }
    else
    {
        max1 = c;
    }
}
else
{
    if (b >= c)
    {
        max1 = b;
    }
    else
    {
        max1 = c;
    }
}

// Method 2: start with a, then let b and c challenge it.
double max2 = a;
if (b > max2)
{
    max2 = b;
}
if (c > max2)
{
    max2 = c;
}

Console.WriteLine($"Method 1 (nested if):      {max1}");
Console.WriteLine($"Method 2 (largest so far): {max2}");
