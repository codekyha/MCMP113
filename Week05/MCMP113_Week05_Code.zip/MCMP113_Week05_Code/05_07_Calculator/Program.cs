// MCMP113 · Week 5 · Example 7 — Four-operation calculator
// Demonstrates: switch on a string, stacked case labels, default, and a division-by-zero check.
Console.Write("First number: ");
bool okA = double.TryParse(Console.ReadLine(), out double a);
Console.Write("Operator (+ - * / %): ");
string op = Console.ReadLine();
Console.Write("Second number: ");
bool okB = double.TryParse(Console.ReadLine(), out double b);

if (!okA || !okB)
{
    Console.WriteLine("Error: please enter two numbers.");
    return;
}

switch (op)
{
    case "+":
        Console.WriteLine($"{a} + {b} = {a + b:F2}");
        break;
    case "-":
        Console.WriteLine($"{a} - {b} = {a - b:F2}");
        break;
    case "*":
    case "x":   // stacked labels: *, x and X share one block
    case "X":
        Console.WriteLine($"{a} * {b} = {a * b:F2}");
        break;
    case "/":
        if (b == 0)
        {
            Console.WriteLine("Error: cannot divide by zero.");
        }
        else
        {
            Console.WriteLine($"{a} / {b} = {a / b:F2}");
        }
        break;
    case "%":
        if (b == 0)
        {
            Console.WriteLine("Error: cannot divide by zero.");
        }
        else
        {
            Console.WriteLine($"{a} % {b} = {a % b:F2}");
        }
        break;
    default:
        Console.WriteLine($"Error: unknown operator \"{op}\".");
        break;
}
