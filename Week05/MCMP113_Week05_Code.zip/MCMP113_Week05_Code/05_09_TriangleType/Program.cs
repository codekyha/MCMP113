// MCMP113 · Week 5 · Example 9 — Triangle type
// Demonstrates: validation first, then an else-if ladder, then an independent if.
const int MaxSide = 10000;

Console.Write("Side a: ");
bool okA = int.TryParse(Console.ReadLine(), out int a);
Console.Write("Side b: ");
bool okB = int.TryParse(Console.ReadLine(), out int b);
Console.Write("Side c: ");
bool okC = int.TryParse(Console.ReadLine(), out int c);

if (!okA || !okB || !okC)
{
    Console.WriteLine("Error: the sides must be whole numbers.");
    return;
}
if (a < 1 || b < 1 || c < 1 || a > MaxSide || b > MaxSide || c > MaxSide)
{
    Console.WriteLine($"Error: each side must be between 1 and {MaxSide}.");
    return;
}
// Triangle inequality: each side < sum of the other two.
if (a + b <= c || a + c <= b || b + c <= a)
{
    Console.WriteLine("Not a triangle: one side is too long.");
    return;
}

string type;
if (a == b && b == c)
{
    type = "equilateral";
}
else if (a == b || b == c || a == c)
{
    type = "isosceles";
}
else
{
    type = "scalene";
}
Console.WriteLine($"Valid triangle: {type}.");

// Independent question (a separate if, NOT part of the ladder above).
if (a * a + b * b == c * c || a * a + c * c == b * b || b * b + c * c == a * a)
{
    Console.WriteLine("It is also a right triangle.");
}
