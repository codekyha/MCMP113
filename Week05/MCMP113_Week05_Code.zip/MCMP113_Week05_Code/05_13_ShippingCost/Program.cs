// MCMP113 · Week 5 · Example 13 — Shipping cost
// Demonstrates: price brackets with an else-if ladder, then a switch on a char.
const decimal ExpressFactor = 1.5m;   // express costs 50 % more

Console.Write("Parcel weight (kg, max 100): ");
if (!decimal.TryParse(Console.ReadLine(), out decimal weight) || weight <= 0 || weight > 100)
{
    Console.WriteLine("Error: the weight must be a number above 0 and at most 100.");
    return;
}
Console.Write("Service (S = standard, E = express): ");
if (!char.TryParse(Console.ReadLine(), out char service))
{
    Console.WriteLine("Error: type a single letter, S or E.");
    return;
}

// Brackets: up to 1 kg, up to 5 kg, up to 20 kg, above 20 kg.
decimal baseCost;
if (weight <= 1)
{
    baseCost = 60m;
}
else if (weight <= 5)
{
    baseCost = 90m;
}
else if (weight <= 20)
{
    baseCost = 150m;
}
else
{
    baseCost = 150m + Math.Ceiling(weight - 20) * 8m;   // 8 TL per started kg above 20
}

decimal total;
string serviceName;
switch (service)
{
    case 'S':
    case 's':
        serviceName = "standard";
        total = baseCost;
        break;
    case 'E':
    case 'e':
        serviceName = "express";
        total = baseCost * ExpressFactor;
        break;
    default:
        Console.WriteLine($"Error: unknown service '{service}'.");
        return;
}

Console.WriteLine($"Base cost: {baseCost:F2} TL");
Console.WriteLine($"Total ({serviceName}): {total:F2} TL");
