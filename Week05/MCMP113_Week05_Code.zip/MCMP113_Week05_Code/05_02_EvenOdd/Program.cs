// MCMP113 · Week 5 · Example 2 — Even or odd
// Demonstrates: if-else on a remainder, and the same decision with the ?: operator.
Console.Write("Enter an integer: ");
if (!int.TryParse(Console.ReadLine(), out int n))
{
    Console.WriteLine("Error: that is not a whole number.");
    return;   // ends the program here (a "guard clause")
}

// Version 1: if-else chooses between two ACTIONS.
// Test "== 0", not "== 1": in C#, -7 % 2 is -1.
if (n % 2 == 0)
{
    Console.WriteLine($"{n} is even.");
}
else
{
    Console.WriteLine($"{n} is odd.");
}

// Version 2: the conditional operator ?: chooses between two VALUES.
string kind = (n % 2 == 0) ? "even" : "odd";
Console.WriteLine($"Check with ?: -> {kind}");
