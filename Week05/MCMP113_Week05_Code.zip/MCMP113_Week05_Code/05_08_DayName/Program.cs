// MCMP113 · Week 5 · Example 8 — Day number to day name
// Demonstrates: switch statement on an int, default, return in a case, stacked labels.
Console.Write("Day number (1-7, Monday = 1): ");
if (!int.TryParse(Console.ReadLine(), out int day))
{
    Console.WriteLine("Error: please enter a whole number.");
    return;
}

string name;
switch (day)
{
    case 1:
        name = "Monday";
        break;
    case 2:
        name = "Tuesday";
        break;
    case 3:
        name = "Wednesday";
        break;
    case 4:
        name = "Thursday";
        break;
    case 5:
        name = "Friday";
        break;
    case 6:
        name = "Saturday";
        break;
    case 7:
        name = "Sunday";
        break;
    default:
        Console.WriteLine("Error: the day must be 1-7.");
        return;   // return also ends a case
}

// Stacked labels: 6 and 7 share one block (no fall-through between blocks in C#).
string kind;
switch (day)
{
    case 6:
    case 7:
        kind = "weekend";
        break;
    default:
        kind = "weekday";
        break;
}

Console.WriteLine($"Day {day} is {name} ({kind}).");
