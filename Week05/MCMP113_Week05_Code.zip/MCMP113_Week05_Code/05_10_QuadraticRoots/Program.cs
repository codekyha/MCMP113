// MCMP113 · Week 5 · Example 10 — Roots of a quadratic equation
// Demonstrates: a three-way decision on the discriminant (> 0, == 0, < 0).
Console.WriteLine("Solves a*x^2 + b*x + c = 0");
Console.Write("a = ");
bool okA = double.TryParse(Console.ReadLine(), out double a);
Console.Write("b = ");
bool okB = double.TryParse(Console.ReadLine(), out double b);
Console.Write("c = ");
bool okC = double.TryParse(Console.ReadLine(), out double c);

if (!okA || !okB || !okC)
{
    Console.WriteLine("Error: please enter three numbers.");
    return;
}
if (a == 0)
{
    Console.WriteLine("Not a quadratic equation (a = 0).");
    return;
}

double delta = b * b - 4 * a * c;
Console.WriteLine($"Discriminant = {delta:F2}");

if (delta > 0)
{
    double x1 = (-b + Math.Sqrt(delta)) / (2 * a);
    double x2 = (-b - Math.Sqrt(delta)) / (2 * a);
    Console.WriteLine($"Two real roots: x1 = {x1:F4}, x2 = {x2:F4}");
}
else if (delta == 0)
{
    double x = -b / (2 * a);
    Console.WriteLine($"One real (double) root: x = {x:F4}");
}
else
{
    double re = -b / (2 * a);
    double im = Math.Sqrt(-delta) / (2 * Math.Abs(a));
    Console.WriteLine($"Complex roots: {re:F4} + {im:F4}i and {re:F4} - {im:F4}i");
}
