// MCMP113 · Week 5 · Example 1 — Pass or fail
// Demonstrates: if-else, and input validation with int.TryParse + a range check.
const int PassMark = 60;   // example pass mark

Console.Write("Enter the exam score (0-100): ");
string input = Console.ReadLine();

// Each test runs only if all the tests above it were false.
if (!int.TryParse(input, out int score))
{
    Console.WriteLine("Error: please enter a whole number.");
}
else if (score < 0 || score > 100)
{
    Console.WriteLine("Error: the score must be 0-100.");
}
else if (score >= PassMark)
{
    Console.WriteLine($"Score {score}: PASS");
}
else
{
    Console.WriteLine($"Score {score}: FAIL");
}
