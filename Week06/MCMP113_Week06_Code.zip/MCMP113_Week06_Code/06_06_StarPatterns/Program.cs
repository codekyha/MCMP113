// MCMP113 · Week 6 · Example 6 — Star patterns
// Demonstrates nested loops whose inner bound depends on the outer variable.

Console.Write("Rows: ");
int rows = int.Parse(Console.ReadLine());

// A) rectangle: every row has the same number of stars
Console.WriteLine("A) Rectangle");
for (int r = 1; r <= rows; r++)
{
    for (int c = 1; c <= 2 * rows; c++)
    {
        Console.Write("*");
    }
    Console.WriteLine();
}

// B) right triangle: row r has r stars
Console.WriteLine("B) Right triangle");
for (int r = 1; r <= rows; r++)
{
    for (int c = 1; c <= r; c++)
    {
        Console.Write("*");
    }
    Console.WriteLine();
}

// C) pyramid: row r has rows - r spaces, 2r - 1 stars
Console.WriteLine("C) Pyramid");
for (int r = 1; r <= rows; r++)
{
    for (int s = 1; s <= rows - r; s++)
    {
        Console.Write(" ");
    }
    for (int c = 1; c <= 2 * r - 1; c++)
    {
        Console.Write("*");
    }
    Console.WriteLine();
}
