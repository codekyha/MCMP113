// MCMP113 · Week 6 · Example 3 — Factorial table with long
// Demonstrates a product accumulator (starts at 1) and silent overflow after 20!.

Console.Write("n = ");
int n = int.Parse(Console.ReadLine());

long factorial = 1;   // product: starts at 1, not 0
for (int i = 1; i <= n; i++)
{
    factorial *= i;   // factorial = factorial * i
    Console.WriteLine($"{i,2}! = {factorial,26:N0}");
}
Console.WriteLine($"long.MaxValue = {long.MaxValue:N0}");
