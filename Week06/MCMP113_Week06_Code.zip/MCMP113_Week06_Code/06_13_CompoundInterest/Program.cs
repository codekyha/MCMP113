// MCMP113 · Week 6 · Example 13 — Compound interest, year by year
// Demonstrates an accumulator that grows by a percentage and a formatted table.

Console.Write("Deposit (TL): ");
decimal balance = decimal.Parse(Console.ReadLine());
Console.Write("Annual interest rate (%): ");
decimal rate = decimal.Parse(Console.ReadLine());
Console.Write("Years: ");
int years = int.Parse(Console.ReadLine());

Console.WriteLine("Year      Interest       Balance");
for (int year = 1; year <= years; year++)
{
    decimal interest = balance * rate / 100;  // this year
    balance += interest;                      // add to balance
    Console.WriteLine($"{year,4} {interest,13:F2} {balance,13:F2}");
}
