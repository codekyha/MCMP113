// MCMP113 · Week 6 · Example 5 — Multiplication grid (nested loops)
// Demonstrates an outer loop for rows and an inner loop for columns.

Console.Write("Grid size: ");
int size = int.Parse(Console.ReadLine());

for (int row = 1; row <= size; row++)      // outer: rows
{
    for (int col = 1; col <= size; col++)  // inner: columns
    {
        Console.Write($"{row * col,4}");   // 4 chars wide
    }
    Console.WriteLine();                   // end of row
}
