// MCMP113 · Week 6 · Example 11 — FizzBuzz
// Demonstrates a for loop combined with an else-if ladder (order of tests matters).

Console.Write("Up to: ");
int n = int.Parse(Console.ReadLine());

for (int i = 1; i <= n; i++)
{
    if (i % 15 == 0)        // divisible by 3 AND 5: test first
    {
        Console.WriteLine("FizzBuzz");
    }
    else if (i % 3 == 0)
    {
        Console.WriteLine("Fizz");
    }
    else if (i % 5 == 0)
    {
        Console.WriteLine("Buzz");
    }
    else
    {
        Console.WriteLine(i);
    }
}
