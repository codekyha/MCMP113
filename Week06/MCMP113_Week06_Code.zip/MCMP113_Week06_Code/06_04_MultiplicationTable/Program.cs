// MCMP113 · Week 6 · Example 4 — Multiplication table of one number
// Demonstrates using the loop variable in a calculation and aligned output {x,3}.

Console.Write("Table of: ");
int number = int.Parse(Console.ReadLine());

for (int i = 1; i <= 10; i++)
{
    Console.WriteLine($"{number} x {i,2} = {number * i,3}");
}
