// MCMP113 · Week 6 · Example 10 — First N Fibonacci numbers
// Demonstrates carrying two values from one pass to the next.

Console.Write("How many terms? ");
int n = int.Parse(Console.ReadLine());

long previous = 0;   // F(0)
long current = 1;    // F(1)
for (int i = 1; i <= n; i++)
{
    Console.Write($"{previous} ");
    long next = previous + current;  // sum of the last two
    previous = current;              // shift one step forward
    current = next;
}
Console.WriteLine();
