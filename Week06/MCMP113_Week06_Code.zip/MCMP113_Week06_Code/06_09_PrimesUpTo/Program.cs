// MCMP113 · Week 6 · Example 9 — All primes up to N (nested loops + break)
// Demonstrates an inner search loop inside an outer counting loop.

Console.Write("Primes up to: ");
int max = int.Parse(Console.ReadLine());

int found = 0;
for (int n = 2; n <= max; n++)           // outer: candidates
{
    bool isPrime = true;
    for (int d = 2; d * d <= n; d++)     // inner: divisors
    {
        if (n % d == 0)
        {
            isPrime = false;
            break;                       // inner loop only
        }
    }
    if (isPrime)
    {
        found++;
        Console.Write($"{n,4}");
        if (found % 10 == 0)
        {
            Console.WriteLine();         // 10 per line
        }
    }
}
Console.WriteLine();
Console.WriteLine($"{found} primes found.");
