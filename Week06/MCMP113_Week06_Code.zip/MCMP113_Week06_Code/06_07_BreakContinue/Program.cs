// MCMP113 · Week 6 · Example 7 — break and continue
// Demonstrates skipping one pass (continue) and leaving the loop early (break).

// Part 1: continue -> skip the multiples of 3
for (int i = 1; i <= 15; i++)
{
    if (i % 3 == 0)
    {
        continue;              // jump to the update i++
    }
    Console.Write($"{i} ");
}
Console.WriteLine();

// Part 2: read at most 10 numbers; 0 stops early, negatives are skipped
int sum = 0;
int used = 0;
for (int k = 1; k <= 10; k++)
{
    Console.Write($"Number {k} (0 = stop): ");
    int x = int.Parse(Console.ReadLine());
    if (x == 0)
    {
        break;                 // leave the loop immediately
    }
    if (x < 0)
    {
        Console.WriteLine("  negative -> skipped");
        continue;              // go on with the next k
    }
    sum += x;
    used++;
}
Console.WriteLine($"Sum of {used} positive numbers = {sum}");
