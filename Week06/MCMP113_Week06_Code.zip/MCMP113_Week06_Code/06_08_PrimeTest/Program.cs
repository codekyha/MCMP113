// MCMP113 · Week 6 · Example 8 — Prime test by trial division
// Demonstrates a search loop that stops with break, testing divisors only up to √n.

Console.Write("n = ");
int n = int.Parse(Console.ReadLine());

bool isPrime = n >= 2;          // 0, 1, negatives: not prime
int limit = (int)Math.Sqrt(n);  // largest divisor to test
int checks = 0;                 // divisions tried

for (int d = 2; d <= limit; d++)
{
    checks++;
    if (n % d == 0)
    {
        Console.WriteLine($"{n} = {d} x {n / d}");
        isPrime = false;
        break;                  // one divisor is enough
    }
}

if (isPrime)
{
    Console.WriteLine($"{n} is prime");
}
else
{
    Console.WriteLine($"{n} is not prime");
}
Console.WriteLine($"Divisions tried: {checks}");
