// MCMP113 · Week 6 · Example 1 — Counting patterns
// Demonstrates counting up, counting down and counting in steps with a for loop.

Console.Write("Count up to: ");
int n = int.Parse(Console.ReadLine());

// 1) count up: 1, 2, ..., n
Console.Write("Up:     ");
for (int i = 1; i <= n; i++)
{
    Console.Write($"{i} ");
}
Console.WriteLine();

// 2) count down: n, n-1, ..., 1
Console.Write("Down:   ");
for (int i = n; i >= 1; i--)
{
    Console.Write($"{i} ");
}
Console.WriteLine();

// 3) count in steps of 2: 0, 2, 4, ... (never above n)
Console.Write("Even:   ");
for (int i = 0; i <= n; i += 2)
{
    Console.Write($"{i} ");
}
Console.WriteLine();

// 4) count down in steps of 5, starting at 5*n
Console.Write("By -5:  ");
for (int i = 5 * n; i > 0; i -= 5)
{
    Console.Write($"{i} ");
}
Console.WriteLine();
