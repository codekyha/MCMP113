# MCMP113 · Introduction to Basic Algorithms and Programming
## Week 6 — example code pack

Asst. Prof. Hasan Oğuz, PhD · Istanbul Okan University · 2026–2027 Fall

Every folder in this pack is a **separate, complete C# console project** (`.csproj` + `Program.cs`) for .NET 10.
All programs were built with 0 errors / 0 warnings and run with the sample inputs listed below.

### Getting started
1. Install the **.NET 10 SDK** (https://dotnet.microsoft.com/en-us/download/dotnet/10.0) and **Visual Studio Code** with the **C# Dev Kit** extension.
2. Unzip this pack, e.g. to `Documents\MCMP113\Week06`.
3. Run one example from a terminal:
   ```
   cd 06_01_CountingPatterns
   dotnet run
   ```
4. Or open the whole pack in VS Code (`File → Open Folder…`). The solution file `MCMP113_Week06_Code.sln` lists all projects; in the C# Dev Kit *Solution Explorer* right-click a project → *Debug → Start New Instance*.

### Notes
* Programs are written with **top-level statements** (no `class Program`/`Main` needed).
* The course project template turns off nullable warnings and uses **invariant culture**, so decimal numbers are typed with a **point** (`72.5`) even on Turkish-language Windows.
* Typing input: when a program waits, type a value and press **Enter**. Stop a running program with **Ctrl + C**.
* `bin/` and `obj/` folders are created automatically on the first build; you may delete them at any time.

---


Each folder is a separate .NET 10 console project. Open the folder in VS Code and run it with `dotnet run`.
Every program was built with 0 errors and 0 warnings and run with the sample input shown here (type one value per line).
The sample runs on the slides and in the notes are the real output of these runs.

| Folder | What it shows | Sample input |
|---|---|---|
| `06_01_CountingPatterns` | counting up, down, in steps of 2 and in steps of −5 with `for` | `10` (title slide: `5`) |
| `06_02_SumAndAverage` | accumulator (`sum`) and counter (`passed`) in one loop; average only if `count > 0` | `5`, `72.5`, `45`, `88`, `60`, `39.5` (edge case: `0`) |
| `06_03_Factorial` | product accumulator starting at 1; `long`; silent overflow after `20!`; `{x:N0}` | `22` (also `5`) |
| `06_04_MultiplicationTable` | using the loop variable in a calculation; aligned output `{x,3}` | `7` |
| `06_05_MultiplicationGrid` | nested loops: outer = rows, inner = columns; `WriteLine()` after the inner loop | `10` (also `4`) |
| `06_06_StarPatterns` | rectangle, right triangle, pyramid: inner bound depends on the outer variable | `4` |
| `06_07_BreakContinue` | `continue` skips multiples of 3; `break` stops reading at `0`; negatives skipped | `8`, `-3`, `12`, `5`, `0` |
| `06_08_PrimeTest` | trial division up to √n, `break` at the first divisor, number of divisions tried | `97`, `91`, `1000003`, `1` |
| `06_09_PrimesUpTo` | search loop (`d * d <= n`) inside a counting loop; `break` leaves only the inner loop; 10 per line | `100` |
| `06_10_Fibonacci` | carrying two values (`previous`, `current`) from one pass to the next | `12` |
| `06_11_FizzBuzz` | `for` + else-if ladder; the multiple-of-15 test must come first | `15` |
| `06_12_MinMax` | smallest, largest and range of N numbers without arrays ("best so far" set by the first input) | `5`, `17`, `-4`, `23.5`, `8`, `0` |
| `06_13_CompoundInterest` | year-by-year table with `decimal`; balance grows by a percentage each pass | `10000`, `40`, `5` |

Notes
- `06_03_Factorial` prints negative values for `21!` and `22!` on purpose: `long` overflows silently (unchecked context). Wrap the multiplication in `checked(...)` to get an `OverflowException` instead.
- `06_08_PrimeTest`: run it several times with the inputs listed (one per run).
- The projects use the course template: `Nullable` disabled and `InvariantGlobalization` enabled, so `72.5` is typed with a decimal **point** also on Turkish-locale PCs.
- Only constructs up to Week 6 are used: no `while`/`do-while` (Week 7), no arrays (Week 9), no methods (Week 12).
