// MCMP113 · Week 6 · Example 12 — Smallest and largest of N numbers (no arrays)
// Demonstrates "best so far" variables initialised with the first input.

Console.Write("How many numbers? ");
int count = int.Parse(Console.ReadLine());

double min = 0;
double max = 0;
for (int i = 1; i <= count; i++)
{
    Console.Write($"Number {i}: ");
    double x = double.Parse(Console.ReadLine());
    if (i == 1 || x < min)     // first number, or a new minimum
    {
        min = x;
    }
    if (i == 1 || x > max)     // first number, or a new maximum
    {
        max = x;
    }
}

if (count > 0)
{
    Console.WriteLine($"Smallest = {min}");
    Console.WriteLine($"Largest  = {max}");
    Console.WriteLine($"Range    = {max - min}");
}
else
{
    Console.WriteLine("Nothing to compare.");
}
