// MCMP113 · Week 6 · Example 2 — Sum, average and count of N grades
// Demonstrates accumulators (sum) and counters (passed) inside a for loop.

Console.Write("How many grades? ");
int count = int.Parse(Console.ReadLine());

double sum = 0;   // accumulator: starts at 0
int passed = 0;   // counter: starts at 0

for (int i = 1; i <= count; i++)
{
    Console.Write($"Grade {i}: ");
    double grade = double.Parse(Console.ReadLine());
    sum += grade;              // add to the running total
    if (grade >= 50)
    {
        passed++;              // count the passing grades
    }
}

if (count > 0)
{
    double average = sum / count;
    Console.WriteLine($"Sum     = {sum:F2}");
    Console.WriteLine($"Average = {average:F2}");
    Console.WriteLine($"Passed  = {passed} of {count}");
}
else
{
    Console.WriteLine("No grades entered.");
}
