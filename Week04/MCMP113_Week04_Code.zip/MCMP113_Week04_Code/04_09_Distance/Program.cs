// MCMP113 · Week 4 · Example 9 — Distance between two points
// Math.Sqrt, Math.Pow and Math.Abs in a geometric formula.
Console.Write("x1 = ");
double x1 = double.Parse(Console.ReadLine());
Console.Write("y1 = ");
double y1 = double.Parse(Console.ReadLine());
Console.Write("x2 = ");
double x2 = double.Parse(Console.ReadLine());
Console.Write("y2 = ");
double y2 = double.Parse(Console.ReadLine());

double dx = x2 - x1;
double dy = y2 - y1;
double distance = Math.Sqrt(dx * dx + dy * dy);
double samePow = Math.Sqrt(Math.Pow(dx, 2) + Math.Pow(dy, 2));   // same value
double manhattan = Math.Abs(dx) + Math.Abs(dy);                  // "taxi" distance

Console.WriteLine($"Euclidean distance = {distance:F3} (with Pow: {samePow:F3})");
Console.WriteLine($"Manhattan distance = {manhattan:F3}");
Console.WriteLine($"Midpoint = ({(x1 + x2) / 2:F2}, {(y1 + y2) / 2:F2})");
