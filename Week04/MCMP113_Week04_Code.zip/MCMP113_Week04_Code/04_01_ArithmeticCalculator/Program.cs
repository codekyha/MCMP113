// MCMP113 · Week 4 · Example 1 — Arithmetic calculator
// The five arithmetic operators on int, and integer division vs real division.
Console.Write("First integer  a = ");
int a = int.Parse(Console.ReadLine());
Console.Write("Second integer b = ");
int b = int.Parse(Console.ReadLine());

Console.WriteLine($"a + b = {a + b}");
Console.WriteLine($"a - b = {a - b}");
Console.WriteLine($"a * b = {a * b}");
Console.WriteLine($"a / b = {a / b}   (quotient)");
Console.WriteLine($"a % b = {a % b}   (remainder)");
Console.WriteLine($"(double)a / b = {(double)a / b:F4}");

// quotient * divisor + remainder always gives back a
Console.WriteLine($"check: {a / b} * {b} + {a % b} = {a / b * b + a % b}");
