// MCMP113 · Week 4 · Example 8 — Compound interest A = P(1 + r/n)^(nt)
// Math.Pow, operator precedence and converting a percentage to a rate.
Console.Write("Principal P (TL): ");
double principal = double.Parse(Console.ReadLine());
Console.Write("Annual interest rate (%): ");
double ratePercent = double.Parse(Console.ReadLine());
Console.Write("Compounding periods per year n: ");
int n = int.Parse(Console.ReadLine());
Console.Write("Years t: ");
int t = int.Parse(Console.ReadLine());

double r = ratePercent / 100;                           // 40 % -> 0.40
double amount = principal * Math.Pow(1 + r / n, n * t);
double simple = principal * (1 + r * t);                // simple interest, for comparison

Console.WriteLine($"Compound amount : {amount:F2} TL");
Console.WriteLine($"Interest earned : {amount - principal:F2} TL");
Console.WriteLine($"Simple interest : {simple:F2} TL");
