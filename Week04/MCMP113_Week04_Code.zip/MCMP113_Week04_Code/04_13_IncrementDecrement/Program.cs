// MCMP113 · Week 4 · Example 13 — Increment, decrement and compound assignment
// Prefix (++i) changes first and then gives the value; postfix (i++) gives the old value.
int i = 5;
int a = i++;                       // a gets 5, then i becomes 6
Console.WriteLine($"a = i++  ->  a = {a}, i = {i}");

i = 5;
int b = ++i;                       // i becomes 6, then b gets 6
Console.WriteLine($"b = ++i  ->  b = {b}, i = {i}");

int j = 3;
int c = j-- * 10;                  // uses 3, then j becomes 2
Console.WriteLine($"c = j-- * 10  ->  c = {c}, j = {j}");

int score = 10;
score += 5;  Console.WriteLine($"score += 5  ->  {score}");
score -= 3;  Console.WriteLine($"score -= 3  ->  {score}");
score *= 2;  Console.WriteLine($"score *= 2  ->  {score}");
score /= 5;  Console.WriteLine($"score /= 5  ->  {score}   (integer division)");
score %= 3;  Console.WriteLine($"score %= 3  ->  {score}");
