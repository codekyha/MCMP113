// MCMP113 · Week 4 · Example 12 — Truth table printer
// &&, ||, ! for all four input combinations, De Morgan's law, short-circuit guard.
bool p, q;
Console.WriteLine("p      q      p&&q   p||q   !p     !(p&&q)==(!p||!q)");

p = false; q = false;
Console.WriteLine($"{p,-6} {q,-6} {p && q,-6} {p || q,-6} {!p,-6} {!(p && q) == (!p || !q)}");
p = false; q = true;
Console.WriteLine($"{p,-6} {q,-6} {p && q,-6} {p || q,-6} {!p,-6} {!(p && q) == (!p || !q)}");
p = true; q = false;
Console.WriteLine($"{p,-6} {q,-6} {p && q,-6} {p || q,-6} {!p,-6} {!(p && q) == (!p || !q)}");
p = true; q = true;
Console.WriteLine($"{p,-6} {q,-6} {p && q,-6} {p || q,-6} {!p,-6} {!(p && q) == (!p || !q)}");

// short-circuit: when b is 0, a / b is never evaluated, so no crash
int a = 10, b = 0;
bool bigRatio = b != 0 && a / b > 2;
Console.WriteLine($"b != 0 && a / b > 2  ->  {bigRatio}");
