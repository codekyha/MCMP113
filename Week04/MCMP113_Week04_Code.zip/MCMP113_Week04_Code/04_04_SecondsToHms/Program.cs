// MCMP113 · Week 4 · Example 4 — Seconds to days, hours, minutes, seconds
// Repeated use of / and % to split one quantity into units.
Console.Write("Total seconds: ");
int total = int.Parse(Console.ReadLine());

int days = total / 86400;             // 86400 s in a day
int hours = total % 86400 / 3600;     // what is left after whole days
int minutes = total % 3600 / 60;
int seconds = total % 60;

Console.WriteLine($"{total} s = {days} d {hours} h {minutes} min {seconds} s");
Console.WriteLine($"clock format: {days}d {hours:D2}:{minutes:D2}:{seconds:D2}");
