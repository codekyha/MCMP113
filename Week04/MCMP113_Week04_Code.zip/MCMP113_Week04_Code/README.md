# MCMP113 · Introduction to Basic Algorithms and Programming
## Week 4 — example code pack

Asst. Prof. Hasan Oğuz, PhD · Istanbul Okan University · 2026–2027 Fall

Every folder in this pack is a **separate, complete C# console project** (`.csproj` + `Program.cs`) for .NET 10.
All programs were built with 0 errors / 0 warnings and run with the sample inputs listed below.

### Getting started
1. Install the **.NET 10 SDK** (https://dotnet.microsoft.com/en-us/download/dotnet/10.0) and **Visual Studio Code** with the **C# Dev Kit** extension.
2. Unzip this pack, e.g. to `Documents\MCMP113\Week04`.
3. Run one example from a terminal:
   ```
   cd 04_01_ArithmeticCalculator
   dotnet run
   ```
4. Or open the whole pack in VS Code (`File → Open Folder…`). The solution file `MCMP113_Week04_Code.sln` lists all projects; in the C# Dev Kit *Solution Explorer* right-click a project → *Debug → Start New Instance*.

### Notes
* Programs are written with **top-level statements** (no `class Program`/`Main` needed).
* The course project template turns off nullable warnings and uses **invariant culture**, so decimal numbers are typed with a **point** (`72.5`) even on Turkish-language Windows.
* Typing input: when a program waits, type a value and press **Enter**. Stop a running program with **Ctrl + C**.
* `bin/` and `obj/` folders are created automatically on the first build; you may delete them at any time.

---


Each folder is a separate .NET 10 console project. Open the folder in VS Code and run it with `dotnet run`.
Every program was built with 0 errors and 0 warnings and run with the sample input shown here (type one value per line).

| Folder | What it shows | Sample input |
|---|---|---|
| `04_01_ArithmeticCalculator` | `+ - * / %` on `int`, integer vs real quotient, the identity `a == (a / b) * b + a % b` | `17`, `5` (also try `-17`, `5`) |
| `04_02_DivisionRules` | `7 / 2` vs `7 / 2.0` vs `(double)(7 / 2)`, sign of `%` for negatives, safe modulo, `Infinity` / `NaN` | none |
| `04_03_DigitExtraction` | digits of a three-digit number with `/ 10` and `% 10`, digit sum, reversed number | `472` |
| `04_04_SecondsToHms` | seconds → days, hours, minutes, seconds; `{x:D2}` padding | `3725` or `100000` |
| `04_05_ClockArithmetic` | time after N minutes with wrap-around and the safe modulo `((x % m) + m) % m` | `22`, `45`, `150` (also `0`, `20`, `-45`) |
| `04_06_LeapYear` | leap-year rule as one `bool` expression with `&&`, `\|\|`, `!`; the `?:` operator | `2024`, `1900`, `2000`, `2026` |
| `04_07_QuadraticRoots` | discriminant, `Math.Sqrt`, essential parentheses, `NaN` for negative Δ | `1`, `-3`, `2` (also `1`, `2`, `5`) |
| `04_08_CompoundInterest` | `A = P(1 + r/n)^(nt)` with `Math.Pow`, percent → rate | `10000`, `40`, `12`, `2` |
| `04_09_Distance` | Euclidean and Manhattan distance, midpoint (`Math.Sqrt`, `Math.Pow`, `Math.Abs`) | `1`, `2`, `4`, `6` |
| `04_10_KimlikCheckDigits` | T.C. Kimlik No check digits d10, d11 (Week 1 algorithm) with digit extraction and the safe modulo | `123456789` or `190909090` (made-up numbers) |
| `04_11_MathClass` | `Math.Round` (banker's vs `AwayFromZero`), `Floor`, `Ceiling`, cast, `Abs`, `Pow`, `Sqrt`, `Max`, `Min` | `2.5`, `-2.5`, `-2.7`, `3.5` |
| `04_12_TruthTable` | truth table of `&&`, `\|\|`, `!`, De Morgan check, short-circuit guard `b != 0 && a / b > 2` | none |
| `04_13_IncrementDecrement` | prefix vs postfix `++`/`--`, compound assignment `+= -= *= /= %=` | none |
| `04_14_OperatorPitfalls` | Week 1 average bug (precedence), integer division, `"Sum: " + a + b`, `int` overflow | `60`, `70`, `85` |

Notes
- Run `04_01_ArithmeticCalculator` with `b = 0` to see a `DivideByZeroException` (the program stops); Week 5 shows how to prevent it with `if`.
- The projects use the course template: `Nullable` disabled and `InvariantGlobalization` enabled, so `2.5` is typed with a decimal **point** also on Turkish-locale PCs.
- No `if`/`else` is used this week; the conditional operator `?:` appears only to choose between two texts.
