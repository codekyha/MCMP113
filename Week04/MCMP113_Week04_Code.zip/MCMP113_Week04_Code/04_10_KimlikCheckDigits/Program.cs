// MCMP113 · Week 4 · Example 10 — T.C. Kimlik No check digits d10 and d11
// Digit extraction with / and %, and the safe modulo for a negative number.
Console.Write("First nine digits: ");
int first9 = int.Parse(Console.ReadLine());

int d1 = first9 / 100_000_000;
int d2 = first9 / 10_000_000 % 10;
int d3 = first9 / 1_000_000 % 10;
int d4 = first9 / 100_000 % 10;
int d5 = first9 / 10_000 % 10;
int d6 = first9 / 1_000 % 10;
int d7 = first9 / 100 % 10;
int d8 = first9 / 10 % 10;
int d9 = first9 % 10;

int oddSum = d1 + d3 + d5 + d7 + d9;
int evenSum = d2 + d4 + d6 + d8;
int raw = 7 * oddSum - evenSum;
int d10 = ((raw % 10) + 10) % 10;             // safe modulo: result is 0..9
int d11 = (oddSum + evenSum + d10) % 10;

Console.WriteLine($"odd sum = {oddSum}, even sum = {evenSum}, 7*odd - even = {raw}");
Console.WriteLine($"raw % 10 = {raw % 10}  ->  d10 = {d10}, d11 = {d11}");
Console.WriteLine($"Full number: {first9}{d10}{d11}   (first digit non-zero: {d1 != 0})");
