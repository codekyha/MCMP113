// MCMP113 · Week 4 · Example 11 — The Math class and rounding
// Round (banker's vs away from zero), Floor, Ceiling, cast, Abs, Pow, Sqrt, Max, Min.
Console.Write("Enter a real number x: ");
double x = double.Parse(Console.ReadLine());

Console.WriteLine($"Math.Round(x)                  = {Math.Round(x)}");
Console.WriteLine($"Math.Round(x, AwayFromZero)    = {Math.Round(x, MidpointRounding.AwayFromZero)}");
Console.WriteLine($"Math.Floor(x)                  = {Math.Floor(x)}");
Console.WriteLine($"Math.Ceiling(x)                = {Math.Ceiling(x)}");
Console.WriteLine($"(int)x                         = {(int)x}");
Console.WriteLine($"Math.Abs(x)                    = {Math.Abs(x)}");
Console.WriteLine($"Math.Pow(x, 2)                 = {Math.Pow(x, 2)}");
Console.WriteLine($"Math.Sqrt(Math.Abs(x))         = {Math.Sqrt(Math.Abs(x)):F4}");
Console.WriteLine($"Math.Max(x, 0), Math.Min(x, 0) = {Math.Max(x, 0)}, {Math.Min(x, 0)}");
