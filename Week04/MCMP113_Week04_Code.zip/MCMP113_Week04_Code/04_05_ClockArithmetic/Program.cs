// MCMP113 · Week 4 · Example 5 — Clock arithmetic
// Time after N minutes (N may be negative): wrap-around with the safe modulo.
Console.Write("Current hour (0-23): ");
int hour = int.Parse(Console.ReadLine());
Console.Write("Current minute (0-59): ");
int minute = int.Parse(Console.ReadLine());
Console.Write("Minutes to add (negative = go back): ");
int delta = int.Parse(Console.ReadLine());

const int MinutesPerDay = 24 * 60;             // 1440
int now = hour * 60 + minute;                  // minutes since midnight
int raw = now + delta;
int wrapped = ((raw % MinutesPerDay) + MinutesPerDay) % MinutesPerDay;

Console.WriteLine($"raw minutes = {raw}, raw % 1440 = {raw % MinutesPerDay}");
Console.WriteLine($"New time: {wrapped / 60:D2}:{wrapped % 60:D2}");
