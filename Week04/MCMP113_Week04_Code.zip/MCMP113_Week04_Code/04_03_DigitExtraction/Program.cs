// MCMP113 · Week 4 · Example 3 — Digits of a three-digit number
// Uses / 10 (drop the last digit) and % 10 (keep the last digit).
Console.Write("Enter a three-digit number: ");
int n = int.Parse(Console.ReadLine());

int hundreds = n / 100;       // 472 / 100 = 4
int tens = n / 10 % 10;       // 472 / 10 = 47, 47 % 10 = 7
int ones = n % 10;            // 472 % 10 = 2

int digitSum = hundreds + tens + ones;
int reversed = ones * 100 + tens * 10 + hundreds;

Console.WriteLine($"hundreds = {hundreds}, tens = {tens}, ones = {ones}");
Console.WriteLine($"digit sum = {digitSum}");
Console.WriteLine($"reversed  = {reversed}");
