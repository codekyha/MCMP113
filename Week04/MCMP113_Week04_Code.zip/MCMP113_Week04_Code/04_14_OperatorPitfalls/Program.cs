// MCMP113 · Week 4 · Example 14 — Operator pitfalls
// Precedence (Week 1 average bug), integer division, string + number, overflow.
Console.Write("Grade 1: ");
int g1 = int.Parse(Console.ReadLine());
Console.Write("Grade 2: ");
int g2 = int.Parse(Console.ReadLine());
Console.Write("Grade 3: ");
int g3 = int.Parse(Console.ReadLine());

Console.WriteLine($"g1 + g2 + g3 / 3     = {g1 + g2 + g3 / 3}      (wrong: / before +)");
Console.WriteLine($"(g1 + g2 + g3) / 3   = {(g1 + g2 + g3) / 3}       (integer division)");
Console.WriteLine($"(g1 + g2 + g3) / 3.0 = {(g1 + g2 + g3) / 3.0:F2}    (correct)");

Console.WriteLine("Sum: " + g1 + g2);       // text first -> joins as text
Console.WriteLine("Sum: " + (g1 + g2));     // parentheses -> adds first
Console.WriteLine(g1 + g2 + " is the sum"); // left to right: adds, then joins

int big = int.MaxValue;
Console.WriteLine($"int.MaxValue + 1 = {big + 1}   (overflow wraps around)");
Console.WriteLine($"(long)big + 1    = {(long)big + 1}");
// Console.WriteLine(checked(big + 1));   // would stop with OverflowException
