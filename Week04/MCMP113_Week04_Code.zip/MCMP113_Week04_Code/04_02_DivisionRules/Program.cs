// MCMP113 · Week 4 · Example 2 — Division rules
// Integer vs real division, the remainder of negative numbers, division by zero.
Console.WriteLine("--- integer vs real division ---");
Console.WriteLine($"7 / 2           = {7 / 2}");
Console.WriteLine($"7 / 2.0         = {7 / 2.0}");
Console.WriteLine($"(double)7 / 2   = {(double)7 / 2}");
Console.WriteLine($"(double)(7 / 2) = {(double)(7 / 2)}");
Console.WriteLine($"-7 / 2          = {-7 / 2}   (truncated toward zero)");

Console.WriteLine("--- remainder: the sign follows the dividend ---");
Console.WriteLine($" 7 %  3 = {7 % 3}");
Console.WriteLine($"-7 %  3 = {-7 % 3}");
Console.WriteLine($" 7 % -3 = {7 % -3}");
int x = -7;
Console.WriteLine($"((x % 3) + 3) % 3 = {((x % 3) + 3) % 3}   (always 0, 1 or 2)");

Console.WriteLine("--- division by zero ---");
double zero = 0.0;
Console.WriteLine($" 1.0 / 0.0 = {1.0 / zero}");
Console.WriteLine($"-1.0 / 0.0 = {-1.0 / zero}");
Console.WriteLine($" 0.0 / 0.0 = {0.0 / zero}");
// int n = 0; Console.WriteLine(1 / n);   // int: program stops with DivideByZeroException
