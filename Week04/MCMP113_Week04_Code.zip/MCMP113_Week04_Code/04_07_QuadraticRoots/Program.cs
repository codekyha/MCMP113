// MCMP113 · Week 4 · Example 7 — Quadratic equation ax² + bx + c = 0
// Discriminant, Math.Sqrt and correct parentheses; NaN appears when there are no real roots.
Console.Write("a = ");
double a = double.Parse(Console.ReadLine());
Console.Write("b = ");
double b = double.Parse(Console.ReadLine());
Console.Write("c = ");
double c = double.Parse(Console.ReadLine());

double delta = b * b - 4 * a * c;
double x1 = (-b + Math.Sqrt(delta)) / (2 * a);    // parentheses are essential
double x2 = (-b - Math.Sqrt(delta)) / (2 * a);

Console.WriteLine($"delta = {delta}");
Console.WriteLine(delta >= 0 ? "Real roots exist." : "No real roots (Sqrt of a negative is NaN).");
Console.WriteLine($"x1 = {x1:F4}");
Console.WriteLine($"x2 = {x2:F4}");
