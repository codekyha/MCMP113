// MCMP113 · Week 4 · Example 6 — Leap year as one boolean expression
// Relational (==, !=) and logical (&&, ||) operators produce a bool.
Console.Write("Year: ");
int year = int.Parse(Console.ReadLine());

bool divisibleBy4 = year % 4 == 0;
bool divisibleBy100 = year % 100 == 0;
bool divisibleBy400 = year % 400 == 0;
bool isLeap = (divisibleBy4 && !divisibleBy100) || divisibleBy400;

Console.WriteLine($"divisible by 4: {divisibleBy4}, by 100: {divisibleBy100}, by 400: {divisibleBy400}");
Console.WriteLine($"isLeap = {isLeap}");
Console.WriteLine($"{year} is {(isLeap ? "a leap year (366 days)" : "not a leap year (365 days)")}");
