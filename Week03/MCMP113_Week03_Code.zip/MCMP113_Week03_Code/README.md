# MCMP113 · Introduction to Basic Algorithms and Programming
## Week 3 — example code pack

Asst. Prof. Hasan Oğuz, PhD · Istanbul Okan University · 2026–2027 Fall

Every folder in this pack is a **separate, complete C# console project** (`.csproj` + `Program.cs`) for .NET 10.
All programs were built with 0 errors / 0 warnings and run with the sample inputs listed below.

### Getting started
1. Install the **.NET 10 SDK** (https://dotnet.microsoft.com/en-us/download/dotnet/10.0) and **Visual Studio Code** with the **C# Dev Kit** extension.
2. Unzip this pack, e.g. to `Documents\MCMP113\Week03`.
3. Run one example from a terminal:
   ```
   cd 03_01_HelloCard
   dotnet run
   ```
4. Or open the whole pack in VS Code (`File → Open Folder…`). The solution file `MCMP113_Week03_Code.sln` lists all projects; in the C# Dev Kit *Solution Explorer* right-click a project → *Debug → Start New Instance*.

### Notes
* Programs are written with **top-level statements** (no `class Program`/`Main` needed).
* The course project template turns off nullable warnings and uses **invariant culture**, so decimal numbers are typed with a **point** (`72.5`) even on Turkish-language Windows.
* Typing input: when a program waits, type a value and press **Enter**. Stop a running program with **Ctrl + C**.
* `bin/` and `obj/` folders are created automatically on the first build; you may delete them at any time.

---


Each folder is a separate .NET 10 console project (course template: Nullable off, InvariantGlobalization on,
so always type a decimal **point**: `72.5`, not `72,5`).
Run with:  `cd <folder>`  then  `dotnet run`.
Every console transcript in the slides and notes was produced by running these programs with the sample input below.

| Folder | What it shows | Sample input |
|---|---|---|
| 03_01_HelloCard | `Write` vs `WriteLine`, escape sequences `\t \" \\ \n`, verbatim string `@"..."` | Ayşe Yılmaz, Computer Programming |
| 03_02_ClassicHello | the classic `namespace` / `class Program` / `static void Main()` template | (none) |
| 03_03_CircleArea | `const double Pi` vs `Math.PI`, area and circumference, `F4` | 2.5 |
| 03_04_Rectangle | input → process → output with `double` | 4.5, 3 |
| 03_05_CelsiusToFahrenheit | formula with `double`; avoiding the `9 / 5` integer-division trap | 36.6 / 100 / -40 |
| 03_06_Bmi | BMI = weight / height²; parentheses; what `72,5` does with our template | 72.5, 1.78 (and 72,5, 1.78) |
| 03_07_Receipt | `decimal` money, `const decimal VatRate = 0.20m` (KDV), aligned output `{x,10:F2}` | Notebook, 24.90, 3 |
| 03_08_SwapVariables | swapping two variables with a temporary variable | 5, 9 |
| 03_09_SecondsToHms | preview of `/` and `%`: seconds → h:m:s, `D2` padding | 3725 / 86399 |
| 03_10_TypeLimits | `sizeof`, `MinValue` / `MaxValue` of the built-in types; `var` inference | (none) |
| 03_11_CastDemo | implicit widening, explicit casts (truncation), `Convert.ToInt32`, `(byte)300`, silent overflow | (none) |
| 03_12_InputParsing | `ReadLine()` returns a string; `int.Parse`, `double.Parse`, `Convert.ToInt32`, `TryParse` preview | 19, 1.75, 30, 7 (crash demo: nineteen) |
| 03_13_OverflowChecked | `int` wrap-around vs `long` vs `checked(...)` | 100, 23 / 2000000000, 500000000 |
