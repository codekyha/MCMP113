// MCMP113 · Week 13 · Example 6 — recursion: a method that calls itself
// Every recursive method needs a BASE CASE that stops, and a step that gets closer to it.

Console.WriteLine($"Factorial(5) = {Factorial(5)}");
Console.WriteLine($"SumOfDigits(2026) = {SumOfDigits(2026)}");
Console.WriteLine($"Gcd(84, 36) = {Gcd(84, 36)}");
Console.WriteLine();
Console.WriteLine("Call stack of FactorialTrace(4):");
long f = FactorialTrace(4, 0);
Console.WriteLine($"Result: {f}");

// n! = n * (n-1)!, with 0! = 1! = 1
static long Factorial(int n)
{
    if (n <= 1)
    {
        return 1;                          // base case
    }
    return n * Factorial(n - 1);           // recursive case
}

// Sum of the decimal digits of n >= 0: last digit + sum of the others
static int SumOfDigits(int n)
{
    if (n < 10)
    {
        return n;
    }
    return n % 10 + SumOfDigits(n / 10);
}

// Euclid (Week 1): gcd(a, b) = gcd(b, a mod b), and gcd(a, 0) = a
static int Gcd(int a, int b)
{
    if (b == 0)
    {
        return a;
    }
    return Gcd(b, a % b);
}

// Factorial that prints each call and each return, indented by depth
static long FactorialTrace(int n, int depth)
{
    string indent = new string(' ', 2 * depth);
    Console.WriteLine($"{indent}call Factorial({n})");
    long result;
    if (n <= 1)
    {
        result = 1;
    }
    else
    {
        result = n * FactorialTrace(n - 1, depth + 1);
    }
    Console.WriteLine($"{indent}return {result}");
    return result;
}
