// MCMP113 · Week 13 · Example 9 — local functions: capturing variables vs static
// A non-static local function can see the top-level variables; a static one cannot.

int bonus = 5;                          // a top-level variable ("global" for local functions)
Console.WriteLine($"AddBonus(70) = {AddBonus(70)}");
bonus = 10;                             // change it somewhere far away ...
Console.WriteLine($"AddBonus(70) = {AddBonus(70)}   (same call, new result!)");
Console.WriteLine($"AddPoints(70, 5) = {AddPoints(70, 5)}   (everything it needs is a parameter)");

// Hidden state: Visit() changes a variable that is not in its parameter list
int visits = 0;
Visit();
Visit();
Console.WriteLine($"visits = {visits}");

// Shadowing: the parameter n of Square hides the top-level n (allowed, but confusing)
int n = 4;
Console.WriteLine($"Square(9) = {Square(9)}, top-level n is still {n}");

// Captures 'bonus': its result depends on a variable outside the method
int AddBonus(int grade)
{
    return grade + bonus;
}

// Static: can use only its parameters and constants
static int AddPoints(int grade, int points)
{
    // return grade + bonus;  // CS8421: A static local function cannot contain a reference to 'bonus'.
    return grade + points;
}

// Side effect on a captured variable
void Visit()
{
    visits++;
}

// Returns n * n for ITS OWN parameter n
static int Square(int n)
{
    return n * n;
}
