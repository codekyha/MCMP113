// MCMP113 · Week 13 · Example 11 — prime utilities built from one predicate
// IsPrime is written once and reused by NextPrime, CountPrimes and PrimesUpTo.

Console.Write("Upper limit n: ");
int n = int.Parse(Console.ReadLine());

int[] primes = PrimesUpTo(n);
Console.WriteLine($"Primes up to {n}: {string.Join(" ", primes)}");
Console.WriteLine($"Count: {CountPrimes(n)}, next prime after {n}: {NextPrime(n)}");

Console.WriteLine("--- Self-tests ---");
Console.WriteLine(Check(!IsPrime(1) && IsPrime(2) && IsPrime(97) && !IsPrime(91), "IsPrime 1, 2, 97, 91"));
Console.WriteLine(Check(NextPrime(13) == 17 && NextPrime(1) == 2, "NextPrime(13) = 17, NextPrime(1) = 2"));
Console.WriteLine(Check(CountPrimes(100) == 25, "CountPrimes(100) = 25"));

// True if n has exactly two divisors; trial division up to the square root
static bool IsPrime(int n)
{
    if (n < 2)
    {
        return false;
    }
    for (int d = 2; d * d <= n; d++)
    {
        if (n % d == 0)
        {
            return false;               // a divisor found: stop at once
        }
    }
    return true;
}

// Returns the smallest prime that is greater than n
static int NextPrime(int n)
{
    int candidate = n + 1;
    while (!IsPrime(candidate))
    {
        candidate++;
    }
    return candidate;
}

// Returns how many primes are in 2..n
static int CountPrimes(int n)
{
    int count = 0;
    for (int k = 2; k <= n; k++)
    {
        if (IsPrime(k))
        {
            count++;
        }
    }
    return count;
}

// Returns a new array with all primes in 2..n (its length comes from CountPrimes)
static int[] PrimesUpTo(int n)
{
    int[] result = new int[CountPrimes(n)];
    int i = 0;
    for (int k = 2; k <= n; k++)
    {
        if (IsPrime(k))
        {
            result[i] = k;
            i++;
        }
    }
    return result;
}

// Returns "PASS ..." or "FAIL ..." for a test description
static string Check(bool ok, string description)
{
    return (ok ? "PASS  " : "FAIL  ") + description;
}
