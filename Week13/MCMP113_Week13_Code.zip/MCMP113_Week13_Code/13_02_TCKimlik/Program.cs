// MCMP113 · Week 13 · Example 2 — bool predicates: IsEven, IsAllDigits, IsValidTCKimlik
// The Week 1 check-digit algorithm as a method. Only SYNTHETIC numbers are used.

Console.WriteLine($"IsEven(14) = {IsEven(14)}, IsEven(-7) = {IsEven(-7)}");
Console.WriteLine($"-29 % 10 = {-29 % 10}, but Mod(-29, 10) = {Mod(-29, 10)}");
Console.WriteLine();

string[] tests = { "12345678950", "19090909018", "12345678951", "12345678590",
                   "02345678950", "1234567895", "1234567895A" };
foreach (string t in tests)
{
    Console.WriteLine($"{t,-12} -> {IsValidTCKimlik(t)}");
}

Console.Write("Number to check: ");
string input = Console.ReadLine();
if (IsValidTCKimlik(input))
{
    Console.WriteLine("The check digits are correct.");
}
else
{
    Console.WriteLine("Not a valid number (typing error?).");
}

// True if n is divisible by 2 (also for negative n)
static bool IsEven(int n)
{
    return n % 2 == 0;
}

// Mathematical remainder 0..m-1, also for negative a (C# % keeps the sign of a)
static int Mod(int a, int m)
{
    return ((a % m) + m) % m;
}

// True if s is not empty and every character is a digit 0-9
static bool IsAllDigits(string s)
{
    if (s.Length == 0)
    {
        return false;
    }
    foreach (char c in s)
    {
        if (c < '0' || c > '9')
        {
            return false;                    // one bad character is enough
        }
    }
    return true;
}

// True if id has 11 digits, d1 != 0 and both check digits d10, d11 are right
static bool IsValidTCKimlik(string id)
{
    if (id.Length != 11 || !IsAllDigits(id) || id[0] == '0')
    {
        return false;
    }
    int[] d = new int[11];
    for (int i = 0; i < 11; i++)
    {
        d[i] = id[i] - '0';                  // char '7' -> int 7
    }
    int oddSum = d[0] + d[2] + d[4] + d[6] + d[8];
    int evenSum = d[1] + d[3] + d[5] + d[7];
    int d10 = Mod(7 * oddSum - evenSum, 10); // may be negative before Mod!
    int d11 = (oddSum + evenSum + d10) % 10;
    return d[9] == d10 && d[10] == d11;
}
