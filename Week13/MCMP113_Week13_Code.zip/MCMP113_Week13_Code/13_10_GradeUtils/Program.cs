// MCMP113 · Week 13 · Example 10 — a small grade utility "library" with self-tests
// Each method does ONE job and returns a value; Check() prints PASS/FAIL for known answers.

Console.WriteLine("--- Self-tests ---");
bool[] results =
{
    Check("Average {50, 70, 90} = 70", Average(new int[] { 50, 70, 90 }) == 70),
    Check("LetterGrade(90) = AA", LetterGrade(90) == "AA"),
    Check("LetterGrade(89.5) = BA", LetterGrade(89.5) == "BA"),
    Check("LetterGrade(59.9) = FF", LetterGrade(59.9) == "FF"),
    Check("GradePoint(\"CB\") = 2.5", GradePoint("CB") == 2.5),
    Check("IsPassing(\"DD\")", IsPassing("DD")),
    Check("!IsPassing(\"FF\")", !IsPassing("FF")),
};
Console.WriteLine($"{CountTrue(results)} of {results.Length} tests passed");

Console.WriteLine("--- Report ---");
string[] names = { "Ayse", "Mehmet", "Zeynep", "Can" };
int[][] scores =
{
    new int[] { 78, 85, 92 },
    new int[] { 55, 61, 49 },
    new int[] { 95, 88, 91 },
    new int[] { 40, 52, 58 },
};
for (int i = 0; i < names.Length; i++)
{
    double avg = Average(scores[i]);
    string letter = LetterGrade(avg);
    string status = IsPassing(letter) ? "passed" : "failed";
    Console.WriteLine($"{names[i],-8} {avg,6:F2}  {letter}  {GradePoint(letter):F1}  {status}");
}

// Returns the mean of the scores
static double Average(int[] a)
{
    int sum = 0;
    foreach (int x in a)
    {
        sum += x;
    }
    return (double)sum / a.Length;
}

// Returns the letter for a (possibly fractional) score; example scale from Week 5
static string LetterGrade(double score)
{
    return score switch
    {
        >= 90 => "AA",
        >= 85 => "BA",
        >= 80 => "BB",
        >= 75 => "CB",
        >= 70 => "CC",
        >= 65 => "DC",
        >= 60 => "DD",
        _ => "FF"
    };
}

// Returns the grade point of a letter on the 4-point scale
static double GradePoint(string letter)
{
    return letter switch
    {
        "AA" => 4.0,
        "BA" => 3.5,
        "BB" => 3.0,
        "CB" => 2.5,
        "CC" => 2.0,
        "DC" => 1.5,
        "DD" => 1.0,
        _ => 0.0
    };
}

// True for every letter except FF (example rule)
static bool IsPassing(string letter)
{
    return letter != "FF";
}

// Prints PASS or FAIL with a description and returns the result
static bool Check(string description, bool ok)
{
    string verdict = ok ? "PASS" : "FAIL";
    Console.WriteLine($"{verdict}  {description}");
    return ok;
}

// Counts the true values in an array of bools
static int CountTrue(bool[] values)
{
    int count = 0;
    foreach (bool v in values)
    {
        if (v)
        {
            count++;
        }
    }
    return count;
}
