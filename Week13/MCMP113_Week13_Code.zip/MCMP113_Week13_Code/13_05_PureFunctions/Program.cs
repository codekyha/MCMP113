// MCMP113 · Week 13 · Example 5 — composition, pure functions and side effects
// Calls inside calls; a pure function always gives the same result and changes nothing else.

const double VatRate = 0.20;           // a constant may be used everywhere
int[] grades = { 72, 58, 91 };

// Composition: the result of one call is the argument of the next
Console.WriteLine($"Max(Max(8, 15), 11) = {Max(Max(8, 15), 11)}");
double price = 250;
Console.WriteLine($"WithVat(Discount(250, 10)) = {WithVat(Discount(price, 10)):F2} TL");

// A pure function: same input -> same output, every time
Console.WriteLine($"Average: {Average(grades):F2}, again: {Average(grades):F2}");
Console.WriteLine($"Passed? {Average(grades) >= 60}");   // the value can be reused

// A method with a side effect: it changes the caller's array
Console.WriteLine($"Average after Curve: {CurveAndAverage(grades):F2}");
Console.WriteLine($"Average after Curve: {CurveAndAverage(grades):F2}");
Console.WriteLine($"grades is now: {string.Join(" ", grades)}");

// Returns the larger of a and b
static int Max(int a, int b)
{
    return a > b ? a : b;
}

// Returns the price reduced by percent %
static double Discount(double price, double percent)
{
    return price * (1 - percent / 100);
}

// Returns the price with VAT added (VatRate is a constant, not a variable)
static double WithVat(double price)
{
    return price * (1 + VatRate);
}

// Returns the mean of the array; reads it, changes nothing (pure)
static double Average(int[] a)
{
    int sum = 0;
    foreach (int x in a)
    {
        sum += x;
    }
    return (double)sum / a.Length;
}

// Adds 5 points to every grade (side effect!) and returns the new mean
static double CurveAndAverage(int[] a)
{
    for (int i = 0; i < a.Length; i++)
    {
        a[i] += 5;                     // writes into the caller's array
    }
    return Average(a);
}
