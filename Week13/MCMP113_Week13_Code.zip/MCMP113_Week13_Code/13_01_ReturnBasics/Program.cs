// MCMP113 · Week 13 · Example 1 — return: value-returning and void methods
// A value-returning method hands a result back; return also ENDS the method at once.

PrintTitle("Value-returning");
int sq = Square(7);                        // the call is replaced by its value
Console.WriteLine($"Square(7) = {sq}");
Console.WriteLine($"Square(3) + Square(4) = {Square(3) + Square(4)}");
Console.WriteLine($"Sign(-8) = {Sign(-8)}, Sign(0) = {Sign(0)}, Sign(5) = {Sign(5)}");

PrintTitle("Early return");
int[] scores = { 95, 87, 72, 64, 41, 105 };
foreach (int score in scores)
{
    Console.WriteLine($"{score,4} -> {LetterGrade(score)}");
}

PrintTitle("void with return;");
PrintQuotient(17, 5);
PrintQuotient(17, 0);

// Prints a title between two lines of '=' (an action: void, returns nothing)
static void PrintTitle(string title)
{
    string line = new string('=', title.Length + 4);
    Console.WriteLine(line);
    Console.WriteLine($"  {title}");
    Console.WriteLine(line);
}

// Returns x squared (a computation: no printing inside)
static int Square(int x)
{
    return x * x;
}

// Returns 1, -1 or 0; every path ends with a return
static int Sign(int n)
{
    if (n > 0)
    {
        return 1;
    }
    if (n < 0)
    {
        return -1;
    }
    return 0;
}

// Returns the letter grade; the first return that runs ends the method
static string LetterGrade(int score)
{
    if (score < 0 || score > 100)
    {
        return "invalid";                  // guard clause: bad input first
    }
    return score switch                    // example scale (see Week 5)
    {
        >= 90 => "AA",
        >= 85 => "BA",
        >= 80 => "BB",
        >= 75 => "CB",
        >= 70 => "CC",
        >= 65 => "DC",
        >= 60 => "DD",
        _ => "FF"
    };
}

// Prints a / b, or a message; "return;" leaves a void method early
static void PrintQuotient(int a, int b)
{
    if (b == 0)
    {
        Console.WriteLine($"{a} / {b}: cannot divide by zero");
        return;                            // nothing after this line runs
    }
    Console.WriteLine($"{a} / {b} = {a / b} remainder {a % b}");
}
