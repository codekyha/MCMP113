// MCMP113 · Week 13 · Example 4 — returning two values: out parameters and tuples
// Same job (min and max of an array) written twice; plus a quotient/remainder tuple.

int[] temps = { 14, 9, 21, 17, 6, 12 };
Console.WriteLine($"temps: {string.Join(" ", temps)}");

// Version 1: out parameters (like int.TryParse)
MinMaxOut(temps, out int low, out int high);
Console.WriteLine($"out:   min = {low}, max = {high}");

// Version 2: a tuple, deconstructed into two new variables
(int min, int max) = MinMax(temps);
Console.WriteLine($"tuple: min = {min}, max = {max}, range = {max - min}");

// A tuple can also be kept whole; the parts have names
var result = MinMax(new int[] { 3, -5, 8 });
Console.WriteLine($"whole: result.min = {result.min}, result.max = {result.max}");

(int q, int r) = DivMod(47, 6);
Console.WriteLine($"47 = 6 * {q} + {r}");

// Writes the smallest and the largest element of a into the two out variables
static void MinMaxOut(int[] a, out int min, out int max)
{
    min = a[0];                         // an out parameter MUST be assigned
    max = a[0];
    for (int i = 1; i < a.Length; i++)
    {
        if (a[i] < min)
        {
            min = a[i];
        }
        if (a[i] > max)
        {
            max = a[i];
        }
    }
}

// Returns the smallest and the largest element of a as a named tuple
static (int min, int max) MinMax(int[] a)
{
    int min = a[0];
    int max = a[0];
    foreach (int x in a)
    {
        if (x < min)
        {
            min = x;
        }
        if (x > max)
        {
            max = x;
        }
    }
    return (min, max);                  // two values in one return
}

// Returns the integer quotient and the remainder of a / b
static (int quotient, int remainder) DivMod(int a, int b)
{
    return (a / b, a % b);
}
