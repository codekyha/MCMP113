// MCMP113 · Week 13 · Example 3 — methods that return arrays
// ReadArray creates and fills a new array; ReverseCopy and EvensOnly leave the original unchanged.

Console.Write("How many numbers? ");
int n = int.Parse(Console.ReadLine());
int[] data = ReadArray(n);

int[] backwards = ReverseCopy(data);
int[] evens = EvensOnly(data);

PrintArray("data    ", data);
PrintArray("reversed", backwards);
PrintArray("evens   ", evens);
PrintArray("data    ", data);          // still in the original order

// Reads n integers from the keyboard and returns them in a new array
static int[] ReadArray(int n)
{
    int[] result = new int[n];
    for (int i = 0; i < n; i++)
    {
        Console.Write($"  value {i + 1}: ");
        result[i] = int.Parse(Console.ReadLine());
    }
    return result;                      // the caller receives the reference
}

// Returns a NEW array with the elements of a in reverse order
static int[] ReverseCopy(int[] a)
{
    int[] copy = new int[a.Length];
    for (int i = 0; i < a.Length; i++)
    {
        copy[a.Length - 1 - i] = a[i];
    }
    return copy;
}

// Returns a new array that holds only the even elements of a (two passes)
static int[] EvensOnly(int[] a)
{
    int count = 0;
    foreach (int x in a)                // pass 1: how big must the result be?
    {
        if (x % 2 == 0)
        {
            count++;
        }
    }
    int[] result = new int[count];
    int k = 0;
    foreach (int x in a)                // pass 2: copy the even values
    {
        if (x % 2 == 0)
        {
            result[k] = x;
            k++;
        }
    }
    return result;
}

// Prints a label and the elements of a on one line
static void PrintArray(string label, int[] a)
{
    Console.WriteLine($"{label}: [{string.Join(", ", a)}]  (Length {a.Length})");
}
