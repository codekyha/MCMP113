// MCMP113 · Week 13 · Example 8 — scope and lifetime of variables
// A variable lives from its declaration to the closing } of its block.
// The commented-out lines do NOT compile; the real compiler error is written next to them.

int total = 0;                          // scope: the rest of the top-level code
for (int i = 1; i <= 3; i++)            // i: only inside the for statement
{
    int square = i * i;                 // square: only inside this { }, new each pass
    total += square;
}
// Console.WriteLine(square);  // CS0103: The name 'square' does not exist in the current context
// Console.WriteLine(i);       // CS0103: The name 'i' does not exist in the current context
Console.WriteLine($"total = {total}");

if (total > 10)
{
    string message = "big";             // two SIBLING blocks may reuse a name
    Console.WriteLine(message);
}
else
{
    string message = "small";
    Console.WriteLine(message);
}

for (int k = 0; k < 2; k++)
{
    // int total = k;          // CS0136: A local or parameter named 'total' cannot be declared
                               //         in this scope because that name is used in an
                               //         enclosing local scope to define a local or parameter
    Console.WriteLine($"k = {k}, total = {total}");
}
// int total = 5;              // CS0128: A local variable or function named 'total' is already
                               //         defined in this scope

// Lifetime: a local variable is created again at every call
CountCalls();
CountCalls();
CountCalls();

// A parameter is a local variable that holds a COPY of the argument
int points = 40;
TryToChange(points);
Console.WriteLine($"after TryToChange: points = {points}");

// Prints how often it has been called... or does it?
static void CountCalls()
{
    int calls = 0;                      // born here, dies at the closing }
    calls++;
    Console.WriteLine($"CountCalls: calls = {calls}");
}

// Changes only its own copy of the argument
static void TryToChange(int value)
{
    value = 100;
    Console.WriteLine($"inside TryToChange: value = {value}");
}
