# MCMP113 · Introduction to Basic Algorithms and Programming
## Week 13 — example code pack

Asst. Prof. Hasan Oğuz, PhD · Istanbul Okan University · 2026–2027 Fall

Every folder in this pack is a **separate, complete C# console project** (`.csproj` + `Program.cs`) for .NET 10.
All programs were built with 0 errors / 0 warnings and run with the sample inputs listed below.

### Getting started
1. Install the **.NET 10 SDK** (https://dotnet.microsoft.com/en-us/download/dotnet/10.0) and **Visual Studio Code** with the **C# Dev Kit** extension.
2. Unzip this pack, e.g. to `Documents\MCMP113\Week13`.
3. Run one example from a terminal:
   ```
   cd 13_01_ReturnBasics
   dotnet run
   ```
4. Or open the whole pack in VS Code (`File → Open Folder…`). The solution file `MCMP113_Week13_Code.sln` lists all projects; in the C# Dev Kit *Solution Explorer* right-click a project → *Debug → Start New Instance*.

### Notes
* Programs are written with **top-level statements** (no `class Program`/`Main` needed).
* The course project template turns off nullable warnings and uses **invariant culture**, so decimal numbers are typed with a **point** (`72.5`) even on Turkish-language Windows.
* Typing input: when a program waits, type a value and press **Enter**. Stop a running program with **Ctrl + C**.
* `bin/` and `obj/` folders are created automatically on the first build; you may delete them at any time.

---


Each folder is a separate .NET 10 console project (course template: Nullable disabled,
InvariantGlobalization on). Open the folder in VS Code and press Run, or type `dotnet run` inside it.
All programs were built with 0 errors / 0 warnings and run with the sample input below;
the transcripts on the slides and in the notes are real output of these runs.
Methods are local functions placed at the bottom of Program.cs, each with a one-line `//` comment.
Lines that are commented out with a compiler error code (CS0103, CS0136, CS0128, CS8421) were
uncommented one at a time and built: the compiler reports exactly that error.

| Folder | What it shows | Sample input |
|---|---|---|
| `13_01_ReturnBasics` | `return` ends a method; value-returning (`Square`, `Sign`, `LetterGrade` with a guard clause) vs `void` (`PrintTitle`, `PrintQuotient` with `return;`) | none |
| `13_02_TCKimlik` | `bool` predicates `IsEven`, `IsAllDigits`, `IsValidTCKimlik` (Week 1 check digits, safe `Mod` for negative values). **Synthetic numbers only** | `12345678950`; `12345678905` |
| `13_03_ReturnArrays` | Methods that return arrays: `ReadArray(n)`, `ReverseCopy`, `EvensOnly` (count, then fill); the original stays unchanged | `5 8 3 12 7 6` |
| `13_04_MultipleResults` | Two results: `out` parameters vs a named tuple `(int min, int max) MinMax(int[] a)`; `DivMod` | none |
| `13_05_PureFunctions` | Composition `Max(Max(8, 15), 11)`, `WithVat(Discount(...))`; pure `Average` vs `CurveAndAverage` with a side effect; a `const` used by static methods | none |
| `13_06_RecursionBasics` | Recursion: `Factorial`, `SumOfDigits`, `Gcd` (Euclid), call stack trace of `Factorial(4)` | none |
| `13_07_FibonacciRace` | Naive recursive Fibonacci (call counter via `ref`) vs loop: 29 860 703 calls for n = 35 | none |
| `13_08_BlockScope` | Block scope, loop variable scope, sibling blocks, CS0103 / CS0136 / CS0128 as commented-out lines, lifetime of locals, parameters are copies | none |
| `13_09_LocalFunctions` | Non-static local function capturing a top-level variable vs `static` local function (CS8421), hidden state, shadowing by a parameter | none |
| `13_10_GradeUtils` | Grade utility "library" (`Average`, `LetterGrade`, `GradePoint`, `IsPassing`) with PASS/FAIL self-tests and a report | none |
| `13_11_PrimeUtils` | `IsPrime` reused by `NextPrime`, `CountPrimes`, `PrimesUpTo` (returns an array); self-tests | `50` |
| `13_12_StringHelpers` | `CountVowels`, `Reverse`, `IsPalindrome`, `CelsiusToFahrenheit` / `FahrenheitToCelsius` round trip; self-tests | `Kayak`; `Okan University` |
