// MCMP113 · Week 13 · Example 7 — Fibonacci: naive recursion vs a loop
// Both give the same numbers, but the recursive version repeats work exponentially.

Console.Write("First 10 terms:");
for (int i = 0; i < 10; i++)
{
    Console.Write($" {FibLoop(i)}");
}
Console.WriteLine();

Console.WriteLine("  n        Fib(n)   recursive calls   loop passes");
int[] sizes = { 5, 10, 20, 30, 35 };
foreach (int n in sizes)
{
    long calls = 0;
    long viaRecursion = FibRec(n, ref calls);
    long viaLoop = FibLoop(n);
    string same = viaRecursion == viaLoop ? "" : "  MISMATCH";
    Console.WriteLine($"{n,3} {viaLoop,13} {calls,17} {n - 1,13}{same}");
}

// Fib(0) = 0, Fib(1) = 1, Fib(n) = Fib(n-1) + Fib(n-2); counts every call in 'calls'
static long FibRec(int n, ref long calls)
{
    calls++;
    if (n < 2)
    {
        return n;                          // two base cases: 0 and 1
    }
    return FibRec(n - 1, ref calls) + FibRec(n - 2, ref calls);
}

// The same numbers with a loop: n - 1 passes, two variables
static long FibLoop(int n)
{
    long previous = 0;
    long current = 1;
    if (n == 0)
    {
        return 0;
    }
    for (int i = 2; i <= n; i++)
    {
        long next = previous + current;
        previous = current;
        current = next;
    }
    return current;
}
