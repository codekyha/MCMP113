// MCMP113 · Week 13 · Example 12 — string helpers and a conversion pair, with self-tests
// Small pure methods: CountVowels, Reverse, IsPalindrome, CelsiusToFahrenheit and back.

Console.Write("Enter a word or sentence: ");
string text = Console.ReadLine();
Console.WriteLine($"Vowels: {CountVowels(text)}");
Console.WriteLine($"Reversed: {Reverse(text)}");
Console.WriteLine($"Palindrome? {IsPalindrome(text)}");

double c = 36.6;
double f = CelsiusToFahrenheit(c);
Console.WriteLine($"{c} C = {f:F2} F, and back: {FahrenheitToCelsius(f):F2} C");

Console.WriteLine("--- Self-tests ---");
int failed = 0;
failed += Test(CountVowels("Programming") == 3, "CountVowels(\"Programming\") = 3");
failed += Test(Reverse("abc") == "cba", "Reverse(\"abc\") = \"cba\"");
failed += Test(IsPalindrome("Ey Edip Adanada pide ye"), "IsPalindrome(\"Ey Edip Adanada pide ye\")");
failed += Test(!IsPalindrome("Okan"), "!IsPalindrome(\"Okan\")");
failed += Test(CelsiusToFahrenheit(100) == 212, "CelsiusToFahrenheit(100) = 212");
failed += Test(Math.Abs(FahrenheitToCelsius(CelsiusToFahrenheit(-40.5)) + 40.5) < 1e-9, "round trip -40.5");
Console.WriteLine(failed == 0 ? "All tests passed." : $"{failed} test(s) failed.");

// Counts the vowels a e i o u (and Turkish ı ö ü), upper or lower case
static int CountVowels(string s)
{
    int count = 0;
    foreach (char ch in s.ToLower())
    {
        if ("aeiouıöü".Contains(ch))
        {
            count++;
        }
    }
    return count;
}

// Returns the characters of s in reverse order
static string Reverse(string s)
{
    string result = "";
    for (int i = s.Length - 1; i >= 0; i--)
    {
        result += s[i];
    }
    return result;
}

// True if s reads the same backwards, ignoring spaces and upper/lower case
static bool IsPalindrome(string s)
{
    string letters = s.Replace(" ", "").ToLower();
    return letters == Reverse(letters);    // reuse Reverse
}

// Converts degrees Celsius to degrees Fahrenheit
static double CelsiusToFahrenheit(double celsius)
{
    return celsius * 9 / 5 + 32;
}

// Converts degrees Fahrenheit to degrees Celsius (the inverse)
static double FahrenheitToCelsius(double fahrenheit)
{
    return (fahrenheit - 32) * 5 / 9;
}

// Prints PASS/FAIL and returns 1 for a failed test, 0 otherwise
static int Test(bool ok, string description)
{
    Console.WriteLine((ok ? "PASS  " : "FAIL  ") + description);
    return ok ? 0 : 1;
}
