// MCMP113 · Week 10 · Example 2 — Second largest value in one pass
// Two "champions": when a new largest appears, the old largest becomes second.

int[] scores = { 72, 85, 64, 85, 90, 78 };
Console.WriteLine("Scores: " + string.Join(", ", scores));

int largest = scores[0];
int second = 0;
bool hasSecond = false;     // no second value seen yet
for (int i = 1; i < scores.Length; i++)
{
    if (scores[i] > largest)
    {
        second = largest;   // old champion moves down
        hasSecond = true;
        largest = scores[i];
    }
    else if (scores[i] < largest && (!hasSecond || scores[i] > second))
    {
        second = scores[i];  // beats only the runner-up
        hasSecond = true;
    }
    // scores[i] == largest: a duplicate, ignore it
}

Console.WriteLine($"Largest: {largest}");
if (hasSecond)
{
    Console.WriteLine($"Second largest: {second}");
}
else
{
    Console.WriteLine("No second largest: all values equal.");
}
