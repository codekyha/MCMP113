// MCMP113 · Week 10 · Example 5 — Binary search on a sorted array (with a trace)
// Like guess-the-number: look at the middle and throw away half of the range.

// the data MUST be sorted
int[] a = { 4, 9, 13, 18, 22, 27, 31, 36, 40, 45, 51, 58, 63, 70, 77 };
Console.WriteLine("a: " + string.Join(" ", a));
Console.Write("Search for: ");
int target = int.Parse(Console.ReadLine());

int low = 0;
int high = a.Length - 1;
int index = -1;          // -1 = not found (yet)
int step = 0;
while (low <= high && index == -1)
{
    int mid = (low + high) / 2;          // integer division
    step++;
    Console.Write($"Step {step}: low={low} high={high} ");
    Console.WriteLine($"mid={mid} a[mid]={a[mid]}");
    if (a[mid] == target)
    {
        index = mid;
    }
    else if (a[mid] < target)
    {
        low = mid + 1;                   // go right
    }
    else
    {
        high = mid - 1;                  // go left
    }
}

if (index >= 0)
{
    Console.WriteLine($"Found at index {index}, steps: {step}");
}
else
{
    Console.WriteLine($"Not found (low > high), steps: {step}");
}
