// MCMP113 · Week 10 · Example 1 — Maximum and minimum with their index
// Start from the first element (not from 0) and remember WHERE the extreme value is.

Console.Write("How many days? ");
int n = int.Parse(Console.ReadLine());
double[] temps = new double[n];
for (int i = 0; i < n; i++)
{
    Console.Write($"Temperature of day {i + 1}: ");
    temps[i] = double.Parse(Console.ReadLine());
}

double max = temps[0];       // first element = first candidate
double min = temps[0];
int maxIndex = 0;
int minIndex = 0;
for (int i = 1; i < n; i++)  // temps[0] is already used
{
    if (temps[i] > max)
    {
        max = temps[i];
        maxIndex = i;
    }
    if (temps[i] < min)
    {
        min = temps[i];
        minIndex = i;
    }
}

Console.WriteLine($"Warmest: {max} on day {maxIndex + 1} (index {maxIndex})");
Console.WriteLine($"Coldest: {min} on day {minIndex + 1} (index {minIndex})");

// The classic mistake: starting the maximum at 0
double wrongMax = 0;
for (int i = 0; i < n; i++)
{
    if (temps[i] > wrongMax)
    {
        wrongMax = temps[i];
    }
}
Console.WriteLine($"Max if we start at 0: {wrongMax}");
