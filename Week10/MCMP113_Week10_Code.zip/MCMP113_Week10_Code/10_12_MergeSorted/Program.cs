// MCMP113 · Week 10 · Example 12 — Merge two sorted arrays into one sorted array
// Compare the two front elements, copy the smaller one, advance in that array.

int[] a = { 3, 8, 15, 21 };
int[] b = { 1, 9, 10, 22, 30 };
int[] c = new int[a.Length + b.Length];
Console.WriteLine("a: " + string.Join(" ", a));
Console.WriteLine("b: " + string.Join(" ", b));

int i = 0;   // next unused index in a
int j = 0;   // next unused index in b
int k = 0;   // next free index in c
while (i < a.Length && j < b.Length)
{
    if (a[i] <= b[j])
    {
        c[k] = a[i];
        i++;
    }
    else
    {
        c[k] = b[j];
        j++;
    }
    k++;
}
while (i < a.Length)   // copy what is left of a
{
    c[k] = a[i];
    i++;
    k++;
}
while (j < b.Length)   // copy what is left of b
{
    c[k] = b[j];
    j++;
    k++;
}

Console.WriteLine("merged: " + string.Join(" ", c));
