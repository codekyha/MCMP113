// MCMP113 · Week 10 · Example 9 — Built-in helpers of the Array class
// What professionals use: Array.Sort, Array.Reverse, Array.IndexOf, Array.BinarySearch.

int[] a = { 31, 12, 47, 8, 25, 19 };
Console.WriteLine("Original:      " + string.Join(" ", a));

Console.WriteLine($"IndexOf(25):   {Array.IndexOf(a, 25)}");
Console.WriteLine($"IndexOf(99):   {Array.IndexOf(a, 99)}"); // -1

Array.Sort(a);                    // ascending, in place
Console.WriteLine("After Sort:    " + string.Join(" ", a));

Console.WriteLine($"BinarySearch(25): {Array.BinarySearch(a, 25)}");
int pos = Array.BinarySearch(a, 20); // < 0: not found
Console.WriteLine($"BinarySearch(20): {pos}  (insert at {-pos - 1})");

Array.Reverse(a);                 // now descending
Console.WriteLine("After Reverse: " + string.Join(" ", a));

string[] names = { "Zeynep", "ali", "Can", "Deniz", "Emre" };
Array.Sort(names);  // our template: ordinal, capitals first
Console.WriteLine("Ordinal:     " + string.Join(", ", names));
Array.Sort(names, StringComparer.OrdinalIgnoreCase);
Console.WriteLine("Ignore case: " + string.Join(", ", names));
