# MCMP113 · Introduction to Basic Algorithms and Programming
## Week 10 — example code pack

Asst. Prof. Hasan Oğuz, PhD · Istanbul Okan University · 2026–2027 Fall

Every folder in this pack is a **separate, complete C# console project** (`.csproj` + `Program.cs`) for .NET 10.
All programs were built with 0 errors / 0 warnings and run with the sample inputs listed below.

### Getting started
1. Install the **.NET 10 SDK** (https://dotnet.microsoft.com/en-us/download/dotnet/10.0) and **Visual Studio Code** with the **C# Dev Kit** extension.
2. Unzip this pack, e.g. to `Documents\MCMP113\Week10`.
3. Run one example from a terminal:
   ```
   cd 10_01_MaxMinIndex
   dotnet run
   ```
4. Or open the whole pack in VS Code (`File → Open Folder…`). The solution file `MCMP113_Week10_Code.sln` lists all projects; in the C# Dev Kit *Solution Explorer* right-click a project → *Debug → Start New Instance*.

### Notes
* Programs are written with **top-level statements** (no `class Program`/`Main` needed).
* The course project template turns off nullable warnings and uses **invariant culture**, so decimal numbers are typed with a **point** (`72.5`) even on Turkish-language Windows.
* Typing input: when a program waits, type a value and press **Enter**. Stop a running program with **Ctrl + C**.
* `bin/` and `obj/` folders are created automatically on the first build; you may delete them at any time.

---


Each folder is a separate .NET 10 console project (course template: Nullable disabled,
InvariantGlobalization on). Open the folder in VS Code and press Run, or type `dotnet run` inside it.
All programs were built with 0 errors / 0 warnings and run with the sample input below;
the transcripts on the slides and in the notes are real output of these runs.
No user-defined methods (Week 12) and no LINQ: everything is top-level statements with loops.

| Folder | What it shows | Sample input |
|---|---|---|
| `10_01_MaxMinIndex` | Max and min with their index (start with `temps[0]`, loop from 1); the "start the maximum at 0" bug | `5 12.5 18 9.5 21 15`; `4 -3.5 -1 -7.25 -2` |
| `10_02_SecondLargest` | Second largest different value in one pass (two champions, `hasSecond` flag, duplicates ignored) | none (fixed data) |
| `10_03_GradeStatistics` | Sum, mean, variance, standard deviation (two passes, `Math.Sqrt`), counting with conditions | `6 72 45 88 60 95 38` |
| `10_04_LinearSearch` | Linear search: first index with early exit (flag, −1 = not found, check counter), all positions, count | `78`; `50` |
| `10_05_BinarySearch` | Binary search on a sorted array with a printed low/mid/high trace | `58`; `20`; `77` |
| `10_06_BubbleSort` | Bubble sort with early exit (`swapped` flag), pass-by-pass output, comparison and swap counters | none |
| `10_07_SelectionSort` | Selection sort, pass by pass, at most one swap per pass, counters | none |
| `10_08_InsertionSort` | Insertion sort (optional): shift bigger values right, insert the key; counters | none |
| `10_09_ArrayBuiltIns` | `Array.IndexOf`, `Array.Sort`, `Array.BinarySearch` (negative result → insertion point), `Array.Reverse`, sorting strings (ordinal vs `OrdinalIgnoreCase`) | none |
| `10_10_ReverseRotate` | Reverse in place with two indices (temp swap; tuple swap in a comment), rotate left by k with `(i - k + n) % n` | `3`; `9` |
| `10_11_RemoveDuplicates` | Remove duplicates from a sorted array with a write index, copy to a shorter array | none |
| `10_12_MergeSorted` | Merge two sorted arrays with three indices (★★★) | none |
| `10_13_SortingRace` | Counting the work for n = 10 … 10 000 (seeded `Random(2026)`): linear vs binary search, bubble vs selection sort comparisons/swaps, `Stopwatch` | none (the last column, milliseconds, differs from run to run and from PC to PC; all other columns are fixed) |
