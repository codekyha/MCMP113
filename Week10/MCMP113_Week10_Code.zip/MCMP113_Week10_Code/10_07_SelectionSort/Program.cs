// MCMP113 · Week 10 · Example 7 — Selection sort, pass by pass
// Find the smallest element of the unsorted part and put it at the front with ONE swap.

int[] a = { 31, 12, 47, 8, 25, 19 };
int n = a.Length;
Console.WriteLine("Start:  " + string.Join(" ", a));

int comparisons = 0;
int swaps = 0;
for (int i = 0; i < n - 1; i++)
{
    int minIndex = i;          // where the smallest is
    for (int j = i + 1; j < n; j++)
    {
        comparisons++;
        if (a[j] < a[minIndex])
        {
            minIndex = j;
        }
    }
    if (minIndex != i)         // at most one swap per pass
    {
        int temp = a[i];
        a[i] = a[minIndex];
        a[minIndex] = temp;
        swaps++;
    }
    Console.Write($"Pass {i + 1}: " + string.Join(" ", a));
    Console.WriteLine($"   (min = {a[i]})");
}

Console.WriteLine("Sorted: " + string.Join(" ", a));
Console.WriteLine($"Comparisons: {comparisons}, swaps: {swaps}");
