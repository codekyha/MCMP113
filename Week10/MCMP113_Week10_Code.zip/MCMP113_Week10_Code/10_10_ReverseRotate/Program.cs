// MCMP113 · Week 10 · Example 10 — Reverse in place and rotate an array
// Two indices walk towards each other; rotation uses a second array and the remainder %.

int[] a = { 1, 2, 3, 4, 5, 6, 7 };
Console.WriteLine("Original:       " + string.Join(" ", a));

// reverse in place: swap the outer pair, move inwards
int left = 0;
int right = a.Length - 1;
while (left < right)
{
    int temp = a[left];
    a[left] = a[right];
    a[right] = temp;
    // one-line tuple swap (same effect):
    // (a[left], a[right]) = (a[right], a[left]);
    left++;
    right--;
}
Console.WriteLine("Reversed:       " + string.Join(" ", a));

// rotate LEFT by k: element i moves to (i - k + n) % n
int[] b = { 1, 2, 3, 4, 5, 6, 7 };
int n = b.Length;
Console.Write("Rotate left by k = ");
int k = int.Parse(Console.ReadLine()) % n; // k = n: no change
int[] rotated = new int[n];
for (int i = 0; i < n; i++)
{
    rotated[(i - k + n) % n] = b[i];
}
Console.WriteLine("Rotated left:   " + string.Join(" ", rotated));
