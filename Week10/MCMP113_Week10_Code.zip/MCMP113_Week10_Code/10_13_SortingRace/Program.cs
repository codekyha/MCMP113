// MCMP113 · Week 10 · Example 13 — Counting the work: search and sort for growing n
// Instrumented loops count comparisons; a fixed Random seed gives the same data on every run.

int[] sizes = { 10, 100, 1000, 10000 };
Random rng = new Random(2026);  // fixed seed: same data each run
int target = 1000000;           // not in the data (0..999999)

Console.Write("     n  linear  binary  ");
Console.WriteLine("bubble-cmp  bubble-swp  select-cmp  select-swp  bubble-ms");
for (int s = 0; s < sizes.Length; s++)
{
    int n = sizes[s];
    int[] data = new int[n];
    for (int i = 0; i < n; i++)
    {
        data[i] = rng.Next(0, 1000000);
    }

    // linear search for a missing value: worst case
    int linear = 0;
    for (int i = 0; i < n; i++)
    {
        linear++;
        if (data[i] == target)
        {
            break;
        }
    }

    // bubble sort (with early exit) on a copy
    int[] b = (int[])data.Clone();
    long bubbleCmp = 0;
    long bubbleSwp = 0;
    var watch = System.Diagnostics.Stopwatch.StartNew();
    for (int pass = 1; pass <= n - 1; pass++)
    {
        bool swapped = false;
        for (int j = 0; j < n - pass; j++)
        {
            bubbleCmp++;
            if (b[j] > b[j + 1])
            {
                int temp = b[j];
                b[j] = b[j + 1];
                b[j + 1] = temp;
                bubbleSwp++;
                swapped = true;
            }
        }
        if (!swapped)
        {
            break;
        }
    }
    watch.Stop();

    // selection sort on another copy
    int[] c = (int[])data.Clone();
    long selectCmp = 0;
    long selectSwp = 0;
    for (int i = 0; i < n - 1; i++)
    {
        int minIndex = i;
        for (int j = i + 1; j < n; j++)
        {
            selectCmp++;
            if (c[j] < c[minIndex])
            {
                minIndex = j;
            }
        }
        if (minIndex != i)
        {
            int temp = c[i];
            c[i] = c[minIndex];
            c[minIndex] = temp;
            selectSwp++;
        }
    }

    // binary search for the missing value in the sorted copy
    int binary = 0;
    int low = 0;
    int high = n - 1;
    bool found = false;
    while (low <= high && !found)
    {
        int mid = (low + high) / 2;
        binary++;
        if (b[mid] == target)
        {
            found = true;
        }
        else if (b[mid] < target)
        {
            low = mid + 1;
        }
        else
        {
            high = mid - 1;
        }
    }

    Console.Write($"{n,6}  {linear,6}  {binary,6}  ");
    Console.Write($"{bubbleCmp,10}  {bubbleSwp,10}  ");
    Console.Write($"{selectCmp,10}  {selectSwp,10}  ");
    Console.WriteLine($"{watch.ElapsedMilliseconds,9}");
}
Console.WriteLine("Worst case of both sorts: n(n-1)/2 comparisons.");
