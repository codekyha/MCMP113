// MCMP113 · Week 10 · Example 4 — Linear search: first index, all positions, count
// Look at the elements one by one; stop early when only the first match is needed.

int[] scores = { 45, 78, 92, 60, 78, 55, 83, 78 };
Console.WriteLine("Scores: " + string.Join(" ", scores));
Console.Write("Search for: ");
int target = int.Parse(Console.ReadLine());

// 1) first occurrence: stop as soon as it is found
int index = -1;          // -1 means "not found"
bool found = false;
int comparisons = 0;
int i = 0;
while (i < scores.Length && !found)
{
    comparisons++;
    if (scores[i] == target)
    {
        found = true;
        index = i;
    }
    i++;
}

if (found)
{
    Console.WriteLine($"First at index {index}: {comparisons} checks");
}
else
{
    Console.WriteLine($"Not found: {comparisons} checks");
}

// 2) all positions and the count: check EVERY element
int count = 0;
Console.Write("All positions:");
for (int k = 0; k < scores.Length; k++)
{
    if (scores[k] == target)
    {
        Console.Write($" {k}");
        count++;
    }
}
Console.WriteLine();
Console.WriteLine($"Count: {count}");
