// MCMP113 · Week 10 · Example 6 — Bubble sort with early exit, pass by pass
// Neighbours that are in the wrong order are swapped; the largest value "bubbles" to the end.

int[] a = { 31, 12, 47, 8, 25, 19 };
int n = a.Length;
Console.WriteLine("Start:  " + string.Join(" ", a));

int comparisons = 0;
int swaps = 0;
for (int pass = 1; pass <= n - 1; pass++)
{
    bool swapped = false;              // no swap yet
    for (int j = 0; j < n - pass; j++) // tail is sorted
    {
        comparisons++;
        if (a[j] > a[j + 1])
        {
            int temp = a[j];           // swap via temp
            a[j] = a[j + 1];
            a[j + 1] = temp;
            swapped = true;
            swaps++;
        }
    }
    Console.WriteLine($"Pass {pass}: " + string.Join(" ", a));
    if (!swapped)                      // sorted: stop early
    {
        break;
    }
}

Console.WriteLine("Sorted: " + string.Join(" ", a));
Console.WriteLine($"Comparisons: {comparisons}, swaps: {swaps}");
