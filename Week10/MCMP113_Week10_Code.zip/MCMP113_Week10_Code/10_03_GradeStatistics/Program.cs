// MCMP113 · Week 10 · Example 3 — Grade statistics: mean, standard deviation, counting
// Two passes: first the mean, then the squared distances from the mean.

Console.Write("Number of students: ");
int n = int.Parse(Console.ReadLine());
double[] grades = new double[n];
for (int i = 0; i < n; i++)
{
    Console.Write($"Grade {i + 1}: ");
    grades[i] = double.Parse(Console.ReadLine());
}

// pass 1: sum and mean
double sum = 0;
for (int i = 0; i < n; i++)
{
    sum += grades[i];
}
double mean = sum / n;

// pass 2: variance = average of squared distances
double squares = 0;
for (int i = 0; i < n; i++)
{
    double d = grades[i] - mean;
    squares += d * d;
}
double variance = squares / n;
double sigma = Math.Sqrt(variance);

// counting with a condition
int passed = 0;
int aboveMean = 0;
for (int i = 0; i < n; i++)
{
    if (grades[i] >= 50)
    {
        passed++;
    }
    if (grades[i] > mean)
    {
        aboveMean++;
    }
}

Console.WriteLine($"Sum      = {sum}");
Console.WriteLine($"Mean     = {mean:F2}");
Console.WriteLine($"Variance = {variance:F2}");
Console.WriteLine($"Std dev  = {sigma:F2}");
Console.WriteLine($"Passed (>= 50): {passed} of {n}");
Console.WriteLine($"Above the mean: {aboveMean} of {n}");
