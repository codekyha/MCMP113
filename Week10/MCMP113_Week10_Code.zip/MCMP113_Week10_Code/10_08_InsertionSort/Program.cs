// MCMP113 · Week 10 · Example 8 — Insertion sort (optional), pass by pass
// Like sorting playing cards in your hand: take the next card, shift bigger cards right, insert.

int[] a = { 31, 12, 47, 8, 25, 19 };
int n = a.Length;
Console.WriteLine("Start:  " + string.Join(" ", a));

int comparisons = 0;
int shifts = 0;
for (int i = 1; i < n; i++)
{
    int key = a[i];            // the "card" to insert
    int j = i - 1;
    while (j >= 0)
    {
        comparisons++;
        if (a[j] > key)
        {
            a[j + 1] = a[j];   // shift one cell right
            shifts++;
            j--;
        }
        else
        {
            break;             // found the place
        }
    }
    a[j + 1] = key;
    Console.Write($"Pass {i}: " + string.Join(" ", a));
    Console.WriteLine($"   ({key} -> [{j + 1}])");
}

Console.WriteLine("Sorted: " + string.Join(" ", a));
Console.WriteLine($"Comparisons: {comparisons}, shifts: {shifts}");
