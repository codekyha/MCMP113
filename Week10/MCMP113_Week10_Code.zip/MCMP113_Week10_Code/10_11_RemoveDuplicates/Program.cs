// MCMP113 · Week 10 · Example 11 — Remove duplicates from a SORTED array
// In a sorted array equal values are neighbours: keep a value only if it differs from the last kept one.

int[] a = { 2, 2, 3, 5, 5, 5, 8, 9, 9 };
Console.WriteLine("Sorted input: " + string.Join(" ", a));

int unique = 1;                 // a[0] is always kept
for (int i = 1; i < a.Length; i++)
{
    if (a[i] != a[unique - 1])  // new value?
    {
        a[unique] = a[i];       // next free cell
        unique++;
    }
}

int[] result = new int[unique]; // keep first cells
for (int i = 0; i < unique; i++)
{
    result[i] = a[i];
}
Console.WriteLine($"Unique ({unique}): " + string.Join(" ", result));
Console.WriteLine($"Removed duplicates: {a.Length - unique}");
