# MCMP113 · Introduction to Basic Algorithms and Programming
## Week 12 — example code pack

Asst. Prof. Hasan Oğuz, PhD · Istanbul Okan University · 2026–2027 Fall

Every folder in this pack is a **separate, complete C# console project** (`.csproj` + `Program.cs`) for .NET 10.
All programs were built with 0 errors / 0 warnings and run with the sample inputs listed below.

### Getting started
1. Install the **.NET 10 SDK** (https://dotnet.microsoft.com/en-us/download/dotnet/10.0) and **Visual Studio Code** with the **C# Dev Kit** extension.
2. Unzip this pack, e.g. to `Documents\MCMP113\Week12`.
3. Run one example from a terminal:
   ```
   cd 12_01_WhyMethods
   dotnet run
   ```
4. Or open the whole pack in VS Code (`File → Open Folder…`). The solution file `MCMP113_Week12_Code.sln` lists all projects; in the C# Dev Kit *Solution Explorer* right-click a project → *Debug → Start New Instance*.

### Notes
* Programs are written with **top-level statements** (no `class Program`/`Main` needed).
* The course project template turns off nullable warnings and uses **invariant culture**, so decimal numbers are typed with a **point** (`72.5`) even on Turkish-language Windows.
* Typing input: when a program waits, type a value and press **Enter**. Stop a running program with **Ctrl + C**.
* `bin/` and `obj/` folders are created automatically on the first build; you may delete them at any time.

---


Each folder is a separate .NET 10 console project (course template: Nullable disabled,
InvariantGlobalization on). Open the folder in VS Code and press Run, or type `dotnet run` inside it.
All programs were built with 0 errors / 0 warnings and run with the sample input below;
the transcripts on the slides and in the notes are real output of these runs.
Methods are `static` local functions at the bottom of `Program.cs`, each with a one-line `//` comment.
Exception: Example 8 (overloading) writes its methods in `partial class Program`, because local functions cannot be overloaded (CS0128).

| Folder | What it shows | Sample input |
|---|---|---|
| `12_01_WhyMethods` | DRY: a receipt drawn with `PrintLine(char, int)` and `PrintItem(string, double)` instead of copied loops | none |
| `12_02_FirstMethods` | Anatomy of a method; `void Greet` vs value-returning `Square`, `Cube` (calls `Square`), `CircleArea`; calls as statements and expressions | `7`, `2.5` |
| `12_03_CallStack` | `Hypotenuse` calls `Square` twice; each method prints when it starts/returns, indentation = call depth | none |
| `12_04_PassByValue` | Value parameters: `AddBonus(score)` changes only its copy; `score = WithBonus(score)` returns the result | none |
| `12_05_ArrayParameters` | Arrays pass a copy of the reference: `AddToAll` changes the caller's elements, `ReplaceArray` (`a = new ...`) does not affect the caller | none |
| `12_06_RefOut` | `SwapCopies` vs `Swap(ref, ref)`; `Divide(..., out q, out r)`; `int.TryParse` as a known `out` method | `19`; `nineteen` |
| `12_07_DefaultNamed` | Optional parameters (`PrintLine(char symbol = '-', int count = 20)`, `Price(net, vatRate = 0.20m, discount = 0m)`) and named arguments | none |
| `12_08_Overloading` | Four `Max` overloads (int,int / double,double / int,int,int / int[]) in `partial class Program`; overload resolution of `Max(3, 2.5)` | none |
| `12_09_MathToolkit` | Refactoring: `IsLeapYear`, `IsPrime`, `Factorial` (long), `Gcd` (Euclid), `Lcm` built on `Gcd` | none |
| `12_10_ReadValidated` | `ReadInt(prompt)` with a TryParse loop, `ReadIntInRange` built on it, `Average(int[])` | `abc 12 3 105 70 85 -5 40` (one per line) |
| `12_11_ArrayToolkit` | `Report` calls `PrintArray`, `Average`, `Max`, `Min`, `CountAtLeast` for two `double[]` groups | none |
| `12_12_MenuCalculator` | do-while menu built from `ShowMenu`, `ReadIntInRange`, `ReadDouble`, `Calculate` (switch expression); division-by-zero check | `1 12.5 7.5 4 10 0 7 5 2 10 0` (one per line) |
| `12_13_DigitTools` | `CountDigits`, `DigitSum`, `Reverse`: a program for practising breakpoints, Step Into (F11), Step Over (F10), Step Out (Shift+F11) | `2026` |
