// MCMP113 · Week 12 · Example 2 — Anatomy of a method: define once, call many times
// Value-returning methods (Square, Cube, CircleArea) and a void method (Greet).

Greet("Elif");
Greet("Mehmet");

Console.Write("Enter an integer: ");
int n = int.Parse(Console.ReadLine());
Console.WriteLine($"Square({n}) = {Square(n)}");
Console.WriteLine($"Cube({n}) = {Cube(n)}");

int sum = Square(3) + Square(4);  // calls in an expression
Console.WriteLine($"Square(3) + Square(4) = {sum}");

Console.Write("Radius in cm: ");
double r = double.Parse(Console.ReadLine());
double area = CircleArea(r);  // store the result
Console.WriteLine($"Area = {area:F2} cm^2");

// prints a greeting; void = it returns nothing
static void Greet(string name)
{
    Console.WriteLine($"Hello, {name}! Welcome to MCMP113.");
}

// returns x * x
static int Square(int x)
{
    return x * x;
}

// returns x * x * x by calling Square
static int Cube(int x)
{
    return Square(x) * x;
}

// returns the area of a circle with the given radius
static double CircleArea(double radius)
{
    return Math.PI * radius * radius;
}
