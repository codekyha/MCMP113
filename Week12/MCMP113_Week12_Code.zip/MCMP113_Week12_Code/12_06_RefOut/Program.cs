// MCMP113 · Week 12 · Example 6 — ref and out parameters
// ref: the parameter is another name for the caller's variable; out: the method must give it a value.

int a = 5;
int b = 9;
Console.WriteLine($"Start:            a = {a}, b = {b}");
SwapCopies(a, b);
Console.WriteLine($"After SwapCopies: a = {a}, b = {b}");
Swap(ref a, ref b);
Console.WriteLine($"After Swap(ref):  a = {a}, b = {b}");

Divide(17, 5, out int q, out int r);
Console.WriteLine($"17 / 5: quotient {q}, remainder {r}");

// int.TryParse is an out method you already know (Week 5)
Console.Write("Your age: ");
if (int.TryParse(Console.ReadLine(), out int age))
{
    Console.WriteLine($"Next year you will be {age + 1}.");
}
else
{
    Console.WriteLine("That is not a whole number.");
}

// swaps its own copies only: the caller's variables do not change
static void SwapCopies(int x, int y)
{
    int temp = x;
    x = y;
    y = temp;
}

// swaps the caller's variables: x and y are aliases (ref)
static void Swap(ref int x, ref int y)
{
    int temp = x;
    x = y;
    y = temp;
}

// gives back two results through out parameters
static void Divide(int dividend, int divisor, out int quotient, out int remainder)
{
    quotient = dividend / divisor;
    remainder = dividend % divisor;
}
