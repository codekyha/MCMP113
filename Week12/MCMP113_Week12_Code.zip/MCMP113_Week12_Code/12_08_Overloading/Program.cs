// MCMP113 · Week 12 · Example 8 — Method overloading: one name, different parameter lists
// Local functions cannot be overloaded (error CS0128), so these methods are written in the Program class.

int[] scores = { 72, 93, 64, 85 };
Console.WriteLine($"Max(3, 8)        = {Max(3, 8)}");
Console.WriteLine($"Max(2.5, 1.75)   = {Max(2.5, 1.75)}");
Console.WriteLine($"Max(4, 11, 7)    = {Max(4, 11, 7)}");
Console.WriteLine($"Max(scores)      = {Max(scores)}");
Console.WriteLine($"Max(3, 2.5)      = {Max(3, 2.5)}");   // 3 becomes 3.0

// the compiler puts the top-level statements into a class called Program;
// "partial" lets us add our own methods to that class
partial class Program
{
    // returns the larger of two ints
    static int Max(int a, int b)
    {
        return a > b ? a : b;
    }

    // returns the larger of two doubles
    static double Max(double a, double b)
    {
        return a > b ? a : b;
    }

    // returns the largest of three ints (reuses Max)
    static int Max(int a, int b, int c)
    {
        return Max(Max(a, b), c);
    }

    // returns the largest element of an array (champion pattern, Week 10)
    static int Max(int[] values)
    {
        int best = values[0];
        for (int i = 1; i < values.Length; i++)
        {
            if (values[i] > best)
            {
                best = values[i];
            }
        }
        return best;
    }
}
