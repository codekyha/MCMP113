// MCMP113 · Week 12 · Example 9 — Refactoring: earlier algorithms as reusable methods
// Leap year (Week 5), prime test (Week 6), factorial (Week 6), Euclid's GCD (Weeks 1 and 7).

int[] years = { 1900, 2000, 2024, 2026 };
foreach (int year in years)
{
    string answer = IsLeapYear(year) ? "leap year" : "not a leap year";
    Console.WriteLine($"{year}: {answer}");
}

Console.Write("Primes up to 30:");
for (int k = 1; k <= 30; k++)
{
    if (IsPrime(k))
    {
        Console.Write($" {k}");
    }
}
Console.WriteLine();

Console.WriteLine($"5! = {Factorial(5)}, 10! = {Factorial(10)}, 20! = {Factorial(20)}");
Console.WriteLine($"Gcd(84, 36) = {Gcd(84, 36)}, Lcm(84, 36) = {Lcm(84, 36)}");
Console.WriteLine($"Gcd(17, 5) = {Gcd(17, 5)}, Lcm(4, 6) = {Lcm(4, 6)}");

// true if year is a leap year in the Gregorian calendar
static bool IsLeapYear(int year)
{
    return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
}

// true if n is prime (trial division up to the square root of n)
static bool IsPrime(int n)
{
    if (n < 2)
    {
        return false;
    }
    for (int d = 2; d * d <= n; d++)
    {
        if (n % d == 0)
        {
            return false;
        }
    }
    return true;
}

// returns n! = 1 * 2 * ... * n as a long (correct up to 20!)
static long Factorial(int n)
{
    long product = 1;
    for (int i = 2; i <= n; i++)
    {
        product *= i;
    }
    return product;
}

// greatest common divisor with Euclid's algorithm
static int Gcd(int a, int b)
{
    while (b != 0)
    {
        int r = a % b;
        a = b;
        b = r;
    }
    return a;
}

// least common multiple, built on Gcd
static int Lcm(int a, int b)
{
    return a / Gcd(a, b) * b;
}
