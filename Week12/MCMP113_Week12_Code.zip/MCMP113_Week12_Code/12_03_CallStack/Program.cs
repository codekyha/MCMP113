// MCMP113 · Week 12 · Example 3 — What happens during a call: the call stack
// Each method prints when it starts and when it returns; the indentation shows the call depth.

double a = 3;
double b = 4;
Console.WriteLine($"main: a = {a}, b = {b}");
double c = Hypotenuse(a, b);
Console.WriteLine($"main: c = {c}");

// returns the hypotenuse of a right triangle with legs x and y
static double Hypotenuse(double x, double y)
{
    Console.WriteLine($"  Hypotenuse starts: x = {x}, y = {y}");
    double sum = Square(x) + Square(y);
    double result = Math.Sqrt(sum);
    Console.WriteLine($"  Hypotenuse returns {result}");
    return result;
}

// returns v * v (and reports the call)
static double Square(double v)
{
    Console.WriteLine($"    Square starts: v = {v}");
    double result = v * v;
    Console.WriteLine($"    Square returns {result}");
    return result;
}
