// MCMP113 · Week 12 · Example 13 — Digit tools: a program to explore with the debugger
// Set a breakpoint on the first call, then use Step Into (F11), Step Over (F10) and Step Out (Shift+F11).

Console.Write("Enter a positive integer: ");
int number = int.Parse(Console.ReadLine());

int count = CountDigits(number);
int sum = DigitSum(number);
int reversed = Reverse(number);
Console.WriteLine($"Digits: {count}, digit sum: {sum}, reversed: {reversed}");
Console.WriteLine($"Average digit: {(double)sum / count:F2}");

// returns how many digits n has (n >= 0)
static int CountDigits(int n)
{
    int count = 1;
    while (n >= 10)
    {
        n /= 10;
        count++;
    }
    return count;
}

// returns the sum of the digits of n
static int DigitSum(int n)
{
    int sum = 0;
    while (n > 0)
    {
        sum += n % 10;
        n /= 10;
    }
    return sum;
}

// returns the digits of n in reverse order (1234 -> 4321)
static int Reverse(int n)
{
    int result = 0;
    while (n > 0)
    {
        result = result * 10 + n % 10;
        n /= 10;
    }
    return result;
}
