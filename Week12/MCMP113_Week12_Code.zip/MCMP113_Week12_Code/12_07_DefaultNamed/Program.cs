// MCMP113 · Week 12 · Example 7 — Optional (default) parameters and named arguments
// Parameters with a default value may be left out; named arguments can skip or reorder them.

PrintLine();                       // both defaults: 20 times '-'
PrintLine('*');                    // count uses its default
PrintLine('=', 12);
PrintLine(count: 5);               // named: skip symbol
PrintLine(count: 8, symbol: '#');  // named: any order

// all net prices are 100 TL; the VAT rates are examples
Console.WriteLine($"Laptop: {Price(100m):F2} TL");                  // default VAT 20 %
Console.WriteLine($"Bread:  {Price(100m, 0.01m):F2} TL");           // VAT 1 %
Console.WriteLine($"Coat:   {Price(100m, discount: 0.25m):F2} TL"); // 25 % off
Console.WriteLine($"Shoes:  {Price(net: 100m, vatRate: 0.10m, discount: 0.10m):F2} TL");

// prints symbol count times; both parameters are optional
static void PrintLine(char symbol = '-', int count = 20)
{
    for (int i = 0; i < count; i++)
    {
        Console.Write(symbol);
    }
    Console.WriteLine();
}

// returns the price after the discount, with VAT added
static decimal Price(decimal net, decimal vatRate = 0.20m, decimal discount = 0m)
{
    decimal discounted = net * (1 - discount);
    return discounted * (1 + vatRate);
}
