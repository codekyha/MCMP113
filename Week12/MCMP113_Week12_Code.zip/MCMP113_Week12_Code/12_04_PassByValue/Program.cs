// MCMP113 · Week 12 · Example 4 — Passing by value: the method works on a COPY
// Changing a parameter inside a method does not change the caller's variable.

int score = 70;
Console.WriteLine($"Before:            score = {score}");

AddBonus(score);           // 70 is copied into points
Console.WriteLine($"After AddBonus:    score = {score}");

score = WithBonus(score);  // store the returned value
Console.WriteLine($"After WithBonus:   score = {score}");

// adds 10 to its own copy only; the caller's variable does not change
static void AddBonus(int points)
{
    points = points + 10;
    Console.WriteLine($"  inside AddBonus: points = {points}");
}

// returns the value plus 10; the caller decides what to do with it
static int WithBonus(int points)
{
    return points + 10;
}
