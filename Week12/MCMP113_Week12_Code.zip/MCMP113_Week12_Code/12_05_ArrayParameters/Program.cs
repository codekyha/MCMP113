// MCMP113 · Week 12 · Example 5 — Arrays as parameters: the REFERENCE is copied
// The method can change the caller's elements, but giving the parameter a new array does not affect the caller.

int[] grades = { 55, 70, 42, 88 };
PrintArray("start", grades);

AddToAll(grades, 5);                   // changes the elements of grades
PrintArray("after AddToAll", grades);

ReplaceArray(grades);                  // tries to replace the whole array
PrintArray("after ReplaceArray", grades);

// prints a label and the elements of the array
static void PrintArray(string label, int[] a)
{
    Console.WriteLine($"{label,-22}: {string.Join(" ", a)}");
}

// adds bonus to every element; the caller sees the change (same array)
static void AddToAll(int[] a, int bonus)
{
    for (int i = 0; i < a.Length; i++)
    {
        a[i] += bonus;
    }
}

// points the parameter to a NEW array; the caller still has the old one
static void ReplaceArray(int[] a)
{
    a = new int[] { 0, 0, 0, 0 };
    PrintArray("  inside ReplaceArray", a);
}
