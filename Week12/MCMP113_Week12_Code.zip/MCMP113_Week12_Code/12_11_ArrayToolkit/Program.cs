// MCMP113 · Week 12 · Example 11 — An array toolkit: Week 9/10 loops as methods
// The same five methods analyse two different groups; each loop is written only once.

double[] groupA = { 72.5, 45, 88, 60, 95.5, 38 };
double[] groupB = { 80, 65, 90 };

Report("Group A", groupA);
Report("Group B", groupB);

// prints a short statistics report for one group (calls the other methods)
static void Report(string title, double[] grades)
{
    Console.WriteLine($"--- {title} ---");
    PrintArray(grades);
    Console.WriteLine($"Average: {Average(grades):F2}");
    double max = Max(grades);
    double min = Min(grades);
    Console.WriteLine($"Max: {max}, Min: {min}, range: {max - min}");
    int passed = CountAtLeast(grades, 50);
    Console.WriteLine($"Passed (>= 50): {passed} of {grades.Length}");
}

// prints the elements on one line, separated by spaces
static void PrintArray(double[] a)
{
    Console.WriteLine("Grades: " + string.Join(" ", a));
}

// returns the arithmetic mean of the elements
static double Average(double[] a)
{
    double sum = 0;
    foreach (double x in a)
    {
        sum += x;
    }
    return sum / a.Length;
}

// returns the largest element (champion pattern)
static double Max(double[] a)
{
    double best = a[0];
    for (int i = 1; i < a.Length; i++)
    {
        if (a[i] > best)
        {
            best = a[i];
        }
    }
    return best;
}

// returns the smallest element
static double Min(double[] a)
{
    double best = a[0];
    for (int i = 1; i < a.Length; i++)
    {
        if (a[i] < best)
        {
            best = a[i];
        }
    }
    return best;
}

// returns how many elements are greater than or equal to limit
static int CountAtLeast(double[] a, double limit)
{
    int count = 0;
    foreach (double x in a)
    {
        if (x >= limit)
        {
            count++;
        }
    }
    return count;
}
