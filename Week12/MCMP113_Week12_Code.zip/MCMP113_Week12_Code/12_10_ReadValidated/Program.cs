// MCMP113 · Week 12 · Example 10 — Input methods: ReadInt and ReadIntInRange
// The TryParse loop is written once and reused for every input; Average works for any int array.

int n = ReadIntInRange("How many students (1-10)? ", 1, 10);
int[] grades = new int[n];
for (int i = 0; i < n; i++)
{
    grades[i] = ReadIntInRange($"Grade {i + 1} (0-100): ", 0, 100);
}
Console.WriteLine($"Grades: {string.Join(", ", grades)}");
Console.WriteLine($"Average: {Average(grades):F2}");

// asks until the user types a whole number, then returns it
static int ReadInt(string prompt)
{
    Console.Write(prompt);
    int value;
    while (!int.TryParse(Console.ReadLine(), out value))
    {
        Console.Write("  Whole number, please: ");
    }
    return value;
}

// asks until the number is between min and max (both included)
static int ReadIntInRange(string prompt, int min, int max)
{
    int value = ReadInt(prompt);
    while (value < min || value > max)
    {
        Console.WriteLine($"  Must be between {min} and {max}.");
        value = ReadInt(prompt);
    }
    return value;
}

// returns the average of the elements of an int array
static double Average(int[] values)
{
    int sum = 0;
    for (int i = 0; i < values.Length; i++)
    {
        sum += values[i];
    }
    return (double)sum / values.Length;
}
