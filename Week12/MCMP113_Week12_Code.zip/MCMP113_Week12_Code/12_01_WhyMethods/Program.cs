// MCMP113 · Week 12 · Example 1 — Why methods? Write the code once, call it many times
// The loop that draws a line is written ONCE (PrintLine) and called with different arguments.

PrintLine('=', 30);
Console.WriteLine("          OKAN CAFE");
PrintLine('=', 30);
PrintItem("Tea x2", 60);
PrintItem("Simit x1", 25);
PrintItem("Toast x1", 110);
PrintLine('-', 30);
PrintItem("TOTAL", 60 + 25 + 110);
PrintLine('=', 30);
PrintLine('*', 12);

// prints symbol count times, then a new line
static void PrintLine(char symbol, int count)
{
    for (int i = 0; i < count; i++)
    {
        Console.Write(symbol);
    }
    Console.WriteLine();
}

// prints one receipt line (30 characters wide)
static void PrintItem(string name, double amount)
{
    Console.WriteLine($"{name,-18}{amount,9:F2} TL");
}
