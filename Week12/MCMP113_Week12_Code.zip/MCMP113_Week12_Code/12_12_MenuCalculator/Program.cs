// MCMP113 · Week 12 · Example 12 — A menu calculator built from small methods
// The main loop only organises the work; reading, checking and calculating happen in methods.

int choice;
do
{
    ShowMenu();
    choice = ReadIntInRange("Choice: ", 0, 5);
    if (choice != 0)
    {
        double x = ReadDouble("First number:  ");
        double y = ReadDouble("Second number: ");
        if (choice == 4 && y == 0)
        {
            Console.WriteLine("Error: division by zero.");
        }
        else
        {
            double result = Calculate(choice, x, y);
            Console.WriteLine($"Result: {result:F2}");
        }
    }
} while (choice != 0);
Console.WriteLine("Goodbye!");

// prints the menu
static void ShowMenu()
{
    Console.WriteLine("1) +   2) -   3) *   4) /   5) power   0) exit");
}

// asks until the user types a number (double), then returns it
static double ReadDouble(string prompt)
{
    Console.Write(prompt);
    double value;
    while (!double.TryParse(Console.ReadLine(), out value))
    {
        Console.Write("  Not a number, try again: ");
    }
    return value;
}

// asks until the user types a whole number between min and max
static int ReadIntInRange(string prompt, int min, int max)
{
    Console.Write(prompt);
    int value;
    while (!int.TryParse(Console.ReadLine(), out value) || value < min || value > max)
    {
        Console.Write($"  Please type {min}-{max}: ");
    }
    return value;
}

// returns the result of the chosen operation (switch expression, Week 5)
static double Calculate(int op, double x, double y)
{
    return op switch
    {
        1 => x + y,
        2 => x - y,
        3 => x * y,
        4 => x / y,
        _ => Math.Pow(x, y),
    };
}
