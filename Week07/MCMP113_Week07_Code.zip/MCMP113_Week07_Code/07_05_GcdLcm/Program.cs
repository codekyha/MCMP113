// MCMP113 · Week 7 · Example 5 — Euclid's GCD and the LCM
// Week 1's algorithm in C#: (x, y) <- (y, x mod y) while y is not 0.

Console.Write("First positive integer a : ");
int a = int.Parse(Console.ReadLine());
Console.Write("Second positive integer b: ");
int b = int.Parse(Console.ReadLine());

if (a <= 0 || b <= 0)
{
    Console.WriteLine("Both numbers must be positive.");
}
else
{
    int x = a;          // copies: a and b are needed for the LCM
    int y = b;
    Console.WriteLine($"{"x",6} {"y",6} {"x % y",7}");
    while (y != 0)
    {
        int r = x % y;
        Console.WriteLine($"{x,6} {y,6} {r,7}");
        x = y;
        y = r;
    }
    int gcd = x;
    long lcm = (long)a / gcd * b;   // divide first, then multiply
    Console.WriteLine($"GCD({a}, {b}) = {gcd}");
    Console.WriteLine($"LCM({a}, {b}) = {lcm}");
}
