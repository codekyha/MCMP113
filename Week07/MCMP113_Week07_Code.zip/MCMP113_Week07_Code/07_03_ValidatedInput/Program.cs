// MCMP113 · Week 7 · Example 3 — Input validation loops
// Keeps asking until the input is a number AND inside the allowed range.

// (a) do-while: ask first, check afterwards
int score;
bool ok;
do
{
    Console.Write("Exam score (0-100): ");
    ok = int.TryParse(Console.ReadLine(), out score);
    if (!ok || score < 0 || score > 100)
    {
        Console.WriteLine("  Invalid: whole number 0-100 only.");
    }
}
while (!ok || score < 0 || score > 100);

// (b) while with a priming read: read once, repeat while invalid
Console.Write("Height in metres (0.5-2.5): ");
bool valid = double.TryParse(Console.ReadLine(), out double height);
while (!valid || height < 0.5 || height > 2.5)
{
    Console.WriteLine("  Invalid: example 1.75");
    Console.Write("Height in metres (0.5-2.5): ");
    valid = double.TryParse(Console.ReadLine(), out height);
}

Console.WriteLine($"Accepted: {score} points, {height:F2} m");
