// MCMP113 · Week 7 · Example 6 — Digit tools
// % 10 gives the last digit, / 10 drops it: count, sum, reverse, palindrome.

int n;
bool ok;
do
{
    Console.Write("Enter a non-negative integer: ");
    ok = int.TryParse(Console.ReadLine(), out n);
}
while (!ok || n < 0);

int rest = n;           // working copy; n is kept for the test
int digitCount = 0;
int digitSum = 0;
long reversed = 0;      // long: the reverse may not fit in an int

// do-while, so that n = 0 is counted as a 1-digit number
do
{
    int digit = rest % 10;              // last digit
    digitCount++;
    digitSum += digit;
    reversed = reversed * 10 + digit;   // append on the right
    rest /= 10;                         // drop the last digit
}
while (rest > 0);

Console.WriteLine($"Digits : {digitCount}");
Console.WriteLine($"Sum    : {digitSum}");
Console.WriteLine($"Reverse: {reversed}");
if (reversed == n)
{
    Console.WriteLine($"{n} is a palindrome.");
}
else
{
    Console.WriteLine($"{n} is not a palindrome.");
}
