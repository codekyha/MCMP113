// MCMP113 · Week 7 · Example 1 — Countdown three ways
// The same countdown with while, do-while and for; try n = 0.

Console.Write("Start the countdown from: ");
int n = int.Parse(Console.ReadLine());

// 1) while: condition tested BEFORE each pass (pre-test)
Console.Write("while    : ");
int i = n;
while (i > 0)
{
    Console.Write($"{i} ");
    i--;
}
Console.WriteLine("Go!");

// 2) do-while: condition tested AFTER each pass (post-test)
Console.Write("do-while : ");
int j = n;
do
{
    Console.Write($"{j} ");
    j--;
}
while (j > 0);
Console.WriteLine("Go!");

// 3) for: the same counter-controlled loop, one header line
Console.Write("for      : ");
for (int k = n; k > 0; k--)
{
    Console.Write($"{k} ");
}
Console.WriteLine("Go!");
