// MCMP113 · Week 7 · Example 4 — Menu-driven bank account
// A do-while menu loop with a switch: the menu is shown at least once.

decimal balance = 0m;
int choice;
Console.WriteLine("=== OKAN MINI BANK ===");

do
{
    Console.WriteLine("1) Balance 2) Deposit 3) Withdraw 0) Exit");
    Console.Write("Choice: ");
    if (!int.TryParse(Console.ReadLine(), out choice))
    {
        choice = -1;        // not a number -> default case
    }

    switch (choice)
    {
        case 1:
            Console.WriteLine($"Balance: {balance:F2} TL");
            break;
        case 2:
            Console.Write("Amount to deposit: ");
            decimal deposit = decimal.Parse(Console.ReadLine());
            if (deposit > 0)
            {
                balance += deposit;
                Console.WriteLine($"New balance: {balance:F2} TL");
            }
            else
            {
                Console.WriteLine("The amount must be positive.");
            }
            break;
        case 3:
            Console.Write("Amount to withdraw: ");
            decimal amount = decimal.Parse(Console.ReadLine());
            if (amount <= 0)
            {
                Console.WriteLine("The amount must be positive.");
            }
            else if (amount > balance)
            {
                Console.WriteLine("Insufficient funds.");
            }
            else
            {
                balance -= amount;
                Console.WriteLine($"New balance: {balance:F2} TL");
            }
            break;
        case 0:
            Console.WriteLine("Goodbye!");
            break;
        default:
            Console.WriteLine("Unknown option, try again.");
            break;
    }
}
while (choice != 0);
