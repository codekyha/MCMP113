// MCMP113 · Week 7 · Example 9 — Guess the number
// Random secret, attempts counter, while (true) with break and continue.

int secret = Random.Shared.Next(1, 101);   // 1..100, 101 excluded
// Testing tip: a fixed seed gives the same secret in every run:
// int secret = new Random(42).Next(1, 101);
int attempts = 0;

Console.WriteLine("I am thinking of a number between 1 and 100.");
while (true)
{
    Console.Write("Your guess: ");
    if (!int.TryParse(Console.ReadLine(), out int guess))
    {
        Console.WriteLine("Please type a whole number.");
        continue;           // back to the top; attempt not counted
    }
    attempts++;
    if (guess < secret)
    {
        Console.WriteLine("Higher!");
    }
    else if (guess > secret)
    {
        Console.WriteLine("Lower!");
    }
    else
    {
        Console.WriteLine($"Correct! {attempts} attempts.");
        break;              // leave the loop immediately
    }
}
