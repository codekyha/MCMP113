// MCMP113 · Week 7 · Example 8 — Collatz sequence
// even -> n / 2, odd -> 3n + 1, repeat until 1 (steps unknown in advance).

int start;
bool ok;
do
{
    Console.Write("Starting value (>= 1): ");
    ok = int.TryParse(Console.ReadLine(), out start);
}
while (!ok || start < 1);

long n = start;     // long: the values can grow a lot
int steps = 0;
long peak = n;
Console.Write(n);
while (n != 1)
{
    if (n % 2 == 0)
    {
        n = n / 2;
    }
    else
    {
        n = 3 * n + 1;
    }
    steps++;
    if (n > peak)
    {
        peak = n;
    }
    // 10 numbers per line keeps long sequences readable
    Console.Write(steps % 10 == 0 ? $"\n{n}" : $" {n}");
}
Console.WriteLine();
Console.WriteLine($"{steps} steps, highest value {peak}");
