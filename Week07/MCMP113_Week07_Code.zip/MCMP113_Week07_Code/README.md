# MCMP113 · Introduction to Basic Algorithms and Programming
## Week 7 — example code pack

Asst. Prof. Hasan Oğuz, PhD · Istanbul Okan University · 2026–2027 Fall

Every folder in this pack is a **separate, complete C# console project** (`.csproj` + `Program.cs`) for .NET 10.
All programs were built with 0 errors / 0 warnings and run with the sample inputs listed below.

### Getting started
1. Install the **.NET 10 SDK** (https://dotnet.microsoft.com/en-us/download/dotnet/10.0) and **Visual Studio Code** with the **C# Dev Kit** extension.
2. Unzip this pack, e.g. to `Documents\MCMP113\Week07`.
3. Run one example from a terminal:
   ```
   cd 07_01_CountdownThreeWays
   dotnet run
   ```
4. Or open the whole pack in VS Code (`File → Open Folder…`). The solution file `MCMP113_Week07_Code.sln` lists all projects; in the C# Dev Kit *Solution Explorer* right-click a project → *Debug → Start New Instance*.

### Notes
* Programs are written with **top-level statements** (no `class Program`/`Main` needed).
* The course project template turns off nullable warnings and uses **invariant culture**, so decimal numbers are typed with a **point** (`72.5`) even on Turkish-language Windows.
* Typing input: when a program waits, type a value and press **Enter**. Stop a running program with **Ctrl + C**.
* `bin/` and `obj/` folders are created automatically on the first build; you may delete them at any time.

---


Each folder is a separate .NET 10 console project (course template: Nullable disabled,
InvariantGlobalization on). Open the folder in VS Code and press Run, or type `dotnet run` inside it.
All programs were built with 0 errors / 0 warnings and run with the sample input below;
the transcripts on the slides and in the notes are real output of these runs.

| Folder | What it shows | Sample input |
|---|---|---|
| `07_01_CountdownThreeWays` | The same countdown with `while`, `do-while` and `for`; only `do-while` runs for n = 0 | `3`, then `0` |
| `07_02_SentinelAverage` | Sentinel-controlled loop (−1), priming read, count / sum / average / highest, empty-input check | `72 85 90 64 -1`; `-1` |
| `07_03_ValidatedInput` | Input validation: `do-while` + `int.TryParse` + range, and `while` with a priming read + `double.TryParse` | `abc 120 85 1,75 0 1.75` |
| `07_04_BankMenu` | Menu-driven program: `do-while` around a `switch` (balance, deposit, withdraw, exit; invalid choice → -1) | `2 500 3 750 3 200 1 x 0` |
| `07_05_GcdLcm` | Euclid's GCD (Week 1) with a printed trace table, LCM = a / gcd · b in `long` | `48 18`; `18 48`; `1071 462`; `0 5` |
| `07_06_DigitTools` | `% 10` and `/ 10`: digit count, digit sum, reverse (`long`), palindrome; `do-while` so 0 has 1 digit | `4071`; `-5 12321`; `0`; `2147483647`; `1200` |
| `07_07_DecimalToBinary` | Repeated division by 2, bits prepended to a string; checked with `Convert.ToString(n, 2)` | `13`; `0`; `2026` |
| `07_08_Collatz` | Collatz sequence (unknown number of passes), steps and peak value, 10 numbers per line | `6`; `0 27` |
| `07_09_GuessNumber` | Guess the number: `Random.Shared.Next(1, 101)`, `while (true)` + `break`, `continue`, attempts counter | any guesses (for a reproducible test swap in the commented `new Random(42)` line → secret 67: `50 75 abc 62 68 65 66 67`) |
| `07_10_ComputerGuesses` | The computer guesses by halving (binary search, Week 1 strategy); never more than 7 guesses | `67`; `150 100` |
| `07_11_PasswordAttempts` | Loop with two exits (flag + counter), `&&` in the condition, which exit happened? | `okan2025 okan2026`; `1234 password Okan2026` |
| `07_12_DoublingTime` | Compound interest until the deposit doubles; `do-while` validation of the rate (0 % would loop forever); rule of 72 | `10000 0 5`; `10000 12` |

Inputs are typed one per line (spaces above separate the lines; `;` separates different runs).
To stop a program that is stuck in an infinite loop, press **Ctrl+C** in the terminal.
