// MCMP113 · Week 7 · Example 12 — How many years until the money doubles?
// The number of passes is not known in advance -> a while loop.

Console.Write("Deposit (TL): ");
decimal principal = decimal.Parse(Console.ReadLine());
decimal rate;
do
{
    Console.Write("Annual interest rate in % (> 0): ");
    rate = decimal.Parse(Console.ReadLine());
}
while (rate <= 0);      // 0 % -> the loop below never ends!

decimal balance = principal;
int years = 0;
Console.WriteLine($"{"Year",4} {"Balance (TL)",14}");
while (balance < 2 * principal)
{
    balance += balance * rate / 100;   // one year of interest
    years++;
    Console.WriteLine($"{years,4} {balance,14:F2}");
}
Console.WriteLine($"The deposit doubles after {years} years.");
Console.WriteLine($"Rule of 72: about {72 / rate:F1} years");
