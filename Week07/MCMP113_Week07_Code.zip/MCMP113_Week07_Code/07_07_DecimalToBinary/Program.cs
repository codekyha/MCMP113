// MCMP113 · Week 7 · Example 7 — Decimal to binary
// Repeated division by 2; the remainders, read backwards, are the bits.

int n;
bool ok;
do
{
    Console.Write("Non-negative integer: ");
    ok = int.TryParse(Console.ReadLine(), out n);
}
while (!ok || n < 0);

int rest = n;
string binary = "";
do
{
    int bit = rest % 2;
    Console.WriteLine($"{rest} / 2 = {rest / 2}, remainder {bit}");
    binary = bit + binary;      // new bit goes to the LEFT
    rest /= 2;
}
while (rest > 0);

Console.WriteLine($"{n} in binary = {binary}");
Console.WriteLine($"Built-in check: {Convert.ToString(n, 2)}");
