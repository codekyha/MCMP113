// MCMP113 · Week 7 · Example 11 — Password with 3 attempts
// Two exits from one loop: success (flag) or no attempts left (counter).

const string Password = "okan2026";
const int MaxAttempts = 3;
int attempts = 0;
bool granted = false;

while (attempts < MaxAttempts && !granted)
{
    Console.Write("Password: ");
    string entry = Console.ReadLine();
    attempts++;
    if (entry == Password)
    {
        granted = true;
    }
    else if (attempts < MaxAttempts)
    {
        int left = MaxAttempts - attempts;
        Console.WriteLine($"Wrong! {left} attempt(s) left.");
    }
}

if (granted)
{
    Console.WriteLine($"Access granted (attempt {attempts}).");
}
else
{
    Console.WriteLine("Wrong password. Account locked.");
}
