// MCMP113 · Week 7 · Example 10 — The computer guesses by halving
// Week 1's binary-search strategy: never more than 7 guesses for 1..100.

int secret;
bool ok;
do
{
    Console.Write("Secret number for the computer (1-100): ");
    ok = int.TryParse(Console.ReadLine(), out secret);
}
while (!ok || secret < 1 || secret > 100);

int low = 1;
int high = 100;
int guesses = 0;
int guess;
do
{
    guess = (low + high) / 2;       // middle of the range
    guesses++;
    Console.Write($"#{guesses}: {low}..{high} -> {guess}  ");
    if (guess < secret)
    {
        Console.WriteLine("higher");
        low = guess + 1;
    }
    else if (guess > secret)
    {
        Console.WriteLine("lower");
        high = guess - 1;
    }
    else
    {
        Console.WriteLine("correct!");
    }
}
while (guess != secret);

Console.WriteLine($"Found {secret} in {guesses} guesses.");
