// MCMP113 · Week 7 · Example 2 — Sentinel-controlled average
// Reads scores until the sentinel -1; prints count, average, highest.

const int Sentinel = -1;
int count = 0;
int sum = 0;
int highest = 0;

Console.WriteLine($"Enter scores (0-100), {Sentinel} to finish.");
Console.Write("Score: ");
int score = int.Parse(Console.ReadLine());  // priming read

while (score != Sentinel)
{
    count++;
    sum += score;
    if (count == 1 || score > highest)
    {
        highest = score;        // first score or a new record
    }
    Console.Write("Score: ");
    score = int.Parse(Console.ReadLine());  // the NEXT value
}

if (count == 0)
{
    Console.WriteLine("No scores entered.");
}
else
{
    double average = (double)sum / count;
    Console.WriteLine($"Count: {count}  Sum: {sum}");
    Console.WriteLine($"Average: {average:F2}  Highest: {highest}");
}
