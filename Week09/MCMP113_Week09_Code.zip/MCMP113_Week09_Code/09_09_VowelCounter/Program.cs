// MCMP113 · Week 9 · Example 9 — Vowel counter
// A string is like a read-only char array: text[i], text.Length. Vowels in a char[].

char[] vowels = { 'a', 'e', 'i', 'o', 'u' };
int[] vowelCounts = new int[vowels.Length];     // parallel to vowels[]

Console.Write("Text: ");
string text = Console.ReadLine();

int letters = 0;
for (int i = 0; i < text.Length; i++)
{
    char c = char.ToLower(text[i]);
    if (char.IsLetter(c))
    {
        letters++;
    }
    for (int v = 0; v < vowels.Length; v++)     // is c one of the vowels?
    {
        if (c == vowels[v])
        {
            vowelCounts[v]++;
        }
    }
}

int totalVowels = 0;
for (int v = 0; v < vowels.Length; v++)
{
    Console.Write($"{vowels[v]}:{vowelCounts[v]}  ");
    totalVowels += vowelCounts[v];
}
Console.WriteLine();
Console.WriteLine($"Letters: {letters}, vowels: {totalVowels}");
Console.WriteLine($"Consonants: {letters - totalVowels}");
if (text.Length > 0)                            // an empty text has no text[0]
{
    char first = text[0];
    char last = text[text.Length - 1];
    Console.WriteLine($"First: '{first}', last: '{last}'");
}
