// MCMP113 · Week 9 · Example 8 — Student report with parallel arrays
// names[i], midterms[i], finals[i] belong to the SAME student i; totals[] is computed.

string[] names = { "Ayşe", "Mehmet", "Elif", "Can", "Zeynep" };
int[] midterms = { 78, 45, 92, 60, 55 };
int[] finals = { 85, 40, 88, 70, 38 };

double[] totals = new double[names.Length];
double classSum = 0;
for (int i = 0; i < names.Length; i++)
{
    totals[i] = 0.4 * midterms[i] + 0.6 * finals[i];   // MCMP113 weights: 40 % + 60 %
    classSum += totals[i];
}
double classAverage = classSum / names.Length;

Console.WriteLine($"{"Name",-8}{"Mid",5}{"Final",7}{"Total",8}  Result");
for (int i = 0; i < names.Length; i++)
{
    string result = totals[i] >= 50 ? "PASS" : "FAIL";   // example threshold
    Console.Write($"{names[i],-8}{midterms[i],5}{finals[i],7}");
    Console.WriteLine($"{totals[i],8:F1}  {result}");
}
Console.WriteLine($"Class average: {classAverage:F2}");
