// MCMP113 · Week 9 · Example 7 — Dice frequency histogram
// A counting array: counts[face - 1]++ replaces six separate counter variables.

Console.Write("How many rolls? ");
int rolls = int.Parse(Console.ReadLine());

// Fixed seed: the same rolls in every run (Random.Shared gives new rolls)
Random rng = new Random(2026);
// counts[0] = number of 1s, ..., counts[5] = number of 6s
int[] counts = new int[6];

for (int r = 0; r < rolls; r++)
{
    int face = rng.Next(1, 7);     // 1..6 (7 is excluded)
    counts[face - 1]++;            // face 1 -> index 0, face 6 -> index 5
}

Console.WriteLine("Face  Count  Share  Histogram (* = 1 %)");
for (int i = 0; i < counts.Length; i++)
{
    double share = 100.0 * counts[i] / rolls;
    int stars = (int)Math.Round(share);   // one * per 1 %
    string bar = "";
    for (int k = 0; k < stars; k++)
    {
        bar += "*";
    }
    Console.WriteLine($"{i + 1,4}  {counts[i],5}  {share,5:F1}%  {bar}");
}
