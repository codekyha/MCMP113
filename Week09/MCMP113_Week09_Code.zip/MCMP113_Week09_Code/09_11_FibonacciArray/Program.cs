// MCMP113 · Week 9 · Example 11 — Fibonacci numbers stored in an array
// Each element comes from the two before it: fib[i] = fib[i - 1] + fib[i - 2].

Console.Write("How many Fibonacci numbers (2-93)? ");
int n = int.Parse(Console.ReadLine());
if (n < 2 || n > 93)
{
    // fib[93] would not fit in a long
    Console.WriteLine("Please choose a number from 2 to 93.");
}
else
{
    long[] fib = new long[n];
    fib[0] = 0;
    fib[1] = 1;
    // start at 2: the indices i - 1 and i - 2 already have values
    for (int i = 2; i < n; i++)
    {
        fib[i] = fib[i - 1] + fib[i - 2];
    }

    Console.WriteLine(string.Join(" ", fib));
    Console.WriteLine($"fib[{n - 1}] = {fib[n - 1]:N0}");
}
