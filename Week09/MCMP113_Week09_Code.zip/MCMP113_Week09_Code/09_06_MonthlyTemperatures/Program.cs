// MCMP113 · Week 9 · Example 6 — Monthly temperatures
// double[] with an initializer list, a parallel string[], neighbours a[i - 1] and a[i].

string[] months = { "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
// Example data: monthly average temperatures in degrees C (similar to Istanbul)
double[] temps = { 6.1, 6.4, 8.2, 12.3, 17.0, 21.6,
                   24.0, 24.2, 20.6, 16.2, 11.8, 8.1 };

double sum = 0;
for (int i = 0; i < temps.Length; i++)
{
    sum += temps[i];
}
double yearAverage = sum / temps.Length;
Console.WriteLine($"Year average: {yearAverage:F2} C");

Console.WriteLine("Month   Temp   Change");
// January has no previous month: the loop starts at index 1
Console.WriteLine($"{months[0],-5}{temps[0],7:F1}{"-",9}");
for (int i = 1; i < temps.Length; i++)
{
    double change = temps[i] - temps[i - 1];
    Console.WriteLine($"{months[i],-5}{temps[i],7:F1}{change,9:F1}");
}

Console.Write("Warmer than average:");
foreach (double t in temps)
{
    if (t > yearAverage)
    {
        Console.Write($" {t:F1}");
    }
}
Console.WriteLine();
