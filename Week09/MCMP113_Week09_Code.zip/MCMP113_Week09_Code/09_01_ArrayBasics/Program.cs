// MCMP113 · Week 9 · Example 1 — Array basics
// new int[5], default values, a[i], Length, initializers, for, foreach, string.Join.

// 1) Declaration: 5 int boxes, all start at the default value 0
int[] scores = new int[5];
Console.WriteLine($"Length: {scores.Length}");
Console.WriteLine($"After new int[5]: {string.Join(", ", scores)}");

// 2) Assignment and access with an index (first index 0, last index Length - 1)
scores[0] = 72;
scores[1] = 85;
scores[4] = 90;
scores[1] = scores[1] + 5;          // read a box, change it, write it back
Console.WriteLine($"After assignments: {string.Join(", ", scores)}");
Console.WriteLine($"First: {scores[0]}, last: {scores[scores.Length - 1]}");

// 3) Default values of other element types
double[] prices = new double[3];
bool[] present = new bool[3];
string[] names = new string[3];
char[] letters = new char[3];
Console.WriteLine($"double: {prices[0]}, bool: {present[0]}");
Console.WriteLine($"string is null: {names[0] == null}, char code: {(int)letters[0]}");

// 4) Initializer lists: size = number of values
int[] primes = { 2, 3, 5, 7, 11 };
string[] days = new[] { "Mon", "Tue", "Wed" };   // type inferred from the values

// 5) Traversal with for (index known) ...
for (int i = 0; i < primes.Length; i++)
{
    Console.WriteLine($"primes[{i}] = {primes[i]}");
}

// ... and with foreach (only the values, read-only)
foreach (string day in days)
{
    Console.Write(day + " ");
}
Console.WriteLine();

// 6) Printing: WriteLine(array) shows the TYPE name, not the values
Console.WriteLine(primes);
Console.WriteLine(string.Join(", ", primes));
for (int i = 0; i < primes.Length; i++)
{
    Console.Write($"{primes[i],4}");      // width 4, right-aligned
}
Console.WriteLine();
