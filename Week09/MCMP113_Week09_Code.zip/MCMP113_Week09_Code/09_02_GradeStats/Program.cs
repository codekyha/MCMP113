// MCMP113 · Week 9 · Example 2 — Grade statistics
// Store N grades, then use them twice: for the average and for the count above it.

Console.Write("How many students? ");
int n = int.Parse(Console.ReadLine());

double[] grades = new double[n];

// Pass 1: read and store every grade
for (int i = 0; i < n; i++)
{
    Console.Write($"Grade {i + 1}: ");
    grades[i] = double.Parse(Console.ReadLine());
}

// Pass 2: the sum and the average
double sum = 0;
for (int i = 0; i < grades.Length; i++)
{
    sum += grades[i];
}
double average = sum / grades.Length;

// Pass 3: count the grades above the average
int aboveCount = 0;
for (int i = 0; i < grades.Length; i++)
{
    if (grades[i] > average)
    {
        aboveCount++;
    }
}

Console.WriteLine($"Grades: {string.Join(" | ", grades)}");
Console.WriteLine($"Average: {average:F2}");
Console.WriteLine($"Above average: {aboveCount} of {n}");
