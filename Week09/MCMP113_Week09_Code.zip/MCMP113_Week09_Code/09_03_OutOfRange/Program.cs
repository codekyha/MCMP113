// MCMP113 · Week 9 · Example 3 — Valid and invalid indices
// Valid indices are 0 .. Length - 1; any other index throws IndexOutOfRangeException.

int[] a = { 10, 20, 30, 40, 50 };
Console.WriteLine($"Valid indices: 0 .. {a.Length - 1}");

Console.Write("Index: ");
int index = int.Parse(Console.ReadLine());

// Safe version: check the index first
if (index >= 0 && index < a.Length)
{
    Console.WriteLine($"Checked:   a[{index}] = {a[index]}");
}
else
{
    Console.WriteLine($"Checked:   {index} is not a valid index");
}

// Unsafe version: no check -> the runtime throws an exception for a bad index
Console.WriteLine($"Unchecked: a[{index}] = {a[index]}");
Console.WriteLine("Done.");
