// MCMP113 · Week 9 · Example 4 — Print in reverse order
// Store first, then print from the last index (Length - 1) down to index 0.

Console.Write("How many numbers? ");
int n = int.Parse(Console.ReadLine());
int[] numbers = new int[n];

for (int i = 0; i < n; i++)
{
    Console.Write($"Number {i + 1}: ");
    numbers[i] = int.Parse(Console.ReadLine());
}

Console.Write("Reversed:");
for (int i = numbers.Length - 1; i >= 0; i--)    // last index is Length - 1
{
    Console.Write($" {numbers[i]}");
}
Console.WriteLine();
