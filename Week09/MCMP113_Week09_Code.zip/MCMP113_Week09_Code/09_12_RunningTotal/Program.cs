// MCMP113 · Week 9 · Example 12 — Weekly sales with a running total
// total[i] = total[i - 1] + sales[i]: every day's total builds on the previous one.

string[] days = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };
decimal[] sales = new decimal[days.Length];
decimal[] total = new decimal[days.Length];

for (int i = 0; i < days.Length; i++)
{
    Console.Write($"Sales on {days[i]} (TL): ");
    sales[i] = decimal.Parse(Console.ReadLine());
}

total[0] = sales[0];                    // the first day has nothing before it
for (int i = 1; i < days.Length; i++)
{
    total[i] = total[i - 1] + sales[i];
}

Console.WriteLine("Day      Sales      Total");
for (int i = 0; i < days.Length; i++)
{
    Console.WriteLine($"{days[i],-4}{sales[i],10:F2}{total[i],11:F2}");
}
Console.WriteLine($"Week total: {total[days.Length - 1]:F2} TL");
