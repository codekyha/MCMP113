// MCMP113 · Week 9 · Example 13 — Predict-the-output checker
// Runs the quiz snippets of the lecture: the answer slides show this real output.

Console.WriteLine("--- Quiz 1: indices ---");
int[] a = { 4, 8, 15, 16, 23 };
Console.WriteLine(a[1] + a[3]);
Console.WriteLine(a[a.Length - 1]);
Console.WriteLine(a[a[0] - 2]);
a[2] = a[0] * 2;
Console.WriteLine(string.Join(",", a));

Console.WriteLine("--- Quiz 2: filling with a loop ---");
int[] b = new int[5];
for (int i = 0; i < b.Length; i++)
{
    b[i] = i * i;
}
Console.WriteLine(b[4] - b[2]);
int s = 0;
for (int i = 0; i < b.Length; i += 2)
{
    s += b[i];
}
Console.WriteLine(s);

Console.WriteLine("--- Quiz 3: two names, one array ---");
int[] x = { 1, 2, 3 };
int[] y = x;
y[0] = 10;
int[] z = (int[])x.Clone();
z[1] = 20;
x[2] = 30;
Console.WriteLine($"{x[0]} {x[1]} {x[2]}");
Console.WriteLine($"{y[0]} {y[1]} {y[2]}");
Console.WriteLine($"{z[0]} {z[1]} {z[2]}");

Console.WriteLine("--- Quiz 4: neighbours and counters ---");
int[] p = { 1, 2, 3, 4, 5 };
for (int i = 1; i < p.Length; i++)
{
    p[i] = p[i - 1] + p[i];
}
Console.WriteLine(string.Join(" ", p));
int[] data = { 2, 0, 2, 3 };
int[] c = new int[4];
foreach (int v in data)
{
    c[v]++;
}
Console.WriteLine(string.Join(" ", c));
