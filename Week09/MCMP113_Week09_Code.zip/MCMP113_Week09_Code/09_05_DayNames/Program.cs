// MCMP113 · Week 9 · Example 5 — Lookup table: day number -> day name
// One array replaces a 7-case switch; the user's 1..7 becomes the index 0..6.

string[] dayNames = { "Monday", "Tuesday", "Wednesday", "Thursday",
                      "Friday", "Saturday", "Sunday" };
int[] lessonHours = { 4, 6, 2, 6, 3, 0, 0 };     // parallel array: same index, same day

Console.Write("Day number (1-7): ");
int day = int.Parse(Console.ReadLine());

if (day < 1 || day > dayNames.Length)
{
    Console.WriteLine("There is no such day.");
}
else
{
    int index = day - 1;                          // 1-based number -> 0-based index
    string name = dayNames[index];
    Console.WriteLine($"{name}: {lessonHours[index]} lesson hours");
}
