# MCMP113 · Introduction to Basic Algorithms and Programming
## Week 9 — example code pack

Asst. Prof. Hasan Oğuz, PhD · Istanbul Okan University · 2026–2027 Fall

Every folder in this pack is a **separate, complete C# console project** (`.csproj` + `Program.cs`) for .NET 10.
All programs were built with 0 errors / 0 warnings and run with the sample inputs listed below.

### Getting started
1. Install the **.NET 10 SDK** (https://dotnet.microsoft.com/en-us/download/dotnet/10.0) and **Visual Studio Code** with the **C# Dev Kit** extension.
2. Unzip this pack, e.g. to `Documents\MCMP113\Week09`.
3. Run one example from a terminal:
   ```
   cd 09_01_ArrayBasics
   dotnet run
   ```
4. Or open the whole pack in VS Code (`File → Open Folder…`). The solution file `MCMP113_Week09_Code.sln` lists all projects; in the C# Dev Kit *Solution Explorer* right-click a project → *Debug → Start New Instance*.

### Notes
* Programs are written with **top-level statements** (no `class Program`/`Main` needed).
* The course project template turns off nullable warnings and uses **invariant culture**, so decimal numbers are typed with a **point** (`72.5`) even on Turkish-language Windows.
* Typing input: when a program waits, type a value and press **Enter**. Stop a running program with **Ctrl + C**.
* `bin/` and `obj/` folders are created automatically on the first build; you may delete them at any time.

---


Each folder is a separate .NET 10 console project (course template: Nullable off, InvariantGlobalization on).
Run with:  `cd <folder>`  then  `dotnet run`.
All programs use top-level statements only (no methods yet — they come in Week 12).

| Folder | What it shows | Sample input |
|---|---|---|
| 09_01_ArrayBasics | `new int[5]`, default values, `a[i]` read/write, `Length`, initializer lists, `for` and `foreach`, `string.Join` | — (no input) |
| 09_02_GradeStats | read N grades into a `double[]`, average, count of grades above the average | 5, then 72, 85.5, 40, 91, 66 |
| 09_03_OutOfRange | valid indices 0..Length−1; checked access vs. `IndexOutOfRangeException` | 3 / 5 / -1 |
| 09_04_ReversePrint | store first, then traverse backwards from `Length - 1` to 0 | 5, then 4, 8, 15, 16, 23 |
| 09_05_DayNames | lookup table: day number 1..7 → index 0..6 (replaces a switch); parallel `int[]` | 3 / 7 / 8 |
| 09_06_MonthlyTemperatures | `double[]` initializer, neighbours `a[i - 1]` and `a[i]`, `foreach` filter | — (no input) |
| 09_07_DiceHistogram | counting array `counts[face - 1]++`, `Random` with a fixed seed, `*` histogram | 60 / 6000 |
| 09_08_StudentReport | parallel arrays (names, midterms, finals) + a computed `totals` array (40 % / 60 %) | — (no input) |
| 09_09_VowelCounter | string indexing `text[i]`, `text.Length`, `char[]` of vowels with a parallel count array | Programming is fun! |
| 09_10_CopyVsReference | `b = a` (same array, two names) vs. `Clone()` and copy loop; `==` on arrays; value type `int` | — (no input) |
| 09_11_FibonacciArray | `long[]`, each element from the two before it; limit 93 so the values fit in `long` | 10 / 93 / 94 |
| 09_12_RunningTotal | `decimal[]` sales, running total `total[i] = total[i - 1] + sales[i]` | 1250, 980.50, 1430, 0, 2100.75, 3200, 1500 |
| 09_13_PredictChecker | runs the four predict-the-output quiz snippets of the lecture (answer slides and notes show this output) | — (no input) |

Notes:
* `09_03_OutOfRange` stops with an unhandled exception for an invalid index — this is intended (the message is discussed in the lecture).
* `09_07_DiceHistogram` uses `new Random(2026)` so that every run prints the same rolls as the slides; replace it with `Random.Shared` for different rolls.
