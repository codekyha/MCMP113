// MCMP113 · Week 9 · Example 10 — Copy or second name?
// Arrays are reference types: b = a gives a second name; Clone() and a loop make copies.

int[] a = { 1, 2, 3 };

Console.WriteLine("1) int[] b = a;  b[0] = 99;");
int[] b = a;                     // NOT a copy: b refers to the same array
b[0] = 99;
Console.WriteLine($"   a = {string.Join(", ", a)}");     // a has changed too!
Console.WriteLine($"   b = {string.Join(", ", b)}");

Console.WriteLine("2) int[] c = (int[])a.Clone();  c[1] = 77;");
int[] c = (int[])a.Clone();      // a new array with the same values
c[1] = 77;
Console.WriteLine($"   a = {string.Join(", ", a)}");
Console.WriteLine($"   c = {string.Join(", ", c)}");

Console.WriteLine("3) copy loop into d;  d[2] = 55;");
int[] d = new int[a.Length];     // a new array, filled element by element
for (int i = 0; i < a.Length; i++)
{
    d[i] = a[i];
}
d[2] = 55;
Console.WriteLine($"   a = {string.Join(", ", a)}");
Console.WriteLine($"   d = {string.Join(", ", d)}");

// == compares references (same array?), not the contents
Console.WriteLine($"a == b: {a == b},  a == c: {a == c}");

// int is a value type: assignment copies the value itself
int x = 1;
int y = x;
y = 99;
Console.WriteLine($"int: x = {x}, y = {y}");
