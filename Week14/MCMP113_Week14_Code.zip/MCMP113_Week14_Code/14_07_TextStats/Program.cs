// MCMP113 · Week 14 · Example 7 — line, word and character counter
// Creates proverbs.txt (UTF-8 with Turkish letters) if needed, then analyses the file the user names.

Console.OutputEncoding = System.Text.Encoding.UTF8;    // shows ğ ü ş ı ö ç correctly on Windows too

string sample = "proverbs.txt";
if (!File.Exists(sample))
{
    string[] text =
    {
        "Damlaya damlaya göl olur.",
        "Ağaç yaş iken eğilir.",
        "",
        "Bugünün işini yarına bırakma.",
        "Practice makes perfect.",
    };
    File.WriteAllLines(sample, text);                    // UTF-8 is the default encoding
    Console.WriteLine($"Created {sample}");
}

Console.Write("File to analyse: ");
string path = Console.ReadLine();
try
{
    string[] lines = File.ReadAllLines(path);
    int words = 0, characters = 0, letters = 0, longest = 0;
    for (int i = 0; i < lines.Length; i++)
    {
        words += CountWords(lines[i]);
        characters += lines[i].Length;                   // line breaks are not counted
        letters += CountLetters(lines[i]);
        if (lines[i].Length > lines[longest].Length)
        {
            longest = i;                                 // index of the longest line so far
        }
    }
    Console.WriteLine($"Lines     : {lines.Length}");
    Console.WriteLine($"Words     : {words}");
    Console.WriteLine($"Characters: {characters}");
    Console.WriteLine($"Letters   : {letters}");
    if (lines.Length > 0)
    {
        Console.WriteLine($"Longest   : line {longest + 1}, \"{lines[longest]}\"");
    }
}
catch (FileNotFoundException)
{
    Console.WriteLine($"Sorry, there is no file called \"{path}\" in this folder.");
}

// Number of words: pieces between spaces, empty pieces ignored
static int CountWords(string line)
{
    return line.Split(' ', StringSplitOptions.RemoveEmptyEntries).Length;
}

// Number of letters; char.IsLetter is true for Turkish letters as well
static int CountLetters(string line)
{
    int count = 0;
    foreach (char c in line)
    {
        if (char.IsLetter(c))
        {
            count++;
        }
    }
    return count;
}
