// MCMP113 · Week 14 · Example 1 — first steps with text files
// WriteAllText, AppendAllText, ReadAllText, Exists, Delete, Path.Combine and where relative paths point.

// 1. A relative path starts in the WORKING DIRECTORY.
//    With `dotnet run` (or Run in VS Code) this is the project folder.
string workDir = Directory.GetCurrentDirectory();
Console.WriteLine($"Working directory: {Path.GetFileName(workDir)}");
string exeDir = Path.GetRelativePath(workDir, AppContext.BaseDirectory);
Console.WriteLine($"Program files in : {exeDir}");

// 2. Create the file (or replace its old content) with one call
string path = "notes.txt";
File.WriteAllText(path, "MCMP113 notes\nWeek 14: files\n");
Console.WriteLine($"Created? {File.Exists(path)}");

// 3. Add text to the END of the file
File.AppendAllText(path, "Data outlives the program.\n");

// 4. Read the whole file back as ONE string
string content = File.ReadAllText(path);
Console.WriteLine($"{path}: {content.Length} characters");
Console.Write(content);
Console.WriteLine("---");

// 5. Path.Combine puts the right separator between folder and file name
Directory.CreateDirectory("backup");              // no error if it already exists
string copyPath = Path.Combine("backup", "notes_copy.txt");
File.WriteAllText(copyPath, content);
Console.WriteLine($"Copy saved as {copyPath}");   // backup\notes_copy.txt on Windows

// 6. WriteAllText again: the old content is REPLACED, not extended
File.WriteAllText(path, "Only this line is left.\n");
Console.Write($"Now: {File.ReadAllText(path)}");

// 7. Delete the file (no error if it does not exist)
File.Delete(path);
Console.WriteLine($"Deleted? {!File.Exists(path)}");
Console.WriteLine($"Copy kept? {File.Exists(copyPath)}");
