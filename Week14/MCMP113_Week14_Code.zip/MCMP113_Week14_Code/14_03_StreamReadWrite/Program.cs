// MCMP113 · Week 14 · Example 3 — StreamWriter and StreamReader with using
// Write a file line by line in a loop; read it back with ReadLine() until it returns null.

Console.Write("Multiplication table for n = ");
int n = int.Parse(Console.ReadLine());
string path = $"table_{n}.txt";

// using: the file is closed automatically at the end of the block
using (StreamWriter writer = new StreamWriter(path))
{
    writer.WriteLine($"Multiplication table for {n}");
    for (int i = 1; i <= 10; i++)
    {
        writer.WriteLine($"{n} x {i,2} = {n * i,3}");
    }
}
Console.WriteLine($"Saved {path}");

// Read line by line: ReadLine() returns null at the end of the file
int lineNo = 0;
using (StreamReader reader = new StreamReader(path))
{
    string line = reader.ReadLine();
    while (line != null)
    {
        lineNo++;
        Console.WriteLine($"{lineNo,2}| {line}");
        line = reader.ReadLine();
    }
}
Console.WriteLine($"{lineNo} lines read");

// new StreamWriter(path, true) opens the file in APPEND mode
using (StreamWriter writer = new StreamWriter(path, true))
{
    writer.WriteLine("-- end of table --");
}
string[] all = File.ReadAllLines(path);
Console.WriteLine($"Now {all.Length} lines, the last one is: {all[all.Length - 1]}");
