// MCMP113 · Week 14 · Example 8 — guess the number with a high-score file
// The best result "name,attempts" is kept in highscore.txt, so it survives between runs.

string path = "highscore.txt";
(string bestName, int bestAttempts) = LoadHighScore(path);
if (bestAttempts > 0)
{
    Console.WriteLine($"Record to beat: {bestAttempts} attempts by {bestName}");
}
else
{
    Console.WriteLine("No record yet. Be the first!");
}

Console.Write("Your name: ");
string name = Console.ReadLine();
int secret = Random.Shared.Next(1, 101);                // 1..100 (Week 7)
int attempts = 0;
int guess = 0;
while (guess != secret)
{
    Console.Write($"Guess {attempts + 1}: ");
    guess = int.Parse(Console.ReadLine());
    attempts++;
    if (guess < secret)
    {
        Console.WriteLine("Too small.");
    }
    else if (guess > secret)
    {
        Console.WriteLine("Too big.");
    }
}
Console.WriteLine($"Correct, {name}! {attempts} attempts.");

if (bestAttempts == 0 || attempts < bestAttempts)
{
    File.WriteAllText(path, $"{name},{attempts}");      // one line: name,attempts
    Console.WriteLine("New record saved!");
}
else
{
    Console.WriteLine($"The record stays with {bestName} ({bestAttempts}).");
}

// Reads "name,attempts" from the file; returns ("", 0) if there is no valid record
static (string name, int attempts) LoadHighScore(string path)
{
    if (!File.Exists(path))
    {
        return ("", 0);
    }
    try
    {
        string[] parts = File.ReadAllText(path).Split(',');
        if (parts.Length != 2)
        {
            return ("", 0);
        }
        return (parts[0], int.Parse(parts[1]));
    }
    catch (FormatException)
    {
        Console.WriteLine("(damaged high-score file ignored)");
        return ("", 0);
    }
}
