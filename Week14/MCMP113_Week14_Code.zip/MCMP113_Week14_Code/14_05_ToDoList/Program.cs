// MCMP113 · Week 14 · Example 5 — a to-do list that is saved between runs
// New tasks are APPENDED to todo.txt; every run starts by loading the list from the file.

string path = "todo.txt";
if (File.Exists(path))
{
    Console.WriteLine($"Welcome back! {LoadTasks(path).Length} task(s) loaded from {path}.");
}
else
{
    Console.WriteLine("No saved list yet: starting a new one.");
}

string choice = "";
while (choice != "0")
{
    Console.Write("1 List  2 Add  3 Done  0 Quit > ");
    choice = Console.ReadLine();
    if (choice == "1")
    {
        PrintTasks(LoadTasks(path));
    }
    else if (choice == "2")
    {
        Console.Write("New task: ");
        string task = Console.ReadLine();
        File.AppendAllText(path, task + Environment.NewLine);   // one new line at the end
        Console.WriteLine("Saved.");
    }
    else if (choice == "3")
    {
        string[] tasks = LoadTasks(path);
        PrintTasks(tasks);
        Console.Write("Number of the finished task: ");
        int number = int.Parse(Console.ReadLine());
        if (number >= 1 && number <= tasks.Length)
        {
            File.WriteAllLines(path, RemoveAt(tasks, number - 1));  // rewrite the whole file
            Console.WriteLine($"Done: {tasks[number - 1]}");
        }
        else
        {
            Console.WriteLine("No such task.");
        }
    }
}
Console.WriteLine("Bye! Your list is saved.");

// Returns all tasks from the file, or an empty array if the file does not exist yet
static string[] LoadTasks(string path)
{
    if (!File.Exists(path))
    {
        return new string[0];
    }
    return File.ReadAllLines(path);
}

// Prints the tasks with numbers 1, 2, 3, ...
static void PrintTasks(string[] tasks)
{
    if (tasks.Length == 0)
    {
        Console.WriteLine("  (nothing to do)");
    }
    for (int i = 0; i < tasks.Length; i++)
    {
        Console.WriteLine($"  {i + 1}. {tasks[i]}");
    }
}

// Returns a copy of the array without the element at position index
static string[] RemoveAt(string[] items, int index)
{
    string[] result = new string[items.Length - 1];
    int k = 0;
    for (int i = 0; i < items.Length; i++)
    {
        if (i != index)
        {
            result[k] = items[i];
            k++;
        }
    }
    return result;
}
