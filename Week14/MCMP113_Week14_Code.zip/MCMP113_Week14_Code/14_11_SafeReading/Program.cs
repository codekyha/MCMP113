// MCMP113 · Week 14 · Example 11 — when files and data go wrong
// try/catch: FileNotFoundException, IOException, FormatException; TryParse as the quiet alternative.

// 1. A file that does not exist
try
{
    string text = File.ReadAllText("no_such_file.txt");
    Console.WriteLine(text);
}
catch (FileNotFoundException)
{
    Console.WriteLine("1) file not found: no_such_file.txt");
}

// 2. A folder that does not exist: DirectoryNotFoundException is a kind of IOException
string oldPath = Path.Combine("old_data", "scores.txt");
try
{
    string text = File.ReadAllText(oldPath);
    Console.WriteLine(text);
}
catch (FileNotFoundException)
{
    Console.WriteLine("2) the file is missing");
}
catch (IOException)                    // general case: AFTER the specific one
{
    Console.WriteLine("2) IOException: no folder old_data");
}

// 3. Bad data inside a file: int.Parse throws FormatException
string path = "scores.txt";
File.WriteAllLines(path, new string[] { "78", "91", "abc", "65", "", "7O", "100" });
string[] lines = File.ReadAllLines(path);
int sum = 0, good = 0;
for (int i = 0; i < lines.Length; i++)
{
    try
    {
        sum += int.Parse(lines[i]);
        good++;
    }
    catch (FormatException)
    {
        Console.WriteLine($"3) line {i + 1}: \"{lines[i]}\" skipped");
    }
}
Console.WriteLine($"   {good} valid scores, average {(double)sum / good:F2}");

// 4. The same check without exceptions: TryParse returns false for bad text
int bad = 0;
foreach (string line in lines)
{
    if (!int.TryParse(line, out int value))
    {
        bad++;
    }
}
Console.WriteLine($"4) TryParse: {bad} bad lines");
