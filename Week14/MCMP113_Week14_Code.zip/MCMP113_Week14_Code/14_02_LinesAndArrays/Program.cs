// MCMP113 · Week 14 · Example 2 — arrays to lines and back
// File.WriteAllLines saves a string[] (one element per line); File.ReadAllLines returns a string[].

string path = "temperatures.txt";

// 1. Save a week of temperatures: number array -> string array -> file
double[] week = { 14.5, 16.0, 13.5, 18.0, 19.5, 17.0, 15.5 };
string[] lines = new string[week.Length];
for (int i = 0; i < week.Length; i++)
{
    lines[i] = week[i].ToString();                // 14.5 -> "14.5"
}
File.WriteAllLines(path, lines);
Console.WriteLine($"Saved {lines.Length} lines to {path}");

// 2. AppendAllLines adds lines at the end (here: one more day)
File.AppendAllLines(path, new string[] { "21.0" });

// 3. Load: the file becomes a string[], one element per line
string[] loaded = File.ReadAllLines(path);
Console.WriteLine($"Loaded {loaded.Length} lines: {string.Join(" | ", loaded)}");

// 4. Convert and process with the loops of Weeks 9-10
double sum = 0;
double max = double.Parse(loaded[0]);
int maxDay = 0;
for (int i = 0; i < loaded.Length; i++)
{
    double t = double.Parse(loaded[i]);
    sum += t;
    if (t > max)
    {
        max = t;
        maxDay = i;
    }
}
Console.WriteLine($"Average: {sum / loaded.Length:F2} C");
Console.WriteLine($"Warmest: day {maxDay + 1} with {max:F1} C");
