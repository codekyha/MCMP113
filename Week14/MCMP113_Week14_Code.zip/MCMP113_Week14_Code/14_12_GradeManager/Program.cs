// MCMP113 · Week 14 · Example 12 — mini-project: Student Grade Manager
// Menu (Week 7) + parallel arrays (Weeks 9-10) + methods (Weeks 12-13) + file save/load (Week 14).

// ---------- Data: parallel arrays with a fixed capacity ----------
const int Capacity = 30;                    // room for at most 30 students
string[] names = new string[Capacity];
int[] midterms = new int[Capacity];
int[] finals = new int[Capacity];
string dataFile = "students.csv";           // relative path: the project folder with dotnet run

Console.WriteLine("=== Student Grade Manager ===");
int count = LoadFromFile(dataFile, names, midterms, finals);   // number of used places
Console.WriteLine($"{count} student(s) loaded");

// ---------- Main loop: menu until the user chooses 0 ----------
int choice;
do
{
    Console.WriteLine();
    Console.WriteLine("1 Add  2 List  3 Statistics  4 Search  5 Save  0 Exit");
    choice = ReadInt("Choice: ", 0, 5);
    switch (choice)
    {
        case 1:
            count = AddStudent(names, midterms, finals, count);
            break;
        case 2:
            PrintList(names, midterms, finals, count);
            break;
        case 3:
            PrintStatistics(names, midterms, finals, count);
            break;
        case 4:
            Console.Write("Name to search: ");
            int index = IndexOfName(names, count, Console.ReadLine());
            if (index == -1)
            {
                Console.WriteLine("Not found.");
            }
            else
            {
                double avg = Average(midterms[index], finals[index]);
                Console.WriteLine($"{names[index]}: average {avg:F1}, grade {LetterGrade(avg)}");
            }
            break;
        case 5:
            SaveToFile(dataFile, names, midterms, finals, count);
            break;
    }
} while (choice != 0);

SaveToFile(dataFile, names, midterms, finals, count);       // save automatically on exit
Console.WriteLine("Goodbye!");

// ---------- Input ----------
// Asks until the user types a whole number between min and max (Week 12 ReadInt)
static int ReadInt(string prompt, int min, int max)
{
    Console.Write(prompt);
    int value;
    while (!int.TryParse(Console.ReadLine(), out value)
           || value < min || value > max)
    {
        Console.Write($"Please type a number from {min} to {max}: ");
    }
    return value;
}

// Asks for a name that is not empty and has no comma (a comma would break the CSV file)
static string ReadName(string prompt)
{
    Console.Write(prompt);
    string name = Console.ReadLine().Trim();
    while (name == "" || name.Contains(','))
    {
        Console.Write("Name must not be empty or contain a comma: ");
        name = Console.ReadLine().Trim();
    }
    return name;
}

// ---------- Computations (pure functions) ----------
// Weighted average with the MCMP113 weights: midterm 40 %, final 60 %
static double Average(int midterm, int final)
{
    return 0.4 * midterm + 0.6 * final;
}

// Letter grade on the example scale of Week 5
static string LetterGrade(double score)
{
    return score switch
    {
        >= 90 => "AA",
        >= 85 => "BA",
        >= 80 => "BB",
        >= 75 => "CB",
        >= 70 => "CC",
        >= 65 => "DC",
        >= 60 => "DD",
        _ => "FF"
    };
}

// Linear search (Week 10), ignoring upper/lower case; -1 if the name is not there
static int IndexOfName(string[] names, int count, string name)
{
    for (int i = 0; i < count; i++)
    {
        if (string.Equals(names[i], name.Trim(), StringComparison.OrdinalIgnoreCase))
        {
            return i;
        }
    }
    return -1;
}

// ---------- Actions on the arrays ----------
// Reads one student into the next free place; returns the new count
static int AddStudent(string[] names, int[] midterms, int[] finals, int count)
{
    if (count == names.Length)
    {
        Console.WriteLine("The list is full.");
        return count;
    }
    names[count] = ReadName("Name: ");
    midterms[count] = ReadInt("Midterm (0-100): ", 0, 100);
    finals[count] = ReadInt("Final (0-100): ", 0, 100);
    return count + 1;
}

// Prints all students as a table
static void PrintList(string[] names, int[] midterms, int[] finals, int count)
{
    Console.WriteLine($"{"#",2}  {"Name",-16}{"Mid",4}{"Fin",5}{"Avg",7}  Grade");
    for (int i = 0; i < count; i++)
    {
        double avg = Average(midterms[i], finals[i]);
        string letter = LetterGrade(avg);
        Console.WriteLine($"{i + 1,2}  {names[i],-16}{midterms[i],4}{finals[i],5}{avg,7:F1}  {letter}");
    }
}

// Prints the class average, the best student and the number of passes
static void PrintStatistics(string[] names, int[] midterms, int[] finals, int count)
{
    if (count == 0)
    {
        Console.WriteLine("No students yet.");
        return;                                     // early return (Week 13)
    }
    double sum = 0;
    int best = 0, passed = 0;
    for (int i = 0; i < count; i++)
    {
        double avg = Average(midterms[i], finals[i]);
        sum += avg;
        if (avg > Average(midterms[best], finals[best]))
        {
            best = i;                               // index of the maximum (Week 10)
        }
        if (LetterGrade(avg) != "FF")
        {
            passed++;
        }
    }
    Console.WriteLine($"Class average: {sum / count:F2}");
    Console.WriteLine($"Best student : {names[best]}");
    Console.WriteLine($"Passed       : {passed} of {count}");
}

// ---------- Files ----------
// Writes one CSV line "name,midterm,final" per student
static void SaveToFile(string path, string[] names, int[] midterms, int[] finals, int count)
{
    using (StreamWriter writer = new StreamWriter(path))
    {
        for (int i = 0; i < count; i++)
        {
            writer.WriteLine($"{names[i]},{midterms[i]},{finals[i]}");
        }
    }
    Console.WriteLine($"{count} student(s) saved to {path}");
}

// Fills the arrays from the CSV file; skips damaged lines; returns how many were read
static int LoadFromFile(string path, string[] names, int[] midterms, int[] finals)
{
    if (!File.Exists(path))
    {
        return 0;                                   // first run: nothing saved yet
    }
    string[] lines;
    try
    {
        lines = File.ReadAllLines(path);
    }
    catch (IOException)                             // e.g. the file is open in another program
    {
        Console.WriteLine($"Cannot read {path}.");
        return 0;
    }
    int count = 0;
    for (int i = 0; i < lines.Length && count < names.Length; i++)
    {
        string[] fields = lines[i].Split(',');      // "Ayse Kaya,72,64" -> 3 fields
        if (fields.Length == 3
            && int.TryParse(fields[1], out int mid)
            && int.TryParse(fields[2], out int fin))
        {
            names[count] = fields[0];
            midterms[count] = mid;
            finals[count] = fin;
            count++;
        }
        else
        {
            Console.WriteLine($"Line {i + 1} skipped: \"{lines[i]}\"");
        }
    }
    return count;
}
