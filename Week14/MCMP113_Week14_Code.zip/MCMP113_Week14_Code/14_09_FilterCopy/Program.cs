// MCMP113 · Week 14 · Example 9 — copy and filter lines
// Reads a file line by line and copies only the lines that contain a keyword into a new file.

string source = "announcements.txt";
string[] sample =
{
    "05.10 Lab 13 solutions are online",
    "06.10 Office hours moved to Wednesday",
    "08.10 Final exam: date will be announced",
    "09.10 Lab 14 is about text files",
    "12.10 Exam rooms: see the course group",
};
File.WriteAllLines(source, sample);                     // our own test data

File.Copy(source, "announcements_backup.txt", true);    // full copy; true = overwrite
Console.WriteLine("Backup copy created.");

Console.Write("Keyword: ");
string keyword = Console.ReadLine();
string target = $"filtered_{keyword}.txt";

int total = 0, copied = 0;
using (StreamReader reader = new StreamReader(source))
using (StreamWriter writer = new StreamWriter(target))
{
    string line;
    while ((line = reader.ReadLine()) != null)           // read, then test for the end
    {
        total++;
        if (line.Contains(keyword, StringComparison.OrdinalIgnoreCase))
        {
            writer.WriteLine(line);
            copied++;
        }
    }
}
Console.WriteLine($"{copied} of {total} lines copied to {target}:");
foreach (string line in File.ReadAllLines(target))
{
    Console.WriteLine($"  {line}");
}
