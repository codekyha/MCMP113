// MCMP113 · Week 14 · Example 6 — a log file with timestamps
// Every event is appended as one line "yyyy-MM-dd HH:mm | LEVEL | message"; the log grows run after run.

string logPath = "sensor.log";
Log(logPath, "INFO", "Program started");

Console.Write("How many readings? ");
int n = int.Parse(Console.ReadLine());
for (int i = 1; i <= n; i++)
{
    Console.Write($"Temperature {i}: ");
    double t = double.Parse(Console.ReadLine());
    if (t > 30)
    {
        Log(logPath, "WARN", $"Reading {i}: {t:F1} C is too high");
    }
    else
    {
        Log(logPath, "INFO", $"Reading {i}: {t:F1} C");
    }
}
Log(logPath, "INFO", "Program finished");

// Show the whole log (also the lines of earlier runs)
string[] lines = File.ReadAllLines(logPath);
Console.WriteLine($"--- {logPath}: {lines.Length} lines ---");
foreach (string line in lines)
{
    Console.WriteLine(line);
}

// Appends one line with the current date and time to the log file
static void Log(string path, string level, string message)
{
    string line = $"{DateTime.Now:yyyy-MM-dd HH:mm} | {level} | {message}";
    File.AppendAllText(path, line + Environment.NewLine);
}
