# MCMP113 · Introduction to Basic Algorithms and Programming
## Week 14 — example code pack

Asst. Prof. Hasan Oğuz, PhD · Istanbul Okan University · 2026–2027 Fall

Every folder in this pack is a **separate, complete C# console project** (`.csproj` + `Program.cs`) for .NET 10.
All programs were built with 0 errors / 0 warnings and run with the sample inputs listed below.

### Getting started
1. Install the **.NET 10 SDK** (https://dotnet.microsoft.com/en-us/download/dotnet/10.0) and **Visual Studio Code** with the **C# Dev Kit** extension.
2. Unzip this pack, e.g. to `Documents\MCMP113\Week14`.
3. Run one example from a terminal:
   ```
   cd 14_01_FirstFile
   dotnet run
   ```
4. Or open the whole pack in VS Code (`File → Open Folder…`). The solution file `MCMP113_Week14_Code.sln` lists all projects; in the C# Dev Kit *Solution Explorer* right-click a project → *Debug → Start New Instance*.

### Notes
* Programs are written with **top-level statements** (no `class Program`/`Main` needed).
* The course project template turns off nullable warnings and uses **invariant culture**, so decimal numbers are typed with a **point** (`72.5`) even on Turkish-language Windows.
* Typing input: when a program waits, type a value and press **Enter**. Stop a running program with **Ctrl + C**.
* `bin/` and `obj/` folders are created automatically on the first build; you may delete them at any time.

---


Each folder is a separate .NET 10 console project (course template: Nullable disabled,
InvariantGlobalization on). Open the folder in VS Code and press Run, or type `dotnet run` inside it.
All programs were built with 0 errors / 0 warnings and run with the sample input below;
the transcripts on the slides and in the notes are real output of these runs.
Methods are local functions placed at the bottom of Program.cs, each with a one-line `//` comment.

**Where do the files go?** Every program uses *relative* paths such as `"grades.csv"`. A relative path
is resolved from the **working directory**. With `dotnet run` (or Run in VS Code) the working directory is
the **project folder**, so the data files appear next to `Program.cs`. (The compiled program itself lives in
`bin/Debug/net10.0/`, which is `AppContext.BaseDirectory`; Example 1 prints both.)

**No external data files are needed.** Every program creates the files it reads (synthetic data only —
all names and grades are made up). Files are written as UTF-8. Programs that keep data *between runs*
(05, 06, 08, 10, 12) start empty the first time; delete their data files to start again.

| Folder | What it shows | Sample input | Files it creates |
|---|---|---|---|
| `14_01_FirstFile` | `File.WriteAllText`, `AppendAllText`, `ReadAllText`, `Exists`, `Delete`; working directory vs `AppContext.BaseDirectory`; `Path.Combine`; overwrite vs append | none | `backup/notes_copy.txt` (`notes.txt` is deleted again) |
| `14_02_LinesAndArrays` | `File.WriteAllLines` / `ReadAllLines` / `AppendAllLines` with `string[]`; parse to `double`, average and maximum (Weeks 9–10) | none | `temperatures.txt` |
| `14_03_StreamReadWrite` | `StreamWriter` / `StreamReader` inside `using`; `ReadLine()` until `null`; append mode `new StreamWriter(path, true)` | `7` | `table_7.txt` |
| `14_04_GradebookCsv` | Writes `grades.csv`, parses rows with `Split(',')` and `int.Parse`, weighted average 40 % / 60 % per row, writes `report.txt` | none | `grades.csv`, `report.txt` |
| `14_05_ToDoList` | To-do list saved between runs: `AppendAllText` for new tasks, `WriteAllLines` to remove one | run 1: `2`, three tasks, `1`, `0`; run 2: `1 3 2 1 0` | `todo.txt` |
| `14_06_LogFile` | Log file with timestamps `DateTime.Now:yyyy-MM-dd HH:mm`, INFO/WARN levels; the log grows run after run | run 1: `3 22.5 31.2 27`; run 2: `1 19.5` | `sensor.log` |
| `14_07_TextStats` | Line / word / character / letter counter, UTF-8 Turkish letters, `catch (FileNotFoundException)` | `proverbs.txt`; `proverb.txt` (typo) | `proverbs.txt` |
| `14_08_HighScore` | Guess-the-number (Week 7) with a high-score file `name,attempts`; tuple-returning `LoadHighScore` | names `Ayla`, `Deniz`, `Mert` + halving guesses (secret is random) | `highscore.txt` |
| `14_09_FilterCopy` | `File.Copy`; copy only the lines containing a keyword (two `using` blocks, `while ((line = reader.ReadLine()) != null)`) | `exam`; `lab` | `announcements.txt`, `announcements_backup.txt`, `filtered_<keyword>.txt` |
| `14_10_BankAccount` | Balance persisted in `balance.txt` (`decimal`), transaction history appended to `history.csv`; `FormatException` for a damaged file | run 1: `1 1500 2 5000 2 200 3 0`; run 2: `1 250.50 3 0`; run 3 (after typing `1.550,50` into balance.txt): `0` | `balance.txt`, `history.csv` |
| `14_11_SafeReading` | `try`/`catch`: `FileNotFoundException`, `IOException` (missing folder), `FormatException` per line; `TryParse` without exceptions | none | `scores.txt` |
| `14_12_GradeManager` | **Mini-project “Student Grade Manager”**: menu + parallel arrays + methods + CSV save/load (load at start, save on request and on exit) | run 1: `3`, add 4 students (with one invalid name and one invalid score), `2 3 0`; run 2: `2 4 ceren yildiz 4 Can 1 Emre Sahin 30 41 x 3 0` | `students.csv` |

Data files produced during testing were deleted, so every program starts in its "first run" state.
