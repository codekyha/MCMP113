// MCMP113 · Week 14 · Example 10 — a bank account that remembers its balance
// balance.txt holds one number; every transaction is appended to history.csv with a timestamp.

string balancePath = "balance.txt";
string historyPath = "history.csv";

decimal balance = LoadBalance(balancePath);
Console.WriteLine($"Balance loaded: {balance:F2} TL");

int choice;
do
{
    Console.Write("1 Deposit  2 Withdraw  3 History  0 Exit > ");
    choice = int.Parse(Console.ReadLine());
    switch (choice)
    {
        case 1:
            decimal deposit = ReadAmount("Amount to deposit: ");
            balance += deposit;
            SaveBalance(balancePath, balance);
            AddHistory(historyPath, "deposit", deposit, balance);
            Console.WriteLine($"New balance: {balance:F2} TL");
            break;
        case 2:
            decimal withdrawal = ReadAmount("Amount to withdraw: ");
            if (withdrawal > balance)
            {
                Console.WriteLine("Insufficient balance.");
                break;
            }
            balance -= withdrawal;
            SaveBalance(balancePath, balance);
            AddHistory(historyPath, "withdraw", withdrawal, balance);
            Console.WriteLine($"New balance: {balance:F2} TL");
            break;
        case 3:
            if (File.Exists(historyPath))
            {
                Console.Write(File.ReadAllText(historyPath));
            }
            break;
    }
} while (choice != 0);
Console.WriteLine($"Goodbye. Final balance: {balance:F2} TL");

// Reads the balance from the file; 0 if the file is missing or damaged
static decimal LoadBalance(string path)
{
    if (!File.Exists(path))
    {
        return 0;
    }
    try
    {
        return decimal.Parse(File.ReadAllText(path));
    }
    catch (FormatException)
    {
        Console.WriteLine($"Warning: {path} damaged; using 0");
        return 0;
    }
}

// Writes the balance into the file (old content replaced)
static void SaveBalance(string path, decimal balance)
{
    File.WriteAllText(path, balance.ToString("F2"));
}

// Appends one CSV line: time,type,amount,balance
static void AddHistory(string path, string type, decimal amount, decimal balance)
{
    string line = $"{DateTime.Now:yyyy-MM-dd HH:mm},{type},{amount:F2},{balance:F2}";
    File.AppendAllText(path, line + Environment.NewLine);
}

// Asks until a positive amount is typed
static decimal ReadAmount(string prompt)
{
    decimal amount;
    Console.Write(prompt);
    while (!decimal.TryParse(Console.ReadLine(), out amount) || amount <= 0)
    {
        Console.Write("Please type a positive amount: ");
    }
    return amount;
}
