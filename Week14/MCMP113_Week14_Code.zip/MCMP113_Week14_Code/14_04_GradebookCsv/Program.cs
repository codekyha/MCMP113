// MCMP113 · Week 14 · Example 4 — gradebook CSV -> report file
// Parses each CSV row with Split(','), computes the weighted average per row and writes report.txt.

string csvPath = "grades.csv";
string reportPath = "report.txt";

// 1. Create the input file (synthetic data), so the program needs no external file
string[] rows =
{
    "name,midterm,final",
    "Ayse Kaya,72,64",
    "Burak Demir,55,66",
    "Ceren Yildiz,88,95",
    "Deniz Arslan,58,61",
    "Emre Sahin,30,41",
};
File.WriteAllLines(csvPath, rows);

// 2. Read the CSV and write the report at the same time
string[] lines = File.ReadAllLines(csvPath);
double classSum = 0;
int passed = 0;
using (StreamWriter report = new StreamWriter(reportPath))
{
    report.WriteLine($"{"Student",-14}{"Mid",4}{"Fin",5}{"Avg",7}  Grade");
    for (int i = 1; i < lines.Length; i++)              // i = 1: skip the header row
    {
        string[] fields = lines[i].Split(',');          // "Ayse Kaya,72,64" -> 3 fields
        string name = fields[0];
        int midterm = int.Parse(fields[1]);
        int final = int.Parse(fields[2]);
        double average = 0.4 * midterm + 0.6 * final;   // MCMP113 weights: 40 % + 60 %
        string letter = LetterGrade(average);
        report.WriteLine($"{name,-14}{midterm,4}{final,5}{average,7:F1}  {letter}");
        classSum += average;
        if (letter != "FF")
        {
            passed++;
        }
    }
    int students = lines.Length - 1;
    report.WriteLine($"Class average: {classSum / students:F2}, passed: {passed} of {students}");
}

// 3. Show the report that was written
Console.WriteLine($"{reportPath} written. Its content:");
Console.Write(File.ReadAllText(reportPath));

// Letter grade for a weighted average (example scale from Week 5)
static string LetterGrade(double score)
{
    return score switch
    {
        >= 90 => "AA",
        >= 85 => "BA",
        >= 80 => "BB",
        >= 75 => "CB",
        >= 70 => "CC",
        >= 65 => "DC",
        >= 60 => "DD",
        _ => "FF"
    };
}
